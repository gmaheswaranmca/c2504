﻿using AccountBackendProject.Models;
using AccountBackendProject.Repositories;
using System;
using System.Collections.Generic;
using System.Web.Http;

namespace AccountBackendProject.Controllers
{
    public class HomeController : System.Web.Mvc.Controller
    {
        [RoutePrefix("api/accounts")]
        public class AccountsController : ApiController
        {
            private readonly AccountRepository _repo;

            public AccountsController()
            {
                _repo = new AccountRepository();
            }

            // GET: api/accounts
            [HttpGet]
            [Route("")]
            public IEnumerable<Account> GetAccounts()
            {
                return _repo.ReadAll();
            }

            // GET: api/accounts/5
            [HttpGet]
            [Route("{id:int}")]
            public Account GetAccount(int id)
            {
                var accounts = _repo.ReadAll();
                return accounts.Find(a => a.AccountNumber == id);
            }

            // POST: api/accounts
            [HttpPost]
            [Route("")]
            public IHttpActionResult CreateAccount(Account account)
            {
                
                _repo.Create(account);
                return Ok(account);
            }

            // PUT: api/accounts/5
            [HttpPut]
            [Route("{id:int}")]
            public IHttpActionResult UpdateAccount(int id, Account account)
            {
                if (id != account.AccountNumber)
                    return BadRequest();

                var accounts = _repo.ReadAll();
                var oldAccount = accounts.Find(a => a.AccountNumber == id);

                if(oldAccount == null)
                {
                    return NotFound();
                }
                oldAccount.Address = account.Address;
                _repo.Update(oldAccount);
                return Ok(oldAccount);
            }

            // DELETE: api/accounts/5
            [HttpDelete]
            [Route("{id:int}")]
            public IHttpActionResult DeleteAccount(int id)
            {
                _repo.Delete(id);
                return Ok();
            }

            // POST: api/accounts/deposit/5
            [HttpPost]
            [Route("deposit/{id:int}")]


            public IHttpActionResult Deposit(int id, [FromBody] decimal amount)
            {
                _repo.Deposit(id, amount);
                return Ok();
            }

            // POST: api/accounts/withdraw/5
            [HttpPost]
            [Route("withdraw/{id:int}")]
            public IHttpActionResult Withdraw(int id, [FromBody] decimal amount)
            {
                try
                {
                    _repo.Withdraw(id, amount);
                    return Ok();
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }
    }
}
