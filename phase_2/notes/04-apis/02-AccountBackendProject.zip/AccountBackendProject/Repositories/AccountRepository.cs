﻿using AccountBackendProject.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AccountBackendProject.Repositories
{
    public class AccountRepository
    {
        private readonly string _connectionString;

        public AccountRepository()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        // Create (Insert) a new Account
        public void Create(Account account)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Accounts (Name, Balance, Type, Email, PhoneNumber, Address, IsActive, InterestPercentage, TransactionCount, LastTransactionDate) " +
                    "VALUES (@Name, @Balance, @Type, @Email, @PhoneNumber, @Address, @IsActive, @InterestPercentage, @TransactionCount, @LastTransactionDate)", con);

                cmd.Parameters.AddWithValue("@Name", account.Name);
                cmd.Parameters.AddWithValue("@Balance", account.Balance);
                cmd.Parameters.AddWithValue("@Type", account.Type);
                cmd.Parameters.AddWithValue("@Email", account.Email);
                cmd.Parameters.AddWithValue("@PhoneNumber", account.PhoneNumber);
                cmd.Parameters.AddWithValue("@Address", account.Address);
                cmd.Parameters.AddWithValue("@IsActive", account.IsActive);
                cmd.Parameters.AddWithValue("@InterestPercentage", account.InterestPercentage);
                cmd.Parameters.AddWithValue("@TransactionCount", account.TransactionCount);
                cmd.Parameters.AddWithValue("@LastTransactionDate", account.LastTransactionDate);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        // Read (Get) all Accounts
        public List<Account> ReadAll()
        {
            List<Account> accounts = new List<Account>();

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM Accounts", con);
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    accounts.Add(new Account
                    {
                        AccountNumber = Convert.ToInt32(reader["AccountNumber"]),
                        Name = reader["Name"].ToString(),
                        Balance = Convert.ToDecimal(reader["Balance"]),
                        Type = reader["Type"].ToString(),
                        Email = reader["Email"].ToString(),
                        PhoneNumber = reader["PhoneNumber"].ToString(),
                        Address = reader["Address"].ToString(),
                        IsActive = Convert.ToBoolean(reader["IsActive"]),
                        InterestPercentage = reader["InterestPercentage"].ToString(),
                        TransactionCount = Convert.ToInt32(reader["TransactionCount"]),
                        LastTransactionDate = Convert.ToDateTime(reader["LastTransactionDate"])
                    });
                }

                con.Close();
            }

            return accounts;
        }

        // Update an existing Account
        public void Update(Account account)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET Name=@Name, Balance=@Balance, Type=@Type, Email=@Email, PhoneNumber=@PhoneNumber, Address=@Address, " +
                    "IsActive=@IsActive, InterestPercentage=@InterestPercentage, TransactionCount=@TransactionCount, LastTransactionDate=@LastTransactionDate WHERE AccountNumber=@AccountNumber", con);

                cmd.Parameters.AddWithValue("@AccountNumber", account.AccountNumber);
                cmd.Parameters.AddWithValue("@Name", account.Name);
                cmd.Parameters.AddWithValue("@Balance", account.Balance);
                cmd.Parameters.AddWithValue("@Type", account.Type);
                cmd.Parameters.AddWithValue("@Email", account.Email);
                cmd.Parameters.AddWithValue("@PhoneNumber", account.PhoneNumber);
                cmd.Parameters.AddWithValue("@Address", account.Address);
                cmd.Parameters.AddWithValue("@IsActive", account.IsActive);
                cmd.Parameters.AddWithValue("@InterestPercentage", account.InterestPercentage);
                cmd.Parameters.AddWithValue("@TransactionCount", account.TransactionCount);
                cmd.Parameters.AddWithValue("@LastTransactionDate", account.LastTransactionDate);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        // Delete an Account (Soft Delete)
        public void Delete(int accountNumber)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET IsActive = 0 WHERE AccountNumber = @AccountNumber", con);
                cmd.Parameters.AddWithValue("@AccountNumber", accountNumber);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        // Deposit Amount to Account
        public void Deposit(int accountNumber, decimal amount)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET Balance = Balance + @Amount, TransactionCount = TransactionCount + 1, LastTransactionDate = @LastTransactionDate WHERE AccountNumber = @AccountNumber", con);
                cmd.Parameters.AddWithValue("@Amount", amount);
                cmd.Parameters.AddWithValue("@AccountNumber", accountNumber);
                cmd.Parameters.AddWithValue("@LastTransactionDate", DateTime.Now);

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        // Withdraw Amount from Account
        public void Withdraw(int accountNumber, decimal amount)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Accounts SET Balance = Balance - @Amount, TransactionCount = TransactionCount + 1, LastTransactionDate = @LastTransactionDate WHERE AccountNumber = @AccountNumber AND Balance >= @Amount", con);
                cmd.Parameters.AddWithValue("@Amount", amount);
                cmd.Parameters.AddWithValue("@AccountNumber", accountNumber);
                cmd.Parameters.AddWithValue("@LastTransactionDate", DateTime.Now);

                con.Open();
                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    throw new Exception("Insufficient balance or account not found");
                }

                con.Close();
            }
        }
    }
}