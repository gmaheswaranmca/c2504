﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BankManagementSystem.Pages
{
    /// <summary>
    /// Interaction logic for AccountViewWindow.xaml
    /// </summary>
    public partial class AccountViewWindow : Window
    {
        public AccountViewWindow()
        {
            InitializeComponent();
            this.DataContext = FormConfig.accountViewModel;
        }
        private static AccountViewWindow _instance;
        public static AccountViewWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AccountViewWindow();
                }
                return _instance;
            }
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
