﻿using BankManagementSystem.Exceptions;
using BankManagementSystem.Models;
using BankManagementSystem.Repos;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Windows;

namespace BankManagementSystem.Databases
{
    public class AccountApiRepo : IAccountRepo
    {

        private static AccountApiRepo _instance;
        public static AccountApiRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AccountApiRepo("https://localhost:44348/");
                }
                return _instance;
            }
        }
        private readonly string _apiBaseUrl;

        public AccountApiRepo(string apiBaseUrl)
        {
            _apiBaseUrl = apiBaseUrl;
        }

        // Create an account (HTTP POST)
        public void Create(Account account)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_apiBaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var jsonContent = JsonConvert.SerializeObject(account);
                var httpContent = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = client.PostAsync("api/accounts", httpContent).Result;
                response.EnsureSuccessStatusCode();
            }
        }

        // Update an account (HTTP PUT)
        public void Update(Account account)
        {
            try
            { 
                using (HttpClient client = new HttpClient())
                {
                    client.BaseAddress = new Uri(_apiBaseUrl);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    var jsonContent = JsonConvert.SerializeObject(account);
                    var httpContent = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                    HttpResponseMessage response = client.PutAsync($"api/accounts/{account.AccountNumber}", httpContent).Result;
                    response.EnsureSuccessStatusCode();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }

        // Delete an account (HTTP DELETE)
        public void Delete(Account account)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_apiBaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.DeleteAsync($"api/accounts/{account.AccountNumber}").Result;
                response.EnsureSuccessStatusCode();
            }
        }

        // Deposit to an account (HTTP PUT)
        public void Deposit(int acNo, int amount)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_apiBaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var depositData = new { AccountNumber = acNo, Amount = amount };
                var jsonContent = JsonConvert.SerializeObject(depositData);
                var httpContent = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = client.PutAsync($"api/accounts/deposit/{acNo}", httpContent).Result;
                response.EnsureSuccessStatusCode();
            }
        }

        // Withdraw from an account (HTTP PUT)
        public void Withdrw(int acNo, int amount)
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_apiBaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                var withdrawData = new { AccountNumber = acNo, Amount = amount };
                var jsonContent = JsonConvert.SerializeObject(withdrawData);
                var httpContent = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");

                HttpResponseMessage response = client.PutAsync($"api/accounts/withdraw/{acNo}", httpContent).Result;
                response.EnsureSuccessStatusCode();
            }
        }

        // Calculate interest and update balance (Business logic on API side)
        public void CalculateInterestAndUpdateBalance()
        {
            // Placeholder for the business logic call to the API
        }

        // Read all accounts (HTTP GET)
        public ObservableCollection<Account> ReadAll()
        {
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri(_apiBaseUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = client.GetAsync("api/accounts").Result;
                if (response.IsSuccessStatusCode)
                {
                    var jsonString = response.Content.ReadAsStringAsync().Result;
                    var accounts = JsonConvert.DeserializeObject<ObservableCollection<Account>>(jsonString);
                    return accounts;
                }
                else
                {
                    return null;
                }
            }
        } 

    }
}
