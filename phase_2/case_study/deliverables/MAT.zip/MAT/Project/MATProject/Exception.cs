﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MATProject
{
	public class MedicationException : Exception
	{
		public MedicationException() : base() { }
		public MedicationException(string message) : base(message) { }
	}
}
