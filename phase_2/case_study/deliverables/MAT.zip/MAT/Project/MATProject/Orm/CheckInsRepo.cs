﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Entities;
using MATProject.Repo;
using System.Collections.ObjectModel;

namespace MATProject.Orm
{
    public class CheckInsRepo : ICheckInsRepo
    {
        //instance of EF DbContextclass
        private readonly MatDbEntities _context;
        private static CheckInsRepo _instance;

        public CheckInsRepo()
        {
            _context = new MatDbEntities();
        }

        public static CheckInsRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new CheckInsRepo();
                }
                return _instance;
            }
        }


    }
}
