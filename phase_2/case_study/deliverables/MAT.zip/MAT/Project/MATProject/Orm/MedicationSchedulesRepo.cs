﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Repo;
using MATProject.Entities;
using System.Collections.ObjectModel;


namespace MATProject.Orm
{
    public  class MedicationSchedulesRepo:IMedicationSchedulesRepo
    {

        private readonly MatDbEntities _context;
        private static MedicationSchedulesRepo _instance;
        public MedicationSchedulesRepo()
        {
            _context = new MatDbEntities();
        }
        public static MedicationSchedulesRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MedicationSchedulesRepo();
                }
                return _instance;
            }
        }

        public ObservableCollection<Medication> ReadAll()
        {
            return new ObservableCollection<Medication>(_context.Medications.ToList());
        }
    }
}
