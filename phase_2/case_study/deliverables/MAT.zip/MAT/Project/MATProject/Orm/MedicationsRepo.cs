﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using MATProject.Repo;
using MATProject.Entities;


namespace MATProject.Orm
{
	public class MedicationsRepo : IMedicationsRepo
    {
		//instance of EF DbContextclass
		private readonly MatDbEntities _context;
		private static MedicationsRepo _instance;
		

		public MedicationsRepo()
		{
            _context = new MatDbEntities();
		}

		
		public static MedicationsRepo Instance
		{
			get
			{
				if (_instance == null)
				{
					_instance = new MedicationsRepo();
				}
				return _instance;
			}
		}

        public void AddMedication(Medication medication)
		{
			_context.Medications.Add(medication);
			_context.SaveChanges();
		}

        //public void EditMedication(Medication medication)
        //{
        //    _context.Medications.Edit(medication);
        //    _context.SaveChanges();
        //}

        public ObservableCollection<Medication> ReadAll()
        {
            return new ObservableCollection<Medication>(_context.Medications.ToList());
        }
    }
}
