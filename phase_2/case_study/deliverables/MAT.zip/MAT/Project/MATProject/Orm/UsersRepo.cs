﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Repo;
using MATProject.Entities;
using System.Collections.ObjectModel;

namespace MATProject.Orm
{
    public class UsersRepo : IUsersRepo
    {
        private readonly MatDbEntities _context;
        private static UsersRepo _instance;

        //public bool ValidateUser(string email, string password)
        //{
        //    //CODE
        //    return _instance.ValidateUser(email, password);//REMOVE THIS
        //}
        public UsersRepo()
        {
            _context = new MatDbEntities();
        }

        public static UsersRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UsersRepo();
                }
                return _instance;
            }
        }

        public void AddUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public ObservableCollection<User> ReadAll()
        {
            return new ObservableCollection<User>(_context.Users.ToList());
        }
    }
}