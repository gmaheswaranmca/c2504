﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using MATProject.Entities;
using MATProject.Repo;

namespace MATProject.Orm
{
    public class DashBoardRepo : IDashBoardRepo
    {

        private readonly MatDbEntities _context;
        private static DashBoardRepo _instance;


        public DashBoardRepo()
        {
            _context = new MatDbEntities();
        }


        public static DashBoardRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DashBoardRepo();
                }
                return _instance;
            }
        }




        public ObservableCollection<Medication> ReadAll()
        {

            //  return new ObservableCollection<Medication>(_context.Medications.ToList());
            DateTime currentDate = DateTime.Now;
            var filteredItems = _context.Medications.Where(item => currentDate >= item.StartDate && currentDate <= item.EndDate).ToList();
            if (filteredItems.Any()) {

                foreach (var item in filteredItems) {

                    string frequencyLabel = ConvertFrequencyToLabel(item.Frequency);
                    item.Frequency = frequencyLabel;
                }

            }
            
            return new ObservableCollection<Medication>(filteredItems);

        }
        private static string ConvertFrequencyToLabel(string frequency)
        {
            string[] parts = frequency.Split('-');
            List<string> labels = new List<string>();

            if (parts.Length == 3)
            {
                if (parts[0] == "1") labels.Add("Morning");
                if (parts[1] == "1") labels.Add("Lunch");
                if (parts[2] == "1") labels.Add("Night");
            }

            return string.Join(", ", labels);
        }

        //public ObservableCollection<Medication> ReadReminders()
        //{



        //}


    }
}
