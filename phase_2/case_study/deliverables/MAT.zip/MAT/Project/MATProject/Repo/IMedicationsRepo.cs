﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Entities;

namespace MATProject.Repo
{
    public interface IMedicationsRepo
    {
		void AddMedication(Medication medication);
		//void Create(Medication medication);


		//Medication GetMedication(int medicationId);

		ObservableCollection<Medication> ReadAll();
		//void UpdateMedication(Medication medication);
		//void DeleteMedication(int medicationId);

	}
}
