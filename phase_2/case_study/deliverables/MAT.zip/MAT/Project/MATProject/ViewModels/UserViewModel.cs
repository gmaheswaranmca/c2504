﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Commands;

using System.Windows.Input;
using System.Windows;
using MATProject.Repo;
using MATProject.Orm;
using System.ComponentModel;
using System.Data.SqlClient;
using MATProject.Entities;
using log4net;
using log4net.Repository.Hierarchy;

namespace MATProject.ViewModels
{
    public delegate void DWindowClose();
    public class UserViewModel : INotifyPropertyChanged
    {
        public DWindowClose NewWindowClose;
        private static readonly ILog log = LogManager.GetLogger(typeof(AddMedicationViewModel));

        private string _name;
        private string _email;
        private string _password;
        private string _dateOfBirth;
        private string _medicalHistory;
        private UsersRepo _userRepo;

        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        public UserViewModel()
        {
            _userRepo = new UsersRepo();
            CreateUserCommand = new RelayCommand(CreateUser);
            LoginCommand = new RelayCommand(ExcueteLogin);
            LoadUsers();
            log.Info("User ViewModel initialized.");
        }
        public void LoadUsers()
        {
            Users = _userRepo.ReadAll();
            log.Debug("Users loaded.");
        }
        public string Name
        {
            get => _name;
            set
            {
                _name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
        public string Email
        {
            get => _email;
            set
            {
                _email = value;
                OnPropertyChanged(nameof(Email));
            }
        }
        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                OnPropertyChanged(nameof(Password));
            }
        }
        public string DateOfBirth
        {
            get => _dateOfBirth;
            set
            {
                _dateOfBirth = value;
                OnPropertyChanged(nameof(DateOfBirth));
            }
        }
        public string MedicalHistory
        {
            get => _medicalHistory;
            set
            {
                _medicalHistory = value;
                OnPropertyChanged(nameof(MedicalHistory));
            }
        }

        

        public void SignUp()
        {
            var user = new User { Name = Name, Email = Email, PasswordHash = Password };
            _userRepo.AddUser(user);
            log.Info($"User  '{Name}' signed up.");
        }

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand CreateUserCommand { get; set; }
        public ICommand LoginCommand { get; set; }

        private void ExcueteLogin()
        {
            
                string enteredEmail = Email;
            string enteredPassword= Password;
                var userss = Users.FirstOrDefault(u => u.Email == enteredEmail&& u.PasswordHash==enteredPassword );

            if (userss != null) {

                MessageBox.Show("Login Successful");
                FormConfig.loggedIn.Show();
            }else
            {
                MessageBox.Show("Invalid Username or Password");
            }

            
        }
        private void CreateUser()
        {
            try
            {
                var user = new User
                {
                    Name = this.Name,
                    Email = this.Email,
                    PasswordHash = this.Password,
                    DateOfBirth = DateTime.Parse(this.DateOfBirth),
                    MedicalHistory = this.MedicalHistory,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now,
                };
                _userRepo.AddUser(user);
                LoadUsers();
                MessageBox.Show("Sign Up Successful");
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"Error adding user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show($"Error adding user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message} - InnerException: {ex.InnerException.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}

