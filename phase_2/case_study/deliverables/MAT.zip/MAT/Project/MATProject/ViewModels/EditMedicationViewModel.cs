﻿//using System;
//using System.Collections.Generic;
//using System.Collections.ObjectModel;
//using System.ComponentModel;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Security.Principal;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows;
//using System.Windows.Input;
//using MATProject.Commands;
//using MATProject.Entities;
//using MATProject.Orm;

//namespace MATProject.ViewModels
//{
//    public class EditMedicationViewModel : INotifyPropertyChanged
//    {
//        private string medicationName;
//        private DateTime startDate;
//        private DateTime endDate;
//        private string dosage;
//        private string frequency;
//        private int userId;
//        private MedicationsRepo medicationsRepo;
//        public int UserId
//        {
//            get => userId;
//            set { userId = value; OnPropertyChanged(nameof(UserId)); }
//        }
//        private ObservableCollection<Medication> _medications;

//        public event PropertyChangedEventHandler PropertyChanged;

//        public ObservableCollection<Medication> Medications
//        {
//            get
//            {
//                return _medications;
//            }
//            set
//            {
//                _medications = value;
//                OnPropertyChanged(nameof(Medications));
//            }
//        }
//        public EditMedicationViewModel()
//        {
//            medicationsRepo = new MedicationsRepo();


//            //CreateMedicationCommand = new RelayCommand(CreateMedication);
//            LoadMedications();
//        }

//        public void LoadMedications()
//        {
//            Medications = medicationsRepo.ReadAll();

//        }

//        //Properties bound to the view
//        public string MedicationName
//        {
//            get => medicationName;
//            set
//            {
//                medicationName = value; OnPropertyChanged(nameof(MedicationName));
//            }
//        }

//        public DateTime StartDate
//        {
//            get => startDate;
//            set
//            {
//                startDate = value; OnPropertyChanged(nameof(StartDate));
//            }
//        }
//        public DateTime EndDate
//        {
//            get => endDate;
//            set
//            {
//                endDate = value; OnPropertyChanged(nameof(EndDate));
//            }
//        }
//        public string Dosage
//        {
//            get => dosage;
//            set
//            {
//                dosage = value; OnPropertyChanged(nameof(Dosage));
//            }
//        }
//        public string Frequency
//        {
//            get => frequency;
//            set
//            {
//                frequency = value; OnPropertyChanged(nameof(Frequency));
//            }
//        }

//        private void OnPropertyChanged(string propertyName)
//        {
//            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
//        }
//        private Medication _selectedMedication = null;
//        /// <summary>
//        /// Gets or sets the selected account.
//        /// </summary>
//        public Medication SelectedAccount
//        {
//            get => _selectedMedication;
//            set
//            {
//                _selectedMedication = value;
//                onPropertyChanged(nameof(SelectedAccount));
//            }
//        }

//        private void onPropertyChanged(string propertyName)
//        {
//            if (PropertyChanged != null)
//            {
//                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
//            }
//        }

//        public ICommand CreateMedicationCommand { get; set; }
//        public ICommand UpdateCommand { get; }

//        private void UpdateMedication()
//        {
//            try
//            {
//                var medication = new Medication
//                {
//                    MedicationName = this.MedicationName,
//                    StartDate = this.StartDate,
//                    EndDate = this.EndDate,
//                    Dosage = this.Dosage,
//                    Frequency = this.Frequency,
//                    //UserID=this.UserId,
//                    CreatedAt = DateTime.Now,
//                    UpdatedAt = DateTime.Now,
//                };
//                medicationsRepo.AddMedication(medication);
//                //medicationsRepo.EditMedication(medication);

//                LoadMedications();
//                MessageBox.Show("Medication editted successfully");
//            }
//            catch (SqlException ex)
//            {
//                MessageBox.Show($"Error editing medication: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
//            }
//            catch (InvalidOperationException ex)
//            {
//                MessageBox.Show($"Error editing medication: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show($"An unexpected error occurred: {ex.Message} - InnerException: {ex.InnerException.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
//            }
//        }
//    }
//}
