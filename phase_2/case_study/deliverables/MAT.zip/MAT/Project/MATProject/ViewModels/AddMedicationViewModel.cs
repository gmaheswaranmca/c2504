﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Commands;
using System.Windows.Input;
using System.ComponentModel;
using MATProject.Orm;
using System.Security.Principal;
using System.Collections.ObjectModel;
using System.Windows;
using MATProject.Entities;
using System.Data.SqlClient;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;

namespace MATProject.ViewModels
{
    /// <summary>
    /// View model for adding a new medication.
    /// </summary>
    public class AddMedicationViewModel : INotifyPropertyChanged
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(AddMedicationViewModel));
        /// <summary>
        /// Event handler for property changed notifications.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
		private string medicationName;
		private DateTime startDate;
		private DateTime endDate;
		private string dosage;
		private string frequency;
		private int userId;
        // Repository for medications
        private MedicationsRepo medicationsRepo;
        /// <summary>
        /// Gets or sets the user ID.
        /// </summary>
        public int UserId
		{
			get => userId;
			set { userId = value; OnPropertyChanged(nameof(UserId)); }
		}
        private ObservableCollection<Medication> _medications;
		DashboardViewModel _dashboardViewModel=new DashboardViewModel();
        public ObservableCollection<Medication> Medications
        {
            get
            {
                return _medications;
            }
            set
            {
                _medications = value;
                OnPropertyChanged(nameof(Medications));
            }
        }
        public AddMedicationViewModel()
		{
            medicationsRepo = new MedicationsRepo();
			CreateMedicationCommand = new RelayCommand(CreateMedication); 
			LoadMedications();
			_dashboardViewModel.LoadMedications();
            log.Info("AddMedicationViewModel initialized.");
        }

		public void LoadMedications()
		{
			Medications=medicationsRepo.ReadAll();
            log.Debug("Medications loaded.");
        }

		//Properties bound to the view
		public string MedicationName 
		{ get => medicationName; 
			set 
			{ 
				medicationName = value; OnPropertyChanged(nameof(MedicationName)); 
			} 
		}

		public DateTime StartDate
		{
			get => startDate;
			set
			{
				startDate = value; OnPropertyChanged(nameof(StartDate));
			}
		}
		public DateTime EndDate
		{
			get => endDate;
			set
			{
				endDate = value; OnPropertyChanged(nameof(EndDate));
			}
		}
		public string Dosage
		{
			get => dosage;
			set
			{
				dosage = value; OnPropertyChanged(nameof(Dosage));
			}
		}
        /// <summary>
        /// Gets or sets the frequency.
        /// </summary>
        public string Frequency
		{
			get => frequency;
			set
			{
				frequency = value; OnPropertyChanged(nameof(Frequency));
			}
		}
        /// <summary>
        /// Raises the PropertyChanged event.
        /// </summary>
        private void OnPropertyChanged(string propertyName)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
		}

        /// <summary>
        /// Command for creating a new medication.
        /// </summary>
        public ICommand CreateMedicationCommand { get; set; }
        /// <summary>
        /// Creates a new medication and adds it to the repository.
        /// </summary>
        private void CreateMedication()
		{
			try
			{
				var medication = new Medication
				{
					MedicationName = this.MedicationName,
					StartDate = this.StartDate,
					EndDate = this.EndDate,
					Dosage = this.Dosage,
					Frequency = this.Frequency,
					//UserID=this.UserId,
					CreatedAt = DateTime.Now,
					UpdatedAt = DateTime.Now,
                };
				medicationsRepo.AddMedication(medication);
				LoadMedications();
				MessageBox.Show("Medication added successfully");
                log.Info($"Medication '{medication.MedicationName}' added successfully.");
            }
            catch (SqlException ex)
			{
                log.Error("Error adding medication:{ex.Message}");
                MessageBox.Show($"Error adding medication: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
            catch (InvalidOperationException ex)
            {
                log.Error("Error adding medication:{ex.Message}");
                MessageBox.Show($"Error adding medication: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
			{
                log.Error("Error adding medication:{ex.Message}");
                MessageBox.Show($"An unexpected error occurred: {ex.Message} - InnerException: {ex.InnerException.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
	}
}
