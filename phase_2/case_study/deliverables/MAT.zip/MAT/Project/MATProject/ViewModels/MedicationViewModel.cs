﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Commands;
using MATProject.Orm;

namespace MATProject.ViewModels
{
	public class MedicationViewModel : INotifyPropertyChanged
	{
		public event PropertyChangedEventHandler PropertyChanged;

		private string medicationName;
		private DateTime startDate;
		private DateTime endDate;
		private string dosage;
		private string frequency;
		private int userId;
		private MedicationsRepo medicationsRepo;

		public MedicationViewModel()
		{

		}
	}
}
