﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using MATProject.Entities;
using MATProject.Orm;
using MATProject.Repo;
using log4net;
using log4net.Repository.Hierarchy;

namespace MATProject.ViewModels
{
    public class DashboardViewModel : INotifyPropertyChanged
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(AddMedicationViewModel));
        private DashBoardRepo dashboardRepo;
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        private ObservableCollection<Medication> _medications;

        private ObservableCollection<Medication> _reminders;

        public ObservableCollection<Medication> Medications
        {
            get
            {
                return _medications;
            }
            set
            {
                _medications = value;
                OnPropertyChanged(nameof(Medications));
            }
        }
        public ObservableCollection<Medication> Reminders
        {
            get
            {
                return _reminders;
            }
            set
            {
                _reminders = value;
                OnPropertyChanged(nameof(Reminders));
            }
        }
        public DashboardViewModel() {
            dashboardRepo = new DashBoardRepo();
            LoadMedications();
            log.Info("DashboardViewModel initialized.");
        }
        public void LoadMedications()
        {
            log.Debug("Attempting to load medications.");
            Medications = dashboardRepo.ReadAll();
            log.Info("Medications loaded successfully.");
            //  Reminders = dashboardRepo.ReadReminders();



        }
    }
}
