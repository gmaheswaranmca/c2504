﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Commands;
using System.Windows.Input;
using System.Windows;
using MATProject.Orm;

namespace MATProject.ViewModels
{
	public class PatientProfileViewModel
    {
    

       
      
    }
}
