﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Orm;
using MATProject.Repo;
using MATProject.Entities;
using System.Collections.ObjectModel;
using log4net;

namespace MATProject.ViewModels
{
	public class MedicationScheduleViewModel:INotifyPropertyChanged
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(AddMedicationViewModel));

        private MedicationSchedulesRepo medicationScheduleRepo;
        public event PropertyChangedEventHandler PropertyChanged;
        private ObservableCollection<Medication> _medications;
        public ObservableCollection<Medication> Medications
        {
            get
            {
                return _medications;
            }
            set
            {
                _medications = value;
                OnPropertyChanged(nameof(Medications));
            }
        }
        private void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public MedicationScheduleViewModel()
        {
            medicationScheduleRepo = new MedicationSchedulesRepo();

            LoadMedications();

        }
        public void LoadMedications()
        {
            log.Info("Loading medications");
            Medications = medicationScheduleRepo.ReadAll();

        }

    }
}
