﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.ViewModels;

namespace MATProject
{
    public class ViewModelConfig
    {
        //View models
        public static UserViewModel userViewModel = null;
        public static AddMedicationViewModel addMedicationViewModel = null;
		public static MedicationViewModel medicationViewModel = null;
		public static MedicationScheduleViewModel medicationScheduleViewModel = null;
		public static DashboardViewModel dashboardViewModel = null;
        public static CheckInViewModel checkInViewModel = null;

        static ViewModelConfig()
		{
            userViewModel = new UserViewModel();
            addMedicationViewModel = new AddMedicationViewModel();
			medicationViewModel = new MedicationViewModel();
			medicationScheduleViewModel=new MedicationScheduleViewModel();
			dashboardViewModel=new DashboardViewModel();
            checkInViewModel=new CheckInViewModel();

        }
	}
}
