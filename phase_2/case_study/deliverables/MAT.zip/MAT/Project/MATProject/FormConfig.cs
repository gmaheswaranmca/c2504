﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MATProject.Pages;
using MATProject.ViewModels;

namespace MATProject
{
    public class FormConfig
    {
        //Windows
        public static HomeWindow homeWindow = null;
        public static DashboardWindow dashboardWindow = null;
		public static AdherenceTrackingWindow adheranceTrackingWindow = null;
        public static CheckInWindow checkInWindow = null;
        public static LoggedInWindow loggedIn = null;
		public static AddMedicationWindow addMedicationWindow = null;
		public static MedicationWindow medicationWindow = null;
		public static MedicationScheduleWindow medicationScheduleWindow = null;
		public static RemindersAndNotificationsWindow remindersAndNotificationsWindow = null;
		//public static AdherenceTrackingWindow adheranceTrackingWindow = null;

		static FormConfig()
		{
			homeWindow = new HomeWindow();
			dashboardWindow = new DashboardWindow();
			adheranceTrackingWindow = new AdherenceTrackingWindow();
            checkInWindow = new CheckInWindow();
            loggedIn = new LoggedInWindow();
			addMedicationWindow = new AddMedicationWindow();
			medicationWindow = new MedicationWindow();
			medicationScheduleWindow = new MedicationScheduleWindow();
			remindersAndNotificationsWindow = new RemindersAndNotificationsWindow();
		}
	}
}
