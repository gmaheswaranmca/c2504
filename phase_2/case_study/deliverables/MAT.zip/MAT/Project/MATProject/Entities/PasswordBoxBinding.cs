﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows;

namespace MATProject.Entities
{
    public static class PasswordBoxBinding
    {
        public static readonly DependencyProperty BindPasswordProperty =
        DependencyProperty.RegisterAttached("BindPassword", typeof(string), typeof(PasswordBoxBinding));
        public static string GetBindPassword(DependencyObject obj)
        {
            return (string)obj.GetValue(BindPasswordProperty);
        }
        public static void SetBindPassword(DependencyObject obj, string value)
        {
            obj.SetValue(BindPasswordProperty, value);
        }
        public static readonly DependencyProperty PasswordProperty =
            DependencyProperty.RegisterAttached("Password", typeof(string), typeof(PasswordBoxBinding), new PropertyMetadata(PasswordChanged));
        private static void PasswordChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            PasswordBox passwordBox = sender as PasswordBox;
            if (passwordBox != null)
            {
                passwordBox.Password = (string)e.NewValue;
            }
        }
    }
}
