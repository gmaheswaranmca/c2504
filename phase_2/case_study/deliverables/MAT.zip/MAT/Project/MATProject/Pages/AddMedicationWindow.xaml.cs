﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace MATProject.Pages
{
    /// <summary>
    /// Interaction logic for AddMedicationWindow.xaml
    /// </summary>
    public partial class AddMedicationWindow : Window
    {
        public AddMedicationWindow()
        {
            InitializeComponent();
            DataContext=ViewModelConfig.addMedicationViewModel;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

      
    }
}
