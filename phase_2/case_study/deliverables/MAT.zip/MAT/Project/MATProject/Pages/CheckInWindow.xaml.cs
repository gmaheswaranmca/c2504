﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MATProject.Commands;
using MATProject.Entities;

namespace MATProject.Pages
{
    /// <summary>
    /// Interaction logic for CheckInWindow.xaml
    /// </summary>
    public partial class CheckInWindow : Window
    {
        //    private string _currentTime;
        //    public string CurrentTime
        //    {
        //        get { return _currentTime; }
        //        set
        //        {
        //            _currentTime = value;
        //            OnPropertyChanged(nameof(CurrentTime));
        //        }
        //    }

        //    public ObservableCollection<CheckIn> CheckIns { get; set; }
        //    public ICommand CheckMedicationCommand { get; }
        //    public ICommand SaveCommand { get; }
        //    public CheckInWindow()
        //    {
        //        InitializeComponent();
        //        // Sample data for Medications
        //        CheckIns = new ObservableCollection<CheckIn>
        //        {
        //           new CheckIn { CheckInTime = DateTime.ParseExact("09-12-2024 08:00:00", "dd-MM-yyyy HH:mm:ss", null), SideEffects = "None", AdherenceStatus = "" },
        //            new CheckIn { CheckInTime = DateTime.ParseExact("09-12-2024 12:00:00", "dd-MM-yyyy HH:mm:ss", null), SideEffects = "None", AdherenceStatus = "" },
        //        new CheckIn { CheckInTime = DateTime.ParseExact("09-12-2024 18:00:00", "dd-MM-yyyy HH:mm:ss", null), SideEffects = "None", AdherenceStatus = "" }
        //        };

        //       // CheckMedicationCommand = new RelayCommand(CheckMedication);
        //      //  SaveCommand = new RelayCommand(SaveUpdates);
        //    }

        //    private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        //    {
        //        e.Cancel = true;
        //        this.Hide();
        //    }

        //    private void CheckMedication(object parameter)
        //    {
        //        if (TimeSpan.TryParse(CurrentTime, out TimeSpan currentTime))
        //        {
        //            foreach (var medicine in Medications)
        //            {
        //                if (TimeSpan.TryParse(medicine.Time, out TimeSpan scheduledTime) && scheduledTime <= currentTime)
        //                {
        //                    MessageBoxResult result = MessageBox.Show($"Did you take {medicine.Name} scheduled at {medicine.Time}?", "Medicine Check", MessageBoxButton.YesNo);

        //                    if (result == MessageBoxResult.Yes)
        //                    {
        //                        medicine.Taken = "✔"; // Medicine was taken
        //                    }
        //                    else
        //                    {
        //                        medicine.Taken = "❌"; // Medicine was not taken
        //                    }

        //                    // Prompt for side effects after yes/no is clicked
        //                    var inputDialog = new InputDialog($"Any side effects for {medicine.Name}?", medicine.SideEffect);
        //                    if (inputDialog.ShowDialog() == true)
        //                    {
        //                        medicine.SideEffect = inputDialog.ResponseText;
        //                    }
        //                }
        //            }
        //        }
        //        else
        //        {
        //            MessageBox.Show("Please enter a valid time in 24-hour format (e.g., 14:30).", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Error);
        //        }
        //    }

        //    private void SaveUpdates(object parameter)
        //    {
        //        // You can save updates here (e.g., save to file or database)
        //        MessageBox.Show("Medication updates have been saved.", "Save", MessageBoxButton.OK, MessageBoxImage.Information);
        //    }

        //    public event PropertyChangedEventHandler PropertyChanged;

        //    protected void OnPropertyChanged(string propertyName)
        //    {
        //        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        //    }
    }
}

