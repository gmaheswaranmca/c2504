﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;
using System.Windows;
using ProjectPHT.Repo;

namespace ProjectPHT.EFRepo
{
    /// <summary>
    /// Repository class for managing health metrics in the PHT system.
    /// Implements the IHealthMetricsRepo interface.
    /// Provides methods to create and retrieve health metrics.
    /// </summary>
    public class EFHealthMetricsRepo : IHealthMetricsRepo
    {
        //string HeartRateNotification;
        //string BpSysNotification;
        //string BpdysNotification;
        //string ActLevelNotification;

        //int heartRateThreshold = 75;
        //int bpSysThreshold = 23;
        //int bpDysThresholdc = 89;
        //int activityLevel = 45;

        //public string InsightGeneration(int Heartrate,int Bpsys,int Bpdys,decimal Actlevel)
        //{
        //    if (HeartRateNotification == null) { }
        //    else if

        private readonly PHT_DbEntities _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="EFHealthMetricsRepo"/> class
        /// with a default database context.
        /// </summary>
        public EFHealthMetricsRepo()
        {
            _context = new PHT_DbEntities();
        }

        /// <summary>
        /// Adds a new health metric record to the database.
        /// </summary>
        /// <param name="healthMetric">The health metric entity to be created and saved to the database.</param>

        public void CreateHealthMetrics(HealthMetric healthMetric)
        {
            //MessageBox.Show($"working.....");
            try
            {
                _context.HealthMetrics.Add(healthMetric);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
            }



        }

        //public void InsightGeneration(int Heartrate, int Bpsys, int Bpdys, decimal Actlevel)
        //{
        //throw new NotImplementedException();
        //}
        /// <summary>
        /// Retrieves all health metrics from the database as an observable collection.
        /// </summary>
        /// <returns>An observable collection of all health metrics.</returns>
        public ObservableCollection<HealthMetric> ReadAllHealthMetrics()
        {
            return new ObservableCollection<HealthMetric>(_context.HealthMetrics.ToList());
        }
    }
}

