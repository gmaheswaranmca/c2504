﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.EFRepo
{
    /// <summary>
    /// Represents a repository for managing user data using Entity Framework.
    /// </summary>
    public class EFUserRepo : IUserRepo
    {
        private static EFUserRepo _instance;
        /// <summary>
        /// Gets the collection of users.
        /// </summary>
        public ObservableCollection<User> Users { get; set; }

        /// <summary>
        /// Gets the singleton instance of the <see cref="EFUser Repo"/>.
        /// </summary>
        public static EFUserRepo Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new EFUserRepo();
                return _instance;
            }

        }
        //public User CurrentUser { get; set; } = null;
        private PHT_DbEntities _context;


        /// <summary>
        /// Initializes a new instance of the <see cref="EFUser Repo"/> class.
        /// </summary>
        public EFUserRepo()
        {
            _context = new PHT_DbEntities();
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="EFUser Repo"/> class with a specified context.
        /// </summary>
        /// <param name="context">The database context to use.</param>
        public EFUserRepo(PHT_DbEntities context) { }


        /// <summary>
        /// Creates a new user in the repository.
        /// </summary>
        /// <param name="user">The user to create.</param>
        /// <exception cref="ArgumentNullException">Thrown when the user is null.</exception>
        public void Create(User user)
        {
            //throw new NotImplementedException();
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        /// <summary>
        /// Hashes the password using MD5.
        /// </summary>
        /// <param name="password">The plain text password.</param>
        /// <returns>The hashed password in hexadecimal format.</returns>
        public string GetPassword(string password)
        {
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(passwordBytes);

                // Convert the hash bytes to a hexadecimal string
                string inputHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                return inputHash;
            }


        }
        /*public void Login(User user)
        {
            var HashedPassword = GetPassword(user.PasswordHash);
            var User = _context.Users.FirstOrDefault(u => u.Email == user.Email && u.PasswordHash == HashedPassword);
            if (User == null)
            {
                throw new Exception("Invalid username or password");
            }
            else
            {
                CurrentUser = User;
            }

        }*/

        /// <summary>
        /// Validates if the user exists in the repository.
        /// </summary>
        /// <param name="user">The user to validate.</param>
        /// <returns>True if the user is valid; otherwise, false.</returns>
        public bool IsValidUser(User user)
        {
            //var HashedPassword = GetPassword(user.PasswordHash);
            var User = _context.Users.FirstOrDefault(u => u.Email == user.Email && u.PasswordHash == user.PasswordHash);
            if (User == null)
            {
                MessageBox.Show("Invalid email or password");
                return false;
            }
            else
            {
                //CurrentUser = User;
                return true;
            }

            //return user != null;
        }

        /// <summary>
        /// Deletes a user from the repository.
        /// </summary>
        /// <param name="userModel">The user to delete.</param>
        public void Delete(User userModel)
        {
            var userToDelete = _context.Users.Find(userModel.UserID);
            if (userToDelete != null)
            {
                _context.Users.Remove(userToDelete);
                _context.SaveChanges();
            }
        }


        /// <summary>
        /// Updates an existing user in the repository.
        /// </summary>
        /// <param name="userModel">The user model with updated values.</param>
        public void Update(User userModel)
        {
            var existingUser = _context.Users.Find(userModel.UserID);
            if (existingUser != null)
            {
                _context.Entry(existingUser).CurrentValues.SetValues(userModel);
                // existingUser.Username = userModel.Username;
                _context.SaveChanges();
            }
        }
        public ObservableCollection<User> ReadAll()
        {
            return new ObservableCollection<User>(_context.Users.ToList());
        }
    }
}