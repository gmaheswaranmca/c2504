﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.EFRepo
{
    /// <summary>
    /// Repository class for managing health insights in the PHT system.
    /// Implements the IHealthInsightsRepo interface.
    /// Provides methods to generate insights, retrieve suggestions, alerts, and user-specific insights.
    /// </summary>
    public class EFHealthInsightRepo : IHealthInsightsRepo
    {
        private readonly PHT_DbEntities _context;


        /// <summary>
        /// Initializes a new instance of the <see cref="EFHealthInsightRepo"/> class
        /// with the specified database context.
        /// </summary>
        /// <param name="context">The PHT database context used to interact with the database.</param>

        public EFHealthInsightRepo(PHT_DbEntities context)
        {
            _context = context;
        }

        /// <summary>
        /// Generates health insights based on the provided list of health metrics.
        /// Adds generated insights to the HealthInsights table in the database.
        /// </summary>
        /// <param name="healthMetrics">The list of health metrics to base insights on.</param>
        /// <exception cref="ArgumentNullException">Thrown when the healthMetrics list is null or empty.</exception>
        public void GenerateInsights(List<HealthMetric> healthMetrics)
        {
            if (healthMetrics == null || !healthMetrics.Any())
                throw new ArgumentNullException(nameof(healthMetrics));
            try
            {
                foreach (var metric in healthMetrics)
                {
                    var insight = new HealthInsight
                    {
                        UserID = metric.UserID,
                        InsightType = "Health Insight",
                        InsightDetails = "Take rest",
                        GeneratedAt = DateTime.Now
                    };

                    _context.HealthInsights.Add(insight);
                }

                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while generating health insights.", ex);
            }
        }



        /// <summary>
        /// Retrieves a list of personalized health suggestions.
        /// These are generic suggestions, and in a full implementation, they would be tailored to user metrics.
        /// </summary>
        /// <returns>A list of health-related suggestions.</returns>
        public List<string> GetSuggestions()
        {
            try
            {
                // Example suggestions, ideally these would be generated based on user metrics
                return new List<string>
            {
                "Increase your daily water intake.",
                "Aim for at least 30 minutes of exercise each day.",
                "Consider a balanced diet with more fruits and vegetables."
            };
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while retrieving suggestions.", ex);
            }
        }

        /// <summary>
        /// Retrieves a list of alerts for users with abnormal health metrics.
        /// Specifically checks for users with high blood pressure readings.
        /// </summary>
        /// <returns>A list of alert messages regarding abnormal metrics.</returns>
        public List<string> GetAlerts()
        {
            try
            {
                var alerts = new List<string>();
                var abnormalMetrics = _context.HealthMetrics
                    .Where(m => m.BloodPressureSystolic > 140 || m.BloodPressureDiastolic > 90)
                    .ToList();

                foreach (var metric in abnormalMetrics)
                {
                    alerts.Add($"Alert: User {metric.UserID} has abnormal blood pressure readings on {metric.MetricDate}.");
                }

                return alerts;
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while retrieving alerts.", ex);
            }
        }


        /// <summary>
        /// Retrieves all health insights for a specified user.
        /// </summary>
        /// <param name="userId">The ID of the user for whom the insights are to be retrieved.</param>
        /// <returns>A list of health insights for the specified user.</returns>
        public List<HealthInsight> GetInsightsByUserId(int userId)
        {
            try
            {
                return _context.HealthInsights
                .Where(h => h.UserID == userId)
                .ToList();
            }
            catch (Exception ex)
            {
                throw new Exception($"An error occurred while retrieving insights for user {userId}.", ex);
            }
        }



    }
}
