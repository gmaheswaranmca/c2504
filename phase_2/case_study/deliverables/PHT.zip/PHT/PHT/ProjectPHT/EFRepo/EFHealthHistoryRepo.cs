﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.EFRepo
{
    /// <summary>
    /// Repository class for managing health history data in the PHT system.
    /// Implements the IHealthHistoryRepo interface.
    /// </summary>
    public class EFHealthHistoryRepo : IHealthHistoryRepo
    {
        /// <summary>
        /// Reads the health history based on the specified type and date.
        /// This method is currently not implemented.
        /// </summary>
        /// <param name="type">The type of health history to read (e.g., metrics, activities).</param>
        /// <param name="date">The date for which to retrieve the health history.</param>
        /// <exception cref="NotImplementedException">Thrown when the method is not implemented.</exception>
        private readonly PHT_DbEntities _context;

        public EFHealthHistoryRepo()
        {
            _context = new PHT_DbEntities();

        }

        public ObservableCollection<HealthHistory> HistoryDataList = new ObservableCollection<HealthHistory>();

        public ObservableCollection<HealthHistory> HistoryRead(string type, DateTime date)
        {
            //using (var context = new ApplicationDbContext())
            //{
            var histories = _context.HealthHistories
                .Where(h => h.UserID == 1 &&
                            h.MetricType == type &&
                            h.RecordedAt > date)
                .ToList();

            HistoryDataList.Clear(); // Clear existing data
            foreach (var history in histories)
            {
                HistoryDataList.Add(history);
            }
            //}
            return HistoryDataList;
        }
        public ObservableCollection<HealthHistory> ReadAllHistories()
        {
            return new ObservableCollection<HealthHistory>(_context.HealthHistories.ToList());
        }
    }
}