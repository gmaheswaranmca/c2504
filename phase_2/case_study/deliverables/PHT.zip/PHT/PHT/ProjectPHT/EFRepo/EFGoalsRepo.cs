﻿using System;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.EFRepo
{
    /// <summary>
    /// Repository class for managing goals in the PHT database using Entity Framework.
    /// Provides methods to create, update, delete, and retrieve goals from the database.
    /// </summary>
    public class EFGoalsRepo : IGoalsRepo
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="EFGoalsRepo"/> class
        /// and establishes a connection to the PHT database.
        /// </summary>
        private readonly PHT_DbEntities _context;

        public EFGoalsRepo()
        {
            _context = new PHT_DbEntities();
        }

        /// <summary>
        /// Adds a new goal to the database.
        /// </summary>
        /// <param name="goalModel">The goal entity to be created and saved to the database.</param>

        public void CreateGoal(Goal goalModel)
        {
            try
            {
                _context.Goals.Add(goalModel);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while creating the goal.", ex);
            }
        }



        /// <summary>
        /// Updates an existing goal in the database.
        /// </summary>
        /// <param name="goalModel">The updated goal entity with modified values.</param>

        public void UpdateGoal(Goal goalModel)
        {
            try
            {
                var existingGoal = _context.Goals.Find(goalModel.GoalID);
                if (existingGoal != null)
                {
                    _context.Entry(existingGoal).CurrentValues.SetValues(goalModel);
                    _context.SaveChanges();
                }

                else
                {
                    throw new Exception("Goal not found.");
                }
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                throw new Exception("An error occurred while updating the goal.", ex);
            }

        }

        /// <summary>
        /// Deletes a goal from the database.
        /// </summary>
        /// <param name="goalModel">The goal entity to be deleted based on its GoalID.</param>
        public void DeleteGoal(Goal goalModel)
        {
            try
            {
                var goalToDelete = _context.Goals.Find(goalModel.GoalID);
                if (goalToDelete != null)
                {
                    _context.Goals.Remove(goalToDelete);
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                // Log the exception (consider using a logging framework)
                throw new Exception("An error occurred while deleting the goal.", ex);
            }

        }

        /// <summary>
        /// Retrieves all goals from the database as an observable collection.
        /// </summary>
        /// <returns>An observable collection of all goal entities in the database.</returns>

        public ObservableCollection<Goal> ReadAllGoal()
        {
            try
            {
                return new ObservableCollection<Goal>(_context.Goals.ToList());
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while retrieving goals.", ex);
            }
        }


    }
}