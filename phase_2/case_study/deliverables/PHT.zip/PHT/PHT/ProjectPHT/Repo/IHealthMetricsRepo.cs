﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;

namespace ProjectPHT.Repo
{
    public interface IHealthMetricsRepo 
    {
        void CreateHealthMetrics(HealthMetric healthMetric);
        ObservableCollection<HealthMetric> ReadAllHealthMetrics();

        //void InsightGeneration(int Heartrate, int Bpsys, int Bpdys, decimal Actlevel);
    }
}
