﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;

namespace ProjectPHT.Repo
{
    public interface IHealthInsightsRepo
    {
        void GenerateInsights(List<HealthMetric> healthMetrics);

        // Method to retrieve personalized suggestions
        List<string> GetSuggestions();

        // Method to retrieve alerts for abnormal metrics
        List<string> GetAlerts();

        List<HealthInsight> GetInsightsByUserId(int userId);

    }
}
