﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;

namespace ProjectPHT.Repo
{
    public interface IGoalsRepo
    {
        void CreateGoal(Goal goalModel);

        void UpdateGoal(Goal goalModel);

        void DeleteGoal(Goal goalModel);

        ObservableCollection<Goal> ReadAllGoal();
    }
}
