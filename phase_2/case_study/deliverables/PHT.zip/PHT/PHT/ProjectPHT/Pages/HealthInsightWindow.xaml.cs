﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot;

namespace ProjectPHT.Pages
{
    /// <summary>
    /// Interaction logic for HealthInsightWindow.xaml
    /// </summary>
    public partial class HealthInsightWindow : Window
    {
        public HealthInsightWindow()
        {
            InitializeComponent();
            LoadHealthData();
        }

        private void LoadHealthData()
        {
            // Example data for the plots
            LoadDailyHealthTrends();
            LoadWeeklyHealthTrends();
            LoadMonthlyHealthTrends();

            // Example personalized suggestions and alerts
            SuggestionsTextBlock.Text = "Increase your exercise to 30 minutes daily.";
            AlertsTextBlock.Text = "Warning: Your systolic blood pressure is above the normal range!";
        }

        private void LoadDailyHealthTrends()
        {
            var dailyPlotModel = new PlotModel { Title = "Daily Health Trends" };
            var lineSeries = new LineSeries { Title = "Heart Rate" };

            // Example data points
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-6)), 70));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-5)), 75));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-4)), 72));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-3)), 80));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-2)), 78));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now.AddDays(-1)), 76));
            lineSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(DateTime.Now), 74));

            dailyPlotModel.Series.Add(lineSeries);
            DailyHealthTrendsPlot.Model = dailyPlotModel;
        }

        private void LoadWeeklyHealthTrends()
        {
            var weeklyPlotModel = new PlotModel { Title = "Weekly Health Trends" };
            var lineSeries = new LineSeries { Title = "Blood Pressure" };

            // Example data points
            lineSeries.Points.Add(new DataPoint(0, 120)); // Week 1
            lineSeries.Points.Add(new DataPoint(1, 125)); // Week 2
            lineSeries.Points.Add(new DataPoint(2, 118)); // Week 3
            lineSeries.Points.Add(new DataPoint(3, 130)); // Week 4
            lineSeries.Points.Add(new DataPoint(4, 128)); // Week 5

            weeklyPlotModel.Series.Add(lineSeries);
            WeeklyHealthTrendsPlot.Model = weeklyPlotModel;
        }

        private void LoadMonthlyHealthTrends()
        {
            var monthlyPlotModel = new PlotModel { Title = "Monthly Health Trends" };
            var lineSeries = new LineSeries { Title = "Activity Level" };

            // Example data points
            lineSeries.Points.Add(new DataPoint(0, 3000)); // Month 1
            lineSeries.Points.Add(new DataPoint(1, 5000)); // Month 2
            lineSeries.Points.Add(new DataPoint(2, 4500)); // Month 3
            lineSeries.Points.Add(new DataPoint(3, 6000)); // Month 4
            lineSeries.Points.Add(new DataPoint(4, 5500)); // Month 5

            monthlyPlotModel.Series.Add(lineSeries);
            MonthlyHealthTrendsPlot.Model = monthlyPlotModel;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
