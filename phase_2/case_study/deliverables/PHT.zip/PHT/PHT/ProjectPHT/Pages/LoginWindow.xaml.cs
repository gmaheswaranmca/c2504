﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ProjectPHT.Entities;
using ProjectPHT.ViewModels;

namespace ProjectPHT.Pages
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            DataContext = PHTConfig.loginViewModel;
        }
        private User user = new User();
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        public bool ValidateEmail(User user, out string errorMessage)
        {
            if (string.IsNullOrWhiteSpace(user.Email))
            {
                errorMessage = "Please enter valid email address";
                return false;
            }
            errorMessage = string.Empty;
            return true;
        }
        private void txtEmail_TextChanged(object sender, TextChangedEventArgs e)
        {
            user.Email = txtEmail.Text;

            if (!ValidateEmail(user, out string errorMessage))
            {
                ErrorMessageeTexblock.Text = errorMessage;
            }
            else
            {
                ErrorMessageeTexblock.Text = string.Empty;
            }

        }


    }
}
