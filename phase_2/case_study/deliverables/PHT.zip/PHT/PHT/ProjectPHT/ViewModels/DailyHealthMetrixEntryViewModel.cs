﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Commands;
using ProjectPHT.EFRepo;
using ProjectPHT.Repo;
using System.Windows.Input;
using System.Windows;
using ProjectPHT.Entities;

namespace ProjectPHT.ViewModels
{

    public delegate void DWidnowClose();
    public delegate bool DFormValid();

    public class DailyHealthMetrixEntryViewModel : ViewModelBase
        {
        /// <summary>
        /// ViewModel for managing daily health metrics entries.
        /// </summary>

        private HealthMetric _newHealthMetricl = null;


        /// <summary>
        /// Delegate for closing a new window.
        /// </summary>

        public DWidnowClose NewWindowClose;

        /// <summary>
        /// Delegate for closing an edit window.
        /// </summary>
        public DWidnowClose EditWindowClose;
            private ObservableCollection<HealthMetric> _healthMetrics;

        /// <summary>
        /// Gets or sets the new health metric entry.
        /// </summary>
        public HealthMetric NewHealthMetric
            {
                get { return _newHealthMetricl; }
                set
                {
                    _newHealthMetricl = value;
                    OnPropertyChanged(nameof(NewHealthMetric));
                }
            }
            //private readonly IHealthMetricsRepo _repo;
            private IHealthMetricsRepo _repo = new EFHealthMetricsRepo();

            public ObservableCollection<HealthMetric> HealthMetrics
            {
                get
                { return _healthMetrics; }
                set
                {
                    _healthMetrics = value; OnPropertyChanged(nameof(HealthMetrics));
                }
            }
            public ICommand CreateCommand { get; }


            public DailyHealthMetrixEntryViewModel()
            {
                LoadHealthMetrics();
                CreateCommand = new RelayCommand(CreateHealthMetrics);
                //NewHealthMetric.MetricDate = DateTime.Now;
                this.NewHealthMetric = new HealthMetric
                {
                    MetricID = 101,
                    HeartRate = 0,
                    BloodPressureSystolic = 0,
                    BloodPressureDiastolic = 0,
                    ActivityLevel = 0,
                    MetricDate = DateTime.Today,
                    CreatedAt = DateTime.Now,
                    UserID = 3,
                };
            }
            public void LoadHealthMetrics()
            {
                HealthMetrics = _repo.ReadAllHealthMetrics();
            }
            public void CreateHealthMetrics()
            {
                //MessageBox.Show($"viewmodel is working..");
                HealthMetric newDailyHealthMetrixEntryViewModel = new HealthMetric
                {
                    MetricID = NewHealthMetric.MetricID,
                    HeartRate = NewHealthMetric.HeartRate,
                    BloodPressureSystolic = NewHealthMetric.BloodPressureSystolic,
                    BloodPressureDiastolic = NewHealthMetric.BloodPressureDiastolic,
                    ActivityLevel = NewHealthMetric.ActivityLevel,
                    MetricDate = NewHealthMetric.MetricDate.Date,
                    CreatedAt = DateTime.Now,
                    UserID = NewHealthMetric.UserID,

                };



                try
                {
                    var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                    caption: "Confirm",
                    button: MessageBoxButton.YesNo,
                    icon: MessageBoxImage.Question);
                    if (result != MessageBoxResult.Yes)
                    {
                        return;
                    }
                    _repo.CreateHealthMetrics(NewHealthMetric);
                    result = MessageBox.Show(messageBoxText: "Inserted Data Successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
                    LoadHealthMetrics();



                    if (NewWindowClose != null)
                    {
                        NewWindowClose();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"{ex.Message}");
                }
            }
        
        }
    }

