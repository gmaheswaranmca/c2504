﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using ProjectPHT.Commands;
using ProjectPHT.EFRepo;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.ViewModels
{
    public delegate void DWindowClose();
    public class GoalsViewModel : ViewModelBase
    {

        private ObservableCollection<Goal> _goals;
        private Goal _newGoal;
        public DWidnowClose NewWindowClose;



        public Goal NewGoal
        {
            get { return _newGoal; }
            set
            {
                _newGoal = value;
                OnPropertyChanged(nameof(NewGoal));
            }
        }

        private Goal _selectedGoal = null;

        public Goal SelectedGoal
        {
            get => _selectedGoal;
            set
            {
                _selectedGoal = value;
                OnPropertyChanged(nameof(SelectedGoal));
            }
        }




        public ObservableCollection<Goal> Goals
        {
            get
            {

                //  return _repo.ReadAllGoal();
                return _goals;


            }
            set { _goals = value; OnPropertyChanged(nameof(Goals)); }
        }

        private IGoalsRepo _repo = new EFGoalsRepo();
        public ICommand CreateCommand { get; }

        public ICommand UpdateCommand { get; }


        public ICommand DeleteCommand { get; }





        public GoalsViewModel()
        {
            LoadGoals();
            CreateCommand = new RelayCommand(CreateGoal);
            UpdateCommand = new RelayCommand(UpdateGoal);
            DeleteCommand = new RelayCommand(DeleteGoal);
            this.NewGoal = new Goal
            {

                GoalID = 3,
                UserID = 3,
                GoalType = "lower BP",
                TargetValue = 10,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now,
                Status = "active",
            };
        }

        public void LoadGoals()
        {
            Goals = _repo.ReadAllGoal();
        }
        public void CreateGoal()
        {
            try
            {
                Goal newGoal = new Goal
                {
                    GoalID = NewGoal.GoalID,
                    UserID = NewGoal.UserID,
                    GoalType = NewGoal.GoalType,
                    TargetValue = NewGoal.TargetValue,
                    StartDate = NewGoal.StartDate,
                    EndDate = NewGoal.EndDate,
                    Status = NewGoal.Status,
                };

                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                    caption: "Confirm",
                    button: MessageBoxButton.YesNo,
                    icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _repo.CreateGoal(newGoal);
                result = MessageBox.Show(messageBoxText: "Created Successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
                LoadGoals();

                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }
            }
            catch (Exception ex)
            {
                // Log the exception
                //Console.WriteLine("An error occurred: " + ex.Message);
                Logger.log.Error(ex);

                // Show an error message to the user
                MessageBox.Show(messageBoxText: "An error occurred: " + ex.Message,
                    caption: "Error",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Error);
            }
        }
        /// <summary>
        /// Updates an existing account.
        /// </summary>
        public void UpdateGoal()
        {
            try
            {

                if (this.SelectedGoal == null)
                {
                    return;
                }

                var res = MessageBox.Show(messageBoxText: "Are you sure to Update?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);

                if (res != MessageBoxResult.Yes)
                {
                    return;
                }


                _repo.UpdateGoal(this.SelectedGoal);
                this.SelectedGoal = this.SelectedGoal;
                var result = MessageBox.Show(messageBoxText: $"Goal {SelectedGoal.GoalID} is updated successfully",
                        caption: "Alert",
                        button: MessageBoxButton.OK,
                        icon: MessageBoxImage.Information);

                LoadGoals();
                Logger.log.Info("Goals updated successfully!");
            }
            catch (Exception ex)
            {
                Logger.log.Error(ex);
                MessageBox.Show(ex.StackTrace);
            }




        }

        /// <summary>
        /// Deletes an existing account.
        /// </summary>
        public void DeleteGoal()
        {
            if (this.SelectedGoal == null)
            {
                //var result1 = MessageBox.Show(messageBoxText: "Please select a goal",
                //    caption: "Alert",
                //    button: MessageBoxButton.OK,
                //    icon: MessageBoxImage.Information);
                return;
            }

            var res = MessageBox.Show(messageBoxText: "Are you sure to Delete?",
                    caption: "Confirm",
                    button: MessageBoxButton.YesNo,
                    icon: MessageBoxImage.Question);

            if (res != MessageBoxResult.Yes)
            {
                return;
            }



            _repo.DeleteGoal(this.SelectedGoal);
            this.SelectedGoal = this.SelectedGoal;
            var result = MessageBox.Show(messageBoxText: $"Goal {SelectedGoal.GoalID} is  deleted successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);

            LoadGoals();


        }


    }
}
