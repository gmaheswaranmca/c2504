﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProjectPHT.Entities;
using ProjectPHT.Repo;

namespace ProjectPHT.ViewModels
{
    public class HealthInsightViewModel
    {
        private readonly IHealthInsightsRepo _healthInsightRepo;

        public int UserID { get; set; }
        public List<HealthInsight> Insights { get; set; } = new List<HealthInsight>();
        public List<string> Suggestions { get; set; } = new List<string>();
        public List<string> Alerts { get; set; } = new List<string>();

        // Constructor
        public HealthInsightViewModel(int userId, IHealthInsightsRepo healthInsightRepo)
        {
            UserID = userId;
            _healthInsightRepo = healthInsightRepo;
            LoadData();
        }
        public HealthInsightViewModel() { }
        // Method to load insights, suggestions, and alerts
        private void LoadData()
        {
            LoadInsights();
            LoadSuggestions();
            LoadAlerts();
        }

        // Method to load insights from the repository
        private void LoadInsights()
        {
            Insights = _healthInsightRepo.GetInsightsByUserId(UserID);
        }

        // Method to load suggestions from the repository
        private void LoadSuggestions()
        {
            Suggestions = _healthInsightRepo.GetSuggestions();
        }

        // Method to load alerts from the repository
        private void LoadAlerts()
        {
            Alerts = _healthInsightRepo.GetAlerts();
        }
    }
}


