﻿create database PHTProject

use PHTProject

CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(MAX) NOT NULL,
    DateOfBirth DATE,
    Gender NVARCHAR(10),
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);


CREATE TABLE HealthMetrics (
    MetricID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    HeartRate INT,
    BloodPressureSystolic INT,
    BloodPressureDiastolic INT,
    ActivityLevel DECIMAL(5, 2),
    MetricDate DATETIME NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE()
);



CREATE TABLE HealthInsights (
    InsightID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    InsightType NVARCHAR(100) NOT NULL,
    InsightDetails NVARCHAR(MAX),
    GeneratedAt DATETIME DEFAULT GETDATE()
);


CREATE TABLE Goals (
    GoalID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    GoalType NVARCHAR(100) NOT NULL,
    TargetValue DECIMAL(10, 2) NOT NULL,
    StartDate DATETIME NOT NULL,
    EndDate DATETIME,
    Status NVARCHAR(50) DEFAULT 'Active'
);



CREATE TABLE DeviceSync (
    SyncID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    DeviceType NVARCHAR(100) NOT NULL,
    LastSyncedAt DATETIME DEFAULT GETDATE(),
    SyncStatus NVARCHAR(50) DEFAULT 'Successful'
);

CREATE TABLE HealthHistory (
    HistoryID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    MetricType NVARCHAR(50) NOT NULL,
    MetricValue DECIMAL(10, 2) NOT NULL,
    RecordedAt DATETIME NOT NULL
);

CREATE TABLE Notifications (
    NotificationID INT IDENTITY(1,1) PRIMARY KEY,
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    NotificationType NVARCHAR(100) NOT NULL,
    Message NVARCHAR(MAX) NOT NULL,
    SentAt DATETIME DEFAULT GETDATE()
);


