﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static CDMD_Project.ViewModel.TreatmentViewModel;

namespace CDMD_Project.Pages
{
    /// <summary>
    /// Interaction logic for TreatmentPlanWindow.xaml
    /// </summary>
    public partial class TreatmentPlanWindow : Window
    {
        public TreatmentPlanWindow()
        {
            InitializeComponent();
            var Viewmodel = new TreatmentPlanViewModel();
            this.DataContext = Viewmodel;
        }

    }
}
    

