﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using CDMD_Project.ViewModel;

namespace CDMD_Project.Pages
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public bool IsAdmin { get; set; } = false;
        public LoginWindow()
        {
            InitializeComponent();
            
       
            var ViewModel = new UsersViewModel();
            this.DataContext = ViewModel;
            //if(ViewModel.CurrentUser.Role.CompareTo("Admin") == 0)
            //{
            //    IsAdmin = true;
            //}

            ViewModel.WindowClose = CloseLogin;
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
        //    if (txtUsername.Text == "quest" && txtPassword.Text == "1234")
        //    {
        //        if (IsAdmin)
        //        {
        //            FormConfig.dashboardWindow.Show();
        //            this.Hide();
        //        }
        //        else
        //        {
        //            FormConfig.dashboardWindow.Show();
        //            this.Hide();
        //        }

        //    }
        //    else
        //    {
        //        MessageBox.Show(messageBoxText: $"Invalid username or password",
        //           caption: "Warning",
        //           button: MessageBoxButton.OK,
        //           icon: MessageBoxImage.Warning);
        //        return;
        //    }
        //}

        public void CloseLogin()
        {
            if (IsAdmin)
            {
                this.Hide();
                FormConfig.dashboardWindow.Show();
            }
            else
            {
                this.Hide();
                //FormConfig.dashboardWindow.Show();
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
        
    

