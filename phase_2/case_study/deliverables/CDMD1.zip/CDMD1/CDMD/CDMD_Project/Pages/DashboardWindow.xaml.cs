﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CDMD_Project.Pages
{
    /// <summary>
    /// Interaction logic for DashboardWindow.xaml
    /// </summary>
    public partial class DashboardWindow : Window
    {
        public DashboardWindow()
        {
            InitializeComponent();
        }
        private static DashboardWindow _instance;
        public static DashboardWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DashboardWindow();
                }

                return _instance;
            }

        }

        private void btnUserManager_Click(object sender, RoutedEventArgs e)
        {
            //FormConfig.userListWindow.Show();
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnPatientSearch_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.patientProfilePage.Show();
        }

        private void btnUserManager_Click_1(object sender, RoutedEventArgs e)
        {
           FormConfig.healthMetricsWindow.Show();
        }

        private void btnAppointmentManager_Click(object sender, RoutedEventArgs e)
        {
          FormConfig.treatmentPlanWindow.Show();
        }
    }
}
        
    

