﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;

namespace CDMD_Project.Repo
{
    public interface IUsersRepo
    {
        bool IsUserAuthenticated { get; set; }
        User CurrentUser { get; set; }
        void Login(User user);
        void create(User newUser);
        ObservableCollection<User> ReadAll();

        void Update(User newUser);
        void Delete(User newUser);
    }
}
