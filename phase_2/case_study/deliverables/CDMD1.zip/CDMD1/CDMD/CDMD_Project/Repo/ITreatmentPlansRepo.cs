﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;

namespace CDMD_Project.Repo
{
    public interface ITreatmentPlansRepo
    {
        void Update(TreatmentPlan treatmentPlan);
        void Create(TreatmentPlan treatmentPlan);

        Patient GetPatientByPhonenumber(string phoneNumber);
        ObservableCollection<TreatmentPlan> GetTreatmentPlansByPatientId(int patientId); // New method
    }
}
