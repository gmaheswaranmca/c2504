﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;

namespace CDMD_Project.Repo
{
    public interface IWearableRepo
    {
        void Create(WearableDevice device);
    }
}
