﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;

namespace CDMD_Project.Repo
{
    public interface IHealthRepo
    {
        //ObservableCollection<HealthMetric> ReadAll();
        //ObservableCollection<Patient>GetAllPatients();
        Patient GetPatientByPhoneNumber(string PhoneNumber);
        HealthMetric GetLatestHealthMetricByPatientId(int patientID);
        void Add(HealthMetric newHealthMetric);
        //void Add(HealthMetric healthMetric);
        //void Update(HealthMetric healthMetric);
        //void Delete(int metricId);
    }
   
}
