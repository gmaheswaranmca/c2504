﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;
using CDMD_Project.Pages;
using CDMD_Project.ViewModel;
using static CDMD_Project.ViewModel.TreatmentViewModel;

namespace CDMD_Project
{
    public static class FormConfig
    {
        public static int UserId { get; set; }

        public static LoginWindow loginWindow = null;
        public static DashboardWindow dashboardWindow = null;
        public static HealthMetricsWindow healthMetricsWindow = null;
        public static HealthMetricViewModel healthMetricViewModel = null;
        public static PatientViewModel patientViewModel = null;
        public static PatientProfilePage patientProfilePage = null;

        public static TreatmentPlanWindow treatmentPlanWindow = null;
        public static TreatmentPlanViewModel treatmentPlanViewModel = null;

        static FormConfig()
        {
            loginWindow = new LoginWindow();
            dashboardWindow = new DashboardWindow();
            healthMetricsWindow = new HealthMetricsWindow();
            healthMetricViewModel = new HealthMetricViewModel();
            patientViewModel = new PatientViewModel();
            patientProfilePage = new PatientProfilePage();
            treatmentPlanViewModel= new TreatmentPlanViewModel();
            treatmentPlanWindow=new TreatmentPlanWindow();
        }
        
    }
    
}
