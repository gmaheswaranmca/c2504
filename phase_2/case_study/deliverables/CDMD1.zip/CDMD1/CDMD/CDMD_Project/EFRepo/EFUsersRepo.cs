﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;
using CDMD_Project.Repo;

namespace CDMD_Project.EFRepo
{
    public class EFUserRepo : IUsersRepo
    {
        private static EFUserRepo _instance;
        public bool IsUserAuthenticated { get; set; }
        public User CurrentUser { get; set; } = null;
        public static EFUserRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFUserRepo();
                }
                return _instance;
            }
        }

        private CdmdDbEntities _context;



        private EFUserRepo()
        {
            _context = new CdmdDbEntities();
        }
        public void create(User newUser)
        {
            _context.Users.Add(newUser);
            _context.SaveChanges();
        }

        public void Delete(User newUser)
        {
            throw new NotImplementedException();
        }

        public ObservableCollection<User> ReadAll()
        {
            return new ObservableCollection<User>(_context.Users.ToList());
        }

        public void Update(User newUser)
        {
            throw new NotImplementedException();
        }

        public void Login(User user)
        {
            var User = _context.Users.FirstOrDefault(u => u.Email == user.Email && u.PasswordHash == user.PasswordHash);
            if (User == null)
            {
                throw new Exception("Invalid username or password");
            }
            else
            {
                CurrentUser = User;
            }

        }
    }
}
