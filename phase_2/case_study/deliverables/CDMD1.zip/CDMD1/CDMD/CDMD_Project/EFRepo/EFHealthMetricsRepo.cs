﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;
using CDMD_Project.Repo;

namespace CDMD_Project.EFRepo
{
    public class EFHealthMetricsRepo :IHealthRepo
    {
        
        
    private static EFHealthMetricsRepo _instance;
    private readonly CdmdDbEntities _context;

    private EFHealthMetricsRepo(CdmdDbEntities context)
    {
        _context = context;
    }

    public static EFHealthMetricsRepo Instance
    {
        get
        {
            if (_instance == null)
            {
                _instance = new EFHealthMetricsRepo(new CdmdDbEntities());
            }
            return _instance;
        }
    }

    public Patient GetPatientByPhoneNumber(string phoneNumber)
    {

        var queryResult = (from p in _context.Patients
                           where p.PhoneNumber.Equals(phoneNumber)
                           select p);//.Include(p => p.HealthMetrics);
        var patients = queryResult.ToList();
        var patient = queryResult.FirstOrDefault();
            //return patient;
            return _context.Patients.FirstOrDefault(p => p.PhoneNumber == phoneNumber);
        }

    public HealthMetric GetLatestHealthMetricByPatientId(int patientId)
    {
        return _context.HealthMetrics
            .Where(hm => hm.PatientID == patientId)
            .OrderByDescending(hm => hm.MetricDate)
            .FirstOrDefault();

    }

    public void Add(HealthMetric healthMetric)
    {
        _context.HealthMetrics.Add(healthMetric);
        _context.SaveChanges();
    }
}
    }



