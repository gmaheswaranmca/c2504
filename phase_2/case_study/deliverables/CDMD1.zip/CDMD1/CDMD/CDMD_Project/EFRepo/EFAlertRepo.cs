﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;
using CDMD_Project.Repo;

namespace CDMD_Project.EFRepo
{
    public class EFAlertRepo:IAlertRepo
    {
        private static EFAlertRepo _instance;
        private readonly CdmdDbEntities _context;

        private EFAlertRepo(CdmdDbEntities context)
        {
            _context = context;
        }

        public static EFAlertRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFAlertRepo(new CdmdDbEntities());
                }
                return _instance;
            }
        }
    }
}
