﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Entities;
using CDMD_Project.Repo;

namespace CDMD_Project.EFRepo
{
    public class EFTreatmentPlansRepo:ITreatmentPlansRepo
    {
        private static EFTreatmentPlansRepo _instance;
        public static EFTreatmentPlansRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFTreatmentPlansRepo();
                }

                return _instance;
            }
        }

        private CdmdDbEntities _context;

        private EFTreatmentPlansRepo()
        {
            _context = new CdmdDbEntities();
        }


        public void Create(TreatmentPlan treatmentPlan)
        {
            _context.TreatmentPlans.Add(treatmentPlan);
            _context.SaveChanges();
        }

        public void Update(TreatmentPlan treatmentPlan)
        {
            var existingTreatmentPlan = _context.TreatmentPlans.Find(treatmentPlan.PlanID);
            if (existingTreatmentPlan != null)
            {
                existingTreatmentPlan.PlanDetails = treatmentPlan.PlanDetails;
                existingTreatmentPlan.Medications = treatmentPlan.Medications;
                existingTreatmentPlan.DietPlan = treatmentPlan.DietPlan;
                existingTreatmentPlan.ExercisePlan = treatmentPlan.ExercisePlan;
                existingTreatmentPlan.FollowUpDate = treatmentPlan.FollowUpDate;
                existingTreatmentPlan.StartDate = treatmentPlan.StartDate;
                existingTreatmentPlan.EndDate = treatmentPlan.EndDate;
                _context.SaveChanges();
            }
        }

        //
        public Patient GetPatientByPhonenumber(string phoneNumber)
        {
            return _context.Patients.FirstOrDefault(p => p.PhoneNumber == phoneNumber);
        }

        public ObservableCollection<TreatmentPlan> GetTreatmentPlansByPatientId(int patientId)
        {
            var treatmentPlans = _context.TreatmentPlans.Where(tp => tp.PatientID == patientId).ToList();
            return new ObservableCollection<TreatmentPlan>(treatmentPlans);
        }
    }

}

