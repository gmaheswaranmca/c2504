﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Command;
using CDMD_Project.EFRepo;
using System.Windows.Input;
using System.Windows;
using CDMD_Project.Repo;
using CDMD_Project.Entities;
using CDMD_Project.Pages;

namespace CDMD_Project.ViewModel
{
    public delegate void DWindowClose();
    public class UsersViewModel:ViewModelBase
    {
        public DWindowClose WindowClose;
        public IUsersRepo _repo = EFUserRepo.Instance;
        private User _newUser;

        public User NewUser
        {
            get
            {
                return _newUser;
            }
            set
            {
                _newUser = value;
                OnPropertyChanged(nameof(NewUser));
            }
        }

        private User _currentUser;

        public User CurrentUser
        {
            get
            {
                return _currentUser;
            }
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));


            }
        }

        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get { return _users; }
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }
        public ICommand CreateCommand { get; set; }
        public ICommand LoginCommand { get; set; }

        public UsersViewModel()
        {
            NewUser = new User
            {
                Username = "Name",
                Email = "",
                PasswordHash = "",
                Role = "Doctor",
                CreatedAt = DateTime.Now,
                //LastLogin = DateTime.Now,

            };

            CurrentUser = new User
            {
                Email = "",
                PasswordHash = ""
            };

            LoadUsers();
            CreateCommand = new RelayCommand(Create);
            LoginCommand = new RelayCommand(Login);
        }

        public void LoadUsers()
        {
            Users = _repo.ReadAll();
        }

        public void Create()
        {

            var newUser = new User
            {
                Username = NewUser.Username,
                Email = NewUser.Email,
                PasswordHash = NewUser.PasswordHash,
                Role = NewUser.Role,
                CreatedAt = DateTime.Now,
                //LastLogin = DateTime.Now,
            };


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _repo.create(newUser);

                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);

                LoadUsers();

                if (WindowClose != null)
                {
                    WindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
        }

        public void Login()
        {
            //try
            //{
            //    _repo.Login(CurrentUser);
            //    MessageBox.Show($"Login successfull");
            //    if (WindowClose != null)
            //    {
            //        WindowClose();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"{ex.Message}");
            //}
            try
            {
                _repo.Login(CurrentUser);
                MessageBox.Show($"Login successfull");
                if (!(_repo.CurrentUser.Role.CompareTo("Admin") == 0))
                {
                    var Window = DashboardWindow.Instance;
                    Window.Show();

                }
                else
                {
                    // FormConfig.dashboardWindow.Show();
                }
                if (WindowClose != null)
                {
                    WindowClose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }



        }

        public bool CanLogin()
        {
            return CurrentUser.Email.Length > 0 && CurrentUser.PasswordHash.Length > 0;
        }

    }
}

