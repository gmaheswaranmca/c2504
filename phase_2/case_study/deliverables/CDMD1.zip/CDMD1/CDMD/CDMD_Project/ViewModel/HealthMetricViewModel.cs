﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Command;
using CDMD_Project.EFRepo;
using CDMD_Project;
using System.Windows.Input;
using System.Windows;
using CDMD_Project.Repo;
using CDMD_Project.Entities;
using System.Linq.Expressions;
using System.Diagnostics;

namespace CDMD_Project.ViewModel
{
    public class HealthMetricViewModel : ViewModelBase
    {

        private ObservableCollection<Patient> _patients; // Collection for patient data
        private HealthMetric _selectedHealthMetric; // To hold selected health metric details
        private string _patientPhoneNumber; // For searching patients
        private DateTime _lastSyncTime; // To track the last sync time for each patient
        private bool _isSyncButtonEnabled = true; // Flag to enable/disable the sync button
        private ObservableCollection<HealthMetric> _healthMetrics;

        public ObservableCollection<HealthMetric> HealthMetrics
        {
            get { return _healthMetrics; }
            set { _healthMetrics = value; OnPropertyChanged(nameof(HealthMetrics)); }
        }
        public ObservableCollection<Patient> Patients
        {
            get { return _patients; }
            set { _patients = value; OnPropertyChanged(nameof(Patients)); }
        }
        public bool IsSyncButtonEnabled
        {
            get { return _isSyncButtonEnabled; }
            set { _isSyncButtonEnabled = value; OnPropertyChanged(nameof(IsSyncButtonEnabled)); }
        }

        public string PhoneNumber
        {
            get { return _patientPhoneNumber; }
            set { _patientPhoneNumber = value; OnPropertyChanged(nameof(PhoneNumber)); }
        }

        public HealthMetric SelectedHealthMetric
        {
            get { return _selectedHealthMetric; }
            set { _selectedHealthMetric = value; OnPropertyChanged(nameof(SelectedHealthMetric)); }
        }

        public ICommand SearchCommand { get; }
        public ICommand SyncDeviceCommand { get; }

        private IHealthRepo _repo = (IHealthRepo)EFHealthMetricsRepo.Instance;

        public HealthMetricViewModel()
        {
            SearchCommand = new RelayCommand(Search);
            SyncDeviceCommand = new RelayCommand(SyncDevice);
            Patients = new ObservableCollection<Patient>(); // Initialize the patient collection
        }

        public void Search()
        {
            try
            {

                Debug.WriteLine($"Searching for patient with phone number: {PhoneNumber}");
                // Implement search logic based on PatientPhoneNumber
                var patient = _repo.GetPatientByPhoneNumber(PhoneNumber); // Implement this method
                if (patient != null)
                {
                    Patients.Clear();
                    Patients.Add(patient);
                    // Optionally load health metrics for the selected patient
                    SelectedHealthMetric = _repo.GetLatestHealthMetricByPatientId(patient.PatientID); // Implement this method
                }
                else
                {
                    MessageBox.Show("Patient not found.");
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show($"{ex.Message}");
            }

        }

        public void SyncDevice()
        {
            try
            {


                if (_isSyncButtonEnabled)
                {
                    if (SelectedHealthMetric != null)
                    {
                        // Generate random data for the wearable devices
                        var glucoseLevel = new Random().Next(80, 120);
                        var heartRate = new Random().Next(60, 100);
                        var bloodPressure = $"{new Random().Next(100, 140)}/{new Random().Next(60, 90)}";

                        // Create a new HealthMetric object with the generated data
                        var newHealthMetric = new HealthMetric
                        {
                            PatientID = SelectedHealthMetric.PatientID,
                            MetricDate = DateTime.Now,
                            BloodSugarLevel = glucoseLevel,
                            HeartRate = heartRate,
                            BloodPressure = bloodPressure,
                            LastSyncTime = DateTime.Now
                        };

                        // Save the new HealthMetric to the database
                        _repo.Add(newHealthMetric);

                        // Update the SelectedHealthMetric with the new data
                        SelectedHealthMetric = newHealthMetric;

                        // Disable the sync button for the next hour
                        _isSyncButtonEnabled = false;
                        _lastSyncTime = DateTime.Now;

                        // Start a timer to re-enable the sync button after an hour
                        var timer = new System.Timers.Timer(3600000); // 1 hour in milliseconds
                        timer.Elapsed += (sender, args) =>
                        {
                            _isSyncButtonEnabled = true;
                            timer.Stop();
                        };
                        timer.Start();
                    }
                    else
                    {
                        MessageBox.Show("Please select a patient before syncing.");
                    }
                }
                else
                {
                    MessageBox.Show("You can't sync again for another hour.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while syncing: {ex.Message}");
            }
        }
    }
}






