﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CDMD_Project.Command;
using CDMD_Project.EFRepo;
using CDMD_Project.Repo;
using System.Windows.Input;
using System.Windows;
using CDMD_Project.Entities;

namespace CDMD_Project.ViewModel
{
    public class TreatmentViewModel
    {
        public class TreatmentPlanViewModel : ViewModelBase
        {
            public ITreatmentPlansRepo _repo = EFTreatmentPlansRepo.Instance;
            private TreatmentPlan _newTreatmentPlan;

            // public string PatientPhoneNumber { get; set; }  
            // public ICommand SearchCommand { get; set; }

            public ObservableCollection<Patient> PatientDetails { get; set; } // Collection to hold patient details

            public string PatientPhoneNumber { get; set; } // Property for the phone number

            public ICommand SearchCommand { get; set; }

            public ICommand NewCommand { get; set; }
            public TreatmentPlan NewTreatmentPlan
            {
                get
                {
                    return _newTreatmentPlan;
                }
                set
                {
                    _newTreatmentPlan = value;
                    OnPropertyChanged(nameof(NewTreatmentPlan));
                }
            }

            public ICommand CreateCommand { get; set; }

            public TreatmentPlanViewModel()
            {
                NewTreatmentPlan = new TreatmentPlan
                {
                    PatientID=0,
                    PlanDetails = "",
                    Medications = "",
                    DietPlan = "",
                    ExercisePlan = "",
                    FollowUpDate = null,
                    StartDate = null,
                    EndDate = null
                };

                CreateCommand = new RelayCommand(Create);

                NewCommand = new RelayCommand(ToNew);

                PatientDetails = new ObservableCollection<Patient>();
                SearchCommand = new RelayCommand(SearchPatientByPhoneNumber);
                ToNew();
            }


            public void Create()
            {
                try
                {
                    var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                            caption: "Confirm",
                            button: MessageBoxButton.YesNo,
                            icon: MessageBoxImage.Question);
                    if (result != MessageBoxResult.Yes)
                    {
                        return;
                    }

                    _repo.Create(NewTreatmentPlan);
                

                    result = MessageBox.Show(messageBoxText: "Created Successfully",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);

                    NewTreatmentPlan = new TreatmentPlan
                    {
                        PatientID = 0,
                        PlanDetails = "",
                        Medications = "",
                        DietPlan = "",
                        ExercisePlan = "",
                        FollowUpDate = null,
                        StartDate = null,
                        EndDate = null
                    };
                    ToNew();
                    
                }
                catch (Exception ex)
                {
                    //MessageBox.Show($"{ex.InnerException}");
                    MessageBox.Show($"Error: {ex.Message}");
                }


            }

            public void ToNew()
            {

                PatientDetails.Clear();
            }

            //
            public void SearchPatientByPhoneNumber()
            {
                try
                {
                    var patient = _repo.GetPatientByPhonenumber(PatientPhoneNumber);
                    if (patient != null)
                    {
                        PatientDetails.Clear(); // Clear existing details
                        PatientDetails.Add(patient);

                    }
                    else
                    {
                        MessageBox.Show("Patient not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }



        }
    }
}
