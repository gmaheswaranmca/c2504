﻿Insert into Users(Username,PasswordHash,Email,Role)
values('neha', '2001', 'neha@gmail.com','User');


select * from Users;