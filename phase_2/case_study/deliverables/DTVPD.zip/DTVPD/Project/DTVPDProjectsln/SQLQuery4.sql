﻿INSERT INTO Users (Username, PasswordHash, Email, Role)
VALUES ('mariya', '2001', 'mariya@gmail.com', 'User');
Select * from Users;