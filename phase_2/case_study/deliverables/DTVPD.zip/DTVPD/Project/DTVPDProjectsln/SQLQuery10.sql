﻿INSERT INTO Users (Username, PasswordHash, Email, Role, CreatedAt, UpdatedAt)
VALUES
    ('admin', 'password123', 'admin@gmail.com', 'Admin', GETDATE(), GETDATE());