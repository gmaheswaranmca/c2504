﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for FeedbackWindow.xaml.
    /// This window allows users to submit feedback.
    /// </summary>
    public partial class FeedbackWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FeedbackWindow"/> class.
        /// Sets the DataContext to the feedback view model.
        /// </summary>
        public FeedbackWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.feedbackViewModel;
        }

        /// <summary>
        /// Handles the click event of the Submit Feedback button.
        /// Executes the submit command from the feedback view model and shows a success message.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnSubmitFeedBack_Click_1(object sender, RoutedEventArgs e)
        {
            ViewModelConfig.feedbackViewModel.SubmitCommand.Execute(null);
            MessageBox.Show("Feedback submitted successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closing_1(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}