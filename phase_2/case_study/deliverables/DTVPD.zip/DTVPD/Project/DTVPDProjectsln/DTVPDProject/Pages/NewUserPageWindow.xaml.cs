﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for NewUser PageWindow.xaml.
    /// This window allows the creation of a new user in the application.
    /// </summary>
    public partial class NewUserPageWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NewUser PageWindow"/> class.
        /// Sets the DataContext to the UserViewModel from the ViewModelConfig.
        /// </summary>
        public NewUserPageWindow()
        {
            InitializeComponent();
            //var ViewModel = ViewModelConfig.UserViewModel;
            this.DataContext = ViewModelConfig.UserViewModel;
            // ViewModel.WindowClose = HideWindow;
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing action and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data containing cancellation information.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true; // Prevents the window from closing
            this.Hide(); // Hides the window instead
        }

        /// <summary>
        /// Hides the new user window.
        /// </summary>
        public void HideWindow()
        {
            this.Hide();
        }
    }
}
