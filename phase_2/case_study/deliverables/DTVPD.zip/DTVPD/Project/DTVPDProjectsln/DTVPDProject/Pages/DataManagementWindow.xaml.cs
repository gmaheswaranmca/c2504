﻿using System.Collections.ObjectModel;
using System.Windows;
using DTVPDProject.Entities;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for DataManagementWindow.xaml.
    /// This window allows users to manage simulation data.
    /// </summary>
    public partial class DataManagementWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DataManagementWindow"/> class.
        /// Default constructor for the DataManagementWindow.
        /// </summary>
        public DataManagementWindow()
        {
            // Default constructor logic can be added here if needed
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataManagementWindow"/> class
        /// with a specified collection of simulations.
        /// </summary>
        /// <param name="simulations">The collection of simulations to be managed.</param>
        public DataManagementWindow(ObservableCollection<Simulation> simulations)
        {
            InitializeComponent();
            // Set the DataContext to a new instance of DataManagementViewModel with the provided simulations
            DataContext = new DataManagementViewModel(simulations);
        }
    }
}