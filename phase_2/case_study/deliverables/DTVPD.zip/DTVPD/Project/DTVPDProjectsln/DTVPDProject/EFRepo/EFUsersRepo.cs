﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Animation;
using DTVPDProject.Entities;
using DTVPDProject.Repo;

namespace DTVPDProject.EFRepo
{
    /// <summary>
    /// Repository class for managing user data in the database using Entity Framework.
    /// </summary>
    public class EFUsersRepo : IUsersRepo
    {
        private static EFUsersRepo _instance;

        /// <summary>
        /// Gets or sets the collection of users.
        /// </summary>
        public ObservableCollection<User> Users {  get; set; }

        /// <summary>
        /// Indicates whether the user is authenticated.
        /// </summary>

        public bool IsUserAuthenticated {  get; set; }


        /// <summary>
        /// Gets or sets the currently authenticated user.
        /// </summary>
        public User CurrentUser { get; set; } = null;

        /// <summary>
        /// Gets the singleton instance of the <see cref="EFUsersRepo"/> class.
        /// </summary>
        public static EFUsersRepo Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new EFUsersRepo();
                }
                return _instance;
            }
        }

        private DtvpdDbEntitiesEntities _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="EFUsersRepo"/> class.
        /// </summary>
        public EFUsersRepo()
        {
            _context = new DtvpdDbEntitiesEntities();
            Users = new ObservableCollection<User>(_context.Users.ToList());
        }

        /// <summary>
        /// Creates a new user in the database.
        /// </summary>
        /// <param name="newUser ">The user to be created.</param>
        public void Create( User newUser)
        {

            try
            {
                _context.Users.Add(newUser);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
            }
            
            
        }

        /// <summary>
        /// Deletes a user from the database.
        /// </summary>
        /// <param name="newUser ">The user to be deleted.</param>
        public void Delete(User newUser)
        {
            var UserToDelete = _context.Users.Find(newUser.UserID);
            if(UserToDelete!= null && newUser.Username != "admin")
            {
                _context.Users.Remove(UserToDelete);
                _context.SaveChanges();
            }
           

        }

        /// <summary>
        /// Reads all users from the database.
        /// </summary>
        /// <returns>A collection of users.</returns>

        public ObservableCollection<User>ReadAll()
        {
            var users = _context.Users.ToList();
            return new ObservableCollection<User>(users);
        }

        /// <summary>
        /// Updates an existing user in the database.
        /// </summary>
        /// <param name="newUser ">The user with updated information.</param>
        public void Update(User newUser)
        {
            var existingUser = Users.FirstOrDefault(a => a.Username.CompareTo(newUser.Username) == 0);
            if (existingUser != null)
            {
                existingUser.Username = newUser.Username;
                existingUser.PasswordHash = newUser.PasswordHash;
                existingUser.Email = newUser.Email;
                existingUser.Role = newUser.Role;
                existingUser.CreatedAt = newUser.CreatedAt;
                existingUser.UpdatedAt = newUser.UpdatedAt;
                _context.SaveChanges();

            }
            else
            {
                throw new NotImplementedException();

            }

        }

        /// <summary>
        /// Hashes the provided password using MD5.
        /// </summary>
        /// <param name="password">The password to hash.</param>
        /// <returns>The hashed password as a string.</returns>

        public string GetPassword(string password)
        {
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(passwordBytes);

                string inputHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                return inputHash;
            }
        }


        /// <summary>
        /// Authenticates a user by checking their email and password.
        /// </summary>
        /// <param name="user">The user to authenticate.</param>
        /// 
        public void Login(User user)
        {
            var HashedPassword = GetPassword(user.PasswordHash);
            var User = _context.Users.FirstOrDefault(u => u.Email == user.Email && u.PasswordHash == user.PasswordHash);// HashedPassword);//
                if (User == null)
                {
                    throw new Exception("Invalid username or password");
                }
                else
                {
                    CurrentUser = User;
                }
          
        }
    }
}
