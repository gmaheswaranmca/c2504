﻿using System;
using System.Windows;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for UserManagementWindow.xaml.
    /// This window manages user accounts, allowing for adding, editing, and deleting users.
    /// </summary>
    public partial class UserManagementWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="User ManagementWindow"/> class.
        /// Sets the DataContext to the UserViewModel for data binding.
        /// </summary>
        public UserManagementWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.UserViewModel; // Set the DataContext for data binding
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing action and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data containing cancellation information.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true; // Prevents the window from closing
            this.Hide(); // Hides the window instead
        }

        /// <summary>
        /// Handles the click event for the Add User button.
        /// Displays the new user page window for adding a new user.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.newUserPageWindow.Show(); // Show the new user page window
        }

        /// <summary>
        /// Handles the click event for the Edit button.
        /// Displays the update user window if a user is selected.
        /// Prompts the user to select an account if none is selected.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (grdUsers.SelectedIndex == -1)
            {
                var result = MessageBox.Show(messageBoxText: "Please select an account",
                    caption: "Confirm",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
                return; // Exit if no user is selected
            }
            FormConfig.updateUserWindow.Show(); // Show the update user window

            UpdateUserWindow newEditWindow = (UpdateUserWindow)FormConfig.updateUserWindow;
            // Additional logic for handling the edit window can be added here
        }

        /// <summary>
        /// Handles the click event for the Delete button.
        /// Deletes the selected user if one is selected.
        /// Prompts the user to select an account if none is selected.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (grdUsers.SelectedIndex == -1)
            {
                var result = MessageBox.Show(messageBoxText: "Please select an account",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
                return; // Exit if no user is selected
            }
            ViewModelConfig.UserViewModel.Delete(); // Call the delete method on the UserViewModel
        }
    }
}