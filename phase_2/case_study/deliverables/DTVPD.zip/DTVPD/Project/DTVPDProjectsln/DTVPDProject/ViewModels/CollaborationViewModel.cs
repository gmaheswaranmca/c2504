﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using DTVPDProject.Entities;
using DTVPDProject.EFRepo;
using DTVPDProject.Commands;
using log4net;

namespace DTVPDProject.ViewModels
{
    public class CollaborationViewModel : ViewModelBase
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(CollaborationViewModel));
        private readonly EFCollaborationRepo _collaborationRepo;

        public CollaborationViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net
            _collaborationRepo = new EFCollaborationRepo();
            LoadCollaborations();
        }

        private ObservableCollection<Collaboration> _collaborations;
        public ObservableCollection<Collaboration> Collaborations
        {
            get { return _collaborations; }
            set { _collaborations = value; OnPropertyChanged(nameof(Collaborations)); }
        }

        private Collaboration _selectedCollaboration;
        public Collaboration SelectedCollaboration
        {
            get { return _selectedCollaboration; }
            set { _selectedCollaboration = value; OnPropertyChanged(nameof(SelectedCollaboration)); }
        }

        private string _twinId;
        public string TwinId
        {
            get { return _twinId; }
            set { _twinId = value; }
        }

        private string _userId;
        public string UserId
        {
            get { return _userId; }
            set { _userId = value; }
        }

        private string _comment;
        public string Comment
        {
            get { return _comment; }
            set { _comment = value; }
        }

        public ICommand AddCollaborationCommand { get; set; }
        public ICommand RemoveCollaborationCommand { get; set; }

        private void LoadCollaborations()
        {
            Logger.Info("Loading collaborations from the repository.");
            Collaborations = _collaborationRepo.GetAllCollaborations();
            Logger.Info($"Loaded {Collaborations.Count} collaborations.");
        }

        public void AddCollaboration(Collaboration collaboration)
        {
            try
            {
                Logger.Info("Adding a new collaboration.");
                _collaborationRepo.AddCollaboration(collaboration);
                LoadCollaborations();
                Logger.Info("Collaboration added successfully.");
            }
            catch (Exception ex)
            {
                Logger.Error("Error adding collaboration.", ex);
            }
        }

        public void RemoveCollaboration()
        {
            if (SelectedCollaboration != null)
            {
                try
                {
                    Logger.Info($"Removing collaboration with ID: {SelectedCollaboration.CollaborationID}");
                    _collaborationRepo.DeleteCollaboration(SelectedCollaboration.CollaborationID);
                    LoadCollaborations();
                    Logger.Info("Collaboration removed successfully.");
                }
                catch (Exception ex)
                {
                    Logger.Error("Error removing collaboration.", ex);
                }
            }
            else
            {
                Logger.Warn("Attempted to remove a collaboration, but none was selected.");
            }
        }
    }
}