﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using log4net;

namespace DTVPDProject.ViewModels
{
    public class HelpAndSupportViewModel : INotifyPropertyChanged
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(HelpAndSupportViewModel));

        // FAQs collection
        public ObservableCollection<string> FAQs { get; set; }

        // Guides collection
        public ObservableCollection<string> Guides { get; set; }

        // Tutorials collection
        public ObservableCollection<string> Tutorials { get; set; }

        public HelpAndSupportViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net

            // Sample data for FAQs
            FAQs = new ObservableCollection<string>
            {
                "What is a digital twin?",
                "How do I set up the product visualization?",
                "How can I run a simulation?"
            };

            // Sample data for Guides
            Guides = new ObservableCollection<string>
            {
                "Guide 1: Setting up your project",
                "Guide 2: Configuring simulations",
                "Guide 3: Visualization options"
            };

            // Sample data for Tutorials
            Tutorials = new ObservableCollection<string>
            {
                "Tutorial 1: Introduction to Digital Twins",
                "Tutorial 2: Creating a new simulation",
                "Tutorial 3: Analyzing simulation results"
            };

            Logger.Info("Help and Support ViewModel initialized with sample data.");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}