﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for ActiveSimulationWindow.xaml
    /// </summary>
    public partial class ActiveSimulationWindow : Window
    {
        public ActiveSimulationWindow()
        {
            InitializeComponent();
        }
    }
}
