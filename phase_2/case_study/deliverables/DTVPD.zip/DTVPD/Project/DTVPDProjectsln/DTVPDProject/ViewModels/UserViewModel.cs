﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using DTVPDProject.Commands;
using DTVPDProject.Entities;
using DTVPDProject.EFRepo;
using log4net;
using DTVPDProject.Repo;

namespace DTVPDProject.ViewModels
{
    public delegate void DWindowClose();

    public class UserViewModel : ViewModelBase
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(UserViewModel));
        public DWindowClose WindowClose;
        public IUsersRepo _repo = EFUsersRepo.Instance;
        private User _newUser;

        public User NewUser
        {
            get => _newUser;
            set
            {
                _newUser = value;
                OnPropertyChanged(nameof(NewUser));
            }
        }

        private User _currentUser;
        public User CurrentUser
        {
            get => _currentUser;
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
            }
        }

        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand LoginCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        public UserViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net

            NewUser = new User
            {
                Username = "Name",
                Email = "",
                PasswordHash = "",
                Role = "User ",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
            };

            CurrentUser = new User
            {
                Email = "",
                PasswordHash = ""
            };

            LoadUsers();
            CreateCommand = new RelayCommand(Create);
            LoginCommand = new RelayCommand(Login);
            UpdateCommand = new RelayCommand(Update);
            DeleteCommand = new RelayCommand(Delete);

            Logger.Info("User ViewModel initialized.");
        }

        public void LoadUsers()
        {
            Users = _repo.ReadAll();
            Logger.Info("Users loaded.");
        }

        public void Create()
        {
            var newUser = new User
            {
                Username = NewUser.Username,
                Email = NewUser.Email,
                PasswordHash = NewUser.PasswordHash,
                Role = NewUser.Role,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
            };

            try
            {
                var result = MessageBox.Show("Are you sure to create?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.No)
                {
                    return;
                }

                _repo.Create(newUser);
                MessageBox.Show("Created Successfully!!", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
                Logger.Info($"User  {newUser.Username} created successfully.");

                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error creating user: " + ex.StackTrace);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        public void Login()
        {
            try
            {
                _repo.Login(CurrentUser);
                MessageBox.Show("Logged in Successfully");
                Logger.Info($"User  {CurrentUser.Email} logged in.");

                if (CurrentUser.Email == "admin@gmail.com")
                {
                    FormConfig.userManagementWindow.Show();
                }
                else
                {
                    FormConfig.homeDashboardWindow.Show();
                }

                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error logging in: " + ex.StackTrace);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        public void Delete()
        {
            if (this.CurrentUser == null)
            {
                MessageBox.Show("Please select an account", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var res = MessageBox.Show("Are you sure to delete?", "Alert", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (res != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                _repo.Delete(this.CurrentUser);
                this.CurrentUser = this.CurrentUser;
                MessageBox.Show($"Account {CurrentUser.Username} is deleted successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
                Logger.Info($"Account {CurrentUser.Username} is deleted successfully.");

                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error deleting user: " + ex.StackTrace);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        public void Update()
        {
            if (this.CurrentUser == null)
            {
                return;
            }

            try
            {
                _repo.Update(this.CurrentUser);
                this.CurrentUser = this.CurrentUser;
                MessageBox.Show($"Account {CurrentUser.Username} is updated successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
                Logger.Info($"Account {CurrentUser.Username} is updated successfully.");

                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error updating user: " + ex.StackTrace);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }
    }
}