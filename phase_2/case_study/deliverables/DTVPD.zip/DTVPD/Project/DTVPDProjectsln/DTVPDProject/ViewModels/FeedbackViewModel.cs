﻿using DTVPDProject.Commands;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using log4net;

namespace DTVPDProject.ViewModels
{
    public class FeedbackViewModel : INotifyPropertyChanged
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(FeedbackViewModel));
        private string _rating;
        private string _feedback;
        private string _easeOfUse;
        private string _openEndedQuestion;

        public string Rating
        {
            get { return _rating; }
            set { _rating = value; OnPropertyChanged(); }
        }

        public string Feedback
        {
            get { return _feedback; }
            set { _feedback = value; OnPropertyChanged(); }
        }

        public string EaseOfUse
        {
            get { return _easeOfUse; }
            set { _easeOfUse = value; OnPropertyChanged(); }
        }

        public string OpenEndedQuestion
        {
            get { return _openEndedQuestion; }
            set { _openEndedQuestion = value; OnPropertyChanged(); }
        }

        public ICommand SubmitCommand { get; set; }

        public FeedbackViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net
            SubmitCommand = new RelayCommand(SubmitFeedback);
        }

        private void SubmitFeedback()
        {
            try
            {
                // Handle feedback submission logic here
                // For example, you can save the feedback to a database or send it via email
                Logger.Info("Feedback submitted:");
                Logger.Info($"Rating: {Rating}");
                Logger.Info($"Feedback: {Feedback}");
                Logger.Info($"Ease of use: {EaseOfUse}");
                Logger.Info($"Open-ended question: {OpenEndedQuestion}");

                Console.WriteLine("Feedback submitted:");
                Console.WriteLine($"Rating: {Rating}");
                Console.WriteLine($"Feedback: {Feedback}");
                Console.WriteLine($"Ease of use: {EaseOfUse}");
                Console.WriteLine($"Open-ended question: {OpenEndedQuestion}");
            }
            catch (Exception ex)
            {
                Logger.Error("Error submitting feedback.", ex);
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action _execute;
        private readonly Func<bool> _canExecute;

        public RelayCommand(Action execute, Func<bool> canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute();
        }

        public void Execute(object parameter)
        {
            _execute();
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }
}