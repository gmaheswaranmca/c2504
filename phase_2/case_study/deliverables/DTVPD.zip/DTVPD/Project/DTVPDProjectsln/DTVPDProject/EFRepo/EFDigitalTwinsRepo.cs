﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using DTVPDProject.Entities;
using DTVPDProject.Repo;

namespace DTVPDProject.EFRepo
{
    /// <summary>
    /// Repository class for managing digital twins in the database.
    /// Implements the IDigitalTwinsRepo interface.
    /// </summary>
    public class EFDigitalTwinsRepo : IDigitalTwinsRepo
    {
        private readonly DtvpdDbEntitiesEntities _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="EFDigitalTwinsRepo"/> class.
        /// </summary>
        public EFDigitalTwinsRepo()
        {
            _context = new DtvpdDbEntitiesEntities();
        }

        /// <summary>
        /// Retrieves all digital twins from the database.
        /// </summary>
        /// <returns>An ObservableCollection of <see cref="DigitalTwin"/> objects.</returns>
        public ObservableCollection<DigitalTwin> ReadAll()
        {
            return new ObservableCollection<DigitalTwin>(_context.DigitalTwins.ToList());
        }

        /// <summary>
        /// Retrieves a digital twin by its ID.
        /// </summary>
        /// <param name="twinID">The ID of the digital twin to retrieve.</param>
        /// <returns>The <see cref="DigitalTwin"/> object with the specified ID, or null if not found.</returns>
        public DigitalTwin GetDigitalTwinById(int twinID)
        {
            return _context.DigitalTwins.Find(twinID);
        }

        /// <summary>
        /// Creates a new digital twin in the database.
        /// </summary>
        /// <param name="digitalTwin">The <see cref="DigitalTwin"/> object to create.</param>
        public void Create(DigitalTwin digitalTwin)
        {
            _context.DigitalTwins.Add(digitalTwin);
            _context.SaveChanges();
        }

        /// <summary>
        /// Updates an existing digital twin in the database.
        /// </summary>
        /// <param name="digitalTwin">The <see cref="DigitalTwin"/> object with updated values.</param>
        public void Update(DigitalTwin digitalTwin)
        {
            var existingDigitalTwin = _context.DigitalTwins.Find(digitalTwin.TwinID);
            if (existingDigitalTwin != null)
            {
                _context.Entry(existingDigitalTwin).CurrentValues.SetValues(digitalTwin);
                _context.SaveChanges();
            }
        }

        /// <summary>
        /// Deletes a digital twin from the database by its ID.
        /// </summary>
        /// <param name="twinID">The ID of the digital twin to delete.</param>
        public void Delete(int twinID)
        {
            var digitalTwin = _context.DigitalTwins.Find(twinID);
            if (digitalTwin != null)
            {
                _context.DigitalTwins.Remove(digitalTwin);
                _context.SaveChanges();
            }
        }

        /// <summary>
        /// Retrieves a digital twin by its ID (not implemented).
        /// </summary>
        /// <param name="TwinID">The ID of the digital twin to retrieve.</param>
        /// <returns>Throws <see cref="NotImplementedException"/>.</returns>
        public DigitalTwin GetTwinById(int TwinID)
        {
            throw new NotImplementedException();
        }
    }
}