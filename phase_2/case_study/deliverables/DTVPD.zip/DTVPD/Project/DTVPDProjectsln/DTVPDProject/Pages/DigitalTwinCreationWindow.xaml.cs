﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for DigitalTwinCreationWindow.xaml.
    /// This window allows users to create and manage digital twins.
    /// </summary>
    public partial class DigitalTwinCreationWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DigitalTwinCreationWindow"/> class.
        /// Sets the DataContext to the digital twin creation view model.
        /// </summary>
        public DigitalTwinCreationWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.digitalTwinCreationViewModel;
            // LoadAllDigitalTwin(); // Uncomment to load all digital twins
            // grdDigitalTwin.ItemsSource = AllDigitalTwin; // Uncomment to set the data source for the grid
        }

        // Uncomment if needed for loading digital twins
        // public ObservableCollection<DigitalTwin> AllDigitalTwin { get; set; }

        // Uncomment if needed for loading digital twins
        // public void LoadAllDigitalTwin()
        // {
        //     var context = new DtvpdDbEntities();
        //     AllDigitalTwin = new ObservableCollection<DigitalTwin>(context.DigitalTwins.ToList());
        // }

        /// <summary>
        /// Handles the click event of the Create button. 
        /// Opens the create list window for adding new digital twins.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnCreate_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.createListWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Edit button. 
        /// Opens the edit list window if a digital twin is selected.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (grdDigitalTwin.SelectedIndex == -1)
            {
                var result = MessageBox.Show(messageBoxText: "Please select an account to edit",
                    caption: "Alert",
                    button: MessageBoxButton.OK,
                    icon: MessageBoxImage.Information);
                return;
            }
            FormConfig.editListWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Simulation button. 
        /// Opens the simulation management window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnSimulation_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.simulationManagementWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Collaborators button. 
        /// Opens the collaboration window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnCollaborators_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.collaborationWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Iterations button. 
        /// Opens the design iteration window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnIterations_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.designIterationWindow.Show();
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}