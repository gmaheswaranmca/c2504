﻿using System;
using System.ComponentModel;

public class Simulation : INotifyPropertyChanged
{
    private int _simulationID;
    public int SimulationID
    {
        get { return _simulationID; }
        set
        {
            _simulationID = value;
            OnPropertyChanged(nameof(SimulationID));
        }
    }

    private string _imagePath;
    public string ImagePath
    {
        get { return _imagePath; }
        set
        {
            _imagePath = value;
            OnPropertyChanged(nameof(ImagePath));
        }
    }

    private string _status;
    public string Status
    {
        get { return _status; }
        set
        {
            _status = value;
            OnPropertyChanged(nameof(Status));
        }
    }

    private string _result;
    public string Result
    {
        get { return _result; }
        set
        {
            _result = value;
            OnPropertyChanged(nameof(Result));
        }
    }

    private string _designSpecifications;
    public string DesignSpecifications
    {
        get { return _designSpecifications; }
        set
        {
            _designSpecifications = value;
            OnPropertyChanged(nameof(DesignSpecifications));
        }
    }

    private string _simulationParameters;
    public string SimulationParameters
    {
        get { return _simulationParameters; }
        set
        {
            _simulationParameters = value;
            OnPropertyChanged(nameof(SimulationParameters));
        }
    }

    private DateTime _updatedAt;
    public DateTime UpdatedAt
    {
        get { return _updatedAt; }
        set
        {
            _updatedAt = value;
            OnPropertyChanged(nameof(UpdatedAt));
        }
    }

    public event PropertyChangedEventHandler PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}