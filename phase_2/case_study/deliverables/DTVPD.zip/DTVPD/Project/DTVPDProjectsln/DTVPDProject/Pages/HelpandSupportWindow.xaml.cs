﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for HelpandSupportWindow.xaml.
    /// This window provides help and support information to users.
    /// </summary>
    public partial class HelpandSupportWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="HelpandSupportWindow"/> class.
        /// Sets the DataContext to the help view model.
        /// </summary>
        public HelpandSupportWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.helpViewModel;
        }
    }
}