﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for UpdateUserWindow.xaml
    /// </summary>
    public partial class UpdateUserWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateUser Window"/> class.
        /// Sets the DataContext to the UserViewModel for data binding.
        /// </summary>
        public UpdateUserWindow()
        {
            InitializeComponent();
            //var ViewModel = ViewModelConfig.UserViewModel;
            this.DataContext = ViewModelConfig.UserViewModel;
            
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing action and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data containing cancellation information.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        /// <summary>
        /// Hides the update user window.
        /// </summary>
        public void HideWindow()
        {
            this.Hide();
        }
    }
}
