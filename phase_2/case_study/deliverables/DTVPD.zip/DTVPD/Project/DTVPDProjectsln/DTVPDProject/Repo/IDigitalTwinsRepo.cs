﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTVPDProject.Entities
{
    /// <summary>
    /// Interface for managing digital twins in the system.
    /// </summary>
    public interface IDigitalTwinsRepo
    {
        /// <summary>
        /// Retrieves all digital twins.
        /// </summary>
        /// <returns>A collection of digital twins.</returns>
        ObservableCollection<DigitalTwin> ReadAll();

        /// <summary>
        /// Retrieves a digital twin by its unique identifier.
        /// </summary>
        /// <param name="TwinID">The unique identifier of the digital twin.</param>
        /// <returns>The digital twin associated with the specified identifier.</returns>
        DigitalTwin GetTwinById(int TwinID);

        /// <summary>
        /// Creates a new digital twin in the system.
        /// </summary>
        /// <param name="digitalTwin">The digital twin to be created.</param>
        void Create(DigitalTwin digitalTwin);

        /// <summary>
        /// Updates an existing digital twin in the system.
        /// </summary>
        /// <param name="digitalTwin">The digital twin with updated information.</param>
        void Update(DigitalTwin digitalTwin);

        /// <summary>
        /// Deletes a digital twin from the system by its unique identifier.
        /// </summary>
        /// <param name="TwinID">The unique identifier of the digital twin to be deleted.</param>
        void Delete(int TwinID);
    }
}