﻿using System.Data.Entity;

namespace DTVPDProject.EFRepo
{
    public class MyDbContext : DbContext
    {
        public MyDbContext() : base("name=DtvpdDbEntities")
        {
            // Configure database connection string in the app.config or web.config
        }

        public DbSet<Simulation> Simulations { get; set; } // Set for Simulation entities
    }
}
