﻿using DTVPDProject.Commands;
using DTVPDProject.Entities;
using DTVPDProject.Pages;
using DTVPDProject.Repo;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using log4net;

namespace DTVPDProject.ViewModels
{
    public class SimulationManagementViewModel : INotifyPropertyChanged
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(SimulationManagementViewModel));
        private readonly EFSimulationsRepo _simulationsRepo;
        private Simulation _selectedSimulation;
        private bool _isSucceeded;
        private bool _isFailed;

        public ObservableCollection<Simulation> Simulations { get; set; }

        public SimulationManagementViewModel(EFSimulationsRepo simulationsRepo)
        {
            _simulationsRepo = simulationsRepo;
            Simulations = new ObservableCollection<Simulation>(_simulationsRepo.GetSimulations());
            UpdateStatusCommand = new RelayCommand(UpdateStatus);
            StartCommand = new RelayCommand(Start);
            StopCommand = new RelayCommand(Stop);
            AddSimulationCommand = new RelayCommand(AddSimulation);
            SubmitCommand = new RelayCommand(Submit);
            UpdateSimulationResultCommand = new RelayCommand(OpenDataManagementWindow);

            Logger.Info("Simulation Management ViewModel initialized.");
        }

        public Simulation SelectedSimulation
        {
            get => _selectedSimulation;
            set
            {
                _selectedSimulation = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CanSubmit));
            }
        }

        public bool IsSucceeded
        {
            get => _isSucceeded;
            set
            {
                _isSucceeded = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CanSubmit));
            }
        }

        public bool IsFailed
        {
            get => _isFailed;
            set
            {
                _isFailed = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(CanSubmit));
            }
        }

        public ICommand UpdateStatusCommand { get; }
        public ICommand StartCommand { get; }
        public ICommand StopCommand { get; }
        public ICommand AddSimulationCommand { get; }
        public ICommand SubmitCommand { get; }
        public ICommand UpdateSimulationResultCommand { get; }

        public bool CanSubmit => SelectedSimulation != null && (IsSucceeded || IsFailed);

        private void UpdateStatus()
        {
            Logger.Info("UpdateStatus command executed.");
            // Implementation for updating status
        }

        private void Start()
        {
            if (SelectedSimulation != null)
            {
                SelectedSimulation.Status = "Started";
                _simulationsRepo.UpdateSimulation(SelectedSimulation);
                _simulationsRepo.SaveChanges();
                Logger.Info($"Simulation {SelectedSimulation.SimulationID} started.");
            }
        }

        private void Stop()
        {
            if (SelectedSimulation != null)
            {
                SelectedSimulation.Status = "Stopped";
                _simulationsRepo.UpdateSimulation(SelectedSimulation);
                _simulationsRepo.SaveChanges();
                Logger.Info($"Simulation {SelectedSimulation.SimulationID} stopped.");
            }
        }

        private void Submit()
        {
            if (SelectedSimulation != null)
            {
                if (IsSucceeded)
                {
                    SelectedSimulation.Result = "Succeeded";
                }
                else if (IsFailed)
                {
                    SelectedSimulation.Result = "Failed";
                }

                _simulationsRepo.UpdateSimulation(SelectedSimulation);
                _simulationsRepo.SaveChanges();
                Logger.Info($"Simulation {SelectedSimulation.SimulationID} submitted with result: {SelectedSimulation.Result}");
            }
        }

        private void AddSimulation()
        {
            try
            {
                Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
                openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";
                openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

                if (openFileDialog.ShowDialog() == true)
                {
                    string imagePath = openFileDialog.FileName;

                    if (!IsImageFile(imagePath))
                    {
                        MessageBox.Show("Please select a valid image file.");
                        return;
                    }

                    Simulation simulation = new Simulation
                    {
                        ImagePath = imagePath,
                        Status = "New",
                        UpdatedAt = DateTime.Now
                    };

                    _simulationsRepo.AddSimulation(simulation);
                    _simulationsRepo.SaveChanges();
                    Simulations.Add(simulation);
                    Logger.Info($"Simulation {simulation.SimulationID} added.");
                }
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        Logger.Error($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                        MessageBox.Show($"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}");
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Error("An error occurred while adding the simulation: " + ex.StackTrace);
                MessageBox.Show("An error occurred while adding the simulation: " + ex.StackTrace);
            }
        }

        private void OpenDataManagementWindow()
        {
            DataManagementWindow dataManagementWindow = new DataManagementWindow(Simulations);
            dataManagementWindow.ShowDialog();
            Logger.Info("Data Management Window opened.");
        }

        private bool IsImageFile(string filePath)
        {
            string extension = Path.GetExtension(filePath).ToLower();
            return extension == ".jpg" || extension == ".jpeg" || extension == ".png";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}