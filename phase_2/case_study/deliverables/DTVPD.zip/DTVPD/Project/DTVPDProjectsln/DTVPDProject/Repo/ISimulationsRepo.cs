﻿using System.Collections;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using DTVPDProject.Entities;
using System.Collections.Generic;

namespace DTVPDProject.Repo
{
    /// <summary>
    /// Interface for managing simulations in the system.
    /// </summary>
    public interface ISimulationsRepo
    {
        /// <summary>
        /// Fetches all simulations.
        /// </summary>
        /// <returns>An enumerable collection of simulations.</returns>
        IEnumerable<Simulation> GetSimulations();

        /// <summary>
        /// Retrieves a simulation by its unique identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the simulation.</param>
        /// <returns>The simulation associated with the specified identifier.</returns>
        Simulation GetSimulationById(int id);

        /// <summary>
        /// Adds a new simulation to the system.
        /// </summary>
        /// <param name="simulation">The simulation to be added.</param>
        void AddSimulation(Simulation simulation);

        /// <summary>
        /// Updates an existing simulation in the system.
        /// </summary>
        /// <param name="simulation">The simulation with updated information.</param>
        void UpdateSimulation(Simulation simulation);

        /// <summary>
        /// Saves changes made to the simulations in the system.
        /// </summary>
        void SaveChanges();
    }
}