﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for CreateListWindow.xaml.
    /// This window allows users to create a new digital twin list.
    /// </summary>
    public partial class CreateListWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateListWindow"/> class.
        /// Sets the DataContext to the digital twin creation view model and assigns the close method.
        /// </summary>
        public CreateListWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.digitalTwinCreationViewModel;

            // Assign the HideWindow method to the NewWindowClose property of the view model
            ViewModelConfig.digitalTwinCreationViewModel.NewWindowClose = HideWindow;
        }

        /// <summary>
        /// Hides the window without closing it.
        /// </summary>
        public void HideWindow()
        {
            this.Hide();
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}