﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTVPDProject.Entities;

namespace DTVPDProject.Repo
{
    /// <summary>
    /// Interface for managing simulation results in the system.
    /// </summary>
    internal interface ISimulationResultsRepo
    {
        /// <summary>
        /// Retrieves all simulation results.
        /// </summary>
        /// <returns>A list of simulation results.</returns>
        List<SimulationResult> GetAllSimulationResults();

        /// <summary>
        /// Retrieves a simulation result by its unique identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the simulation result.</param>
        /// <returns>The simulation result associated with the specified identifier.</returns>
        SimulationResult GetSimulationResultById(int id);

        /// <summary>
        /// Updates an existing simulation result in the system.
        /// </summary>
        /// <param name="simulationResult">The simulation result with updated information.</param>
        void UpdateSimulationResult(SimulationResult simulationResult);

        /// <summary>
        /// Adds a new simulation result to the system.
        /// </summary>
        /// <param name="simulationResult">The simulation result to be added.</param>
        void AddSimulationResult(SimulationResult simulationResult);

        /// <summary>
        /// Deletes a simulation result from the system by its unique identifier.
        /// </summary>
        /// <param name="id">The unique identifier of the simulation result to be deleted.</param>
        void DeleteSimulationResult(int id);
    }
}