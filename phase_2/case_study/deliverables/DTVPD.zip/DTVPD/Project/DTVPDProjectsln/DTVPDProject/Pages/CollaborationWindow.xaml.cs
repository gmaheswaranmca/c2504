﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DTVPDProject.EFRepo;
using DTVPDProject.Entities;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for CollaborationWindow.xaml.
    /// This window allows users to manage collaborations.
    /// </summary>
    public partial class CollaborationWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CollaborationWindow"/> class.
        /// Sets the DataContext to the collaboration view model.
        /// </summary>
        public CollaborationWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.collaborationViewModel;
        }

        /// <summary>
        /// Hides the window without closing it.
        /// </summary>
        public void WindowClose()
        {
            this.Hide();
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closing_1(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        /// <summary>
        /// Handles the click event of the Add button. 
        /// Creates a new collaboration and adds it to the view model.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = this.DataContext as CollaborationViewModel;

            // Check if the DataContext is valid
            if (viewModel != null)
            {
                // Create a new Collaboration instance
                var newCollaboration = new Collaboration
                {
                    TwinID = int.TryParse(txtTwinID.Text, out int twinId) ? (int?)twinId : null,
                    UserID = int.TryParse(txtUserID.Text, out int userId) ? (int?)userId : null,
                    Comment = txtComment.Text,
                    CreatedAt = DateTime.Now // Set the current date and time
                };

                // Call the AddCollaboration method in the ViewModel
                viewModel.AddCollaboration(newCollaboration);

                // Optionally, clear the input fields after adding
                txtTwinID.Clear();
                txtUserID.Clear();
                txtComment.Clear();
            }
        }

        /// <summary>
        /// Handles the click event of the Remove Collaboration button. 
        /// Removes the selected collaboration from the view model.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnRemoveCollaboration_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = this.DataContext as CollaborationViewModel;

            // Check if the DataContext is valid
            if (viewModel != null)
            {
                // Call the RemoveCollaboration method in the ViewModel
                viewModel.RemoveCollaboration();
            }
        }
    }
}