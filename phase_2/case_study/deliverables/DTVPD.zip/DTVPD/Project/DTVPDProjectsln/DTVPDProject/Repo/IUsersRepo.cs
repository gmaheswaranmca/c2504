﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTVPDProject.Entities;

namespace DTVPDProject.Repo
{
    /// <summary>
    /// Interface for managing user authentication and user data in the system.
    /// </summary>
    public interface IUsersRepo
    {
        /// <summary>
        /// Gets or sets a value indicating whether the current user is authenticated.
        /// </summary>
        bool IsUserAuthenticated { get; set; }

        /// <summary>
        /// Gets or sets the currently logged-in user.
        /// </summary>
        User CurrentUser { get; set; }

        /// <summary>
        /// Authenticates a user and logs them into the system.
        /// </summary>
        /// <param name="user">The user to be authenticated.</param>
        void Login(User user);

        /// <summary>
        /// Creates a new user in the system.
        /// </summary>
        /// <param name="newUser ">The user to be created.</param>
        void Create(User newUser);

        /// <summary>
        /// Retrieves all users in the system.
        /// </summary>
        /// <returns>An observable collection of users.</returns>

        ObservableCollection<User> ReadAll();

        /// <summary>
        /// Updates an existing user in the system.
        /// </summary>
        /// <param name="newUser ">The user with updated information.</param>
        void Update(User newUser);

        /// <summary>
        /// Deletes a user from the system.
        /// </summary>
        /// <param name="newUser ">The user to be deleted.</param>
        void Delete(User newUser);
    }
}
