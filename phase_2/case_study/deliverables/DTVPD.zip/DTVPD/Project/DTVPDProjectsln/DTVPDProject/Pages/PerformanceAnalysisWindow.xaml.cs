﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;
using System.Windows.Media.Media3D;
using HelixToolkit.Wpf;
using DTVPDProject.ViewModels;
using System.Collections.ObjectModel;
using LiveCharts.Definitions.Charts;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for PerformanceAnalysisPageWindow.xaml.
    /// This window provides performance analysis visualizations using charts and 3D models.
    /// </summary>
    public partial class PerformanceAnalysisWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="PerformanceAnalysisWindow"/> class.
        /// Sets the DataContext to the performance view model for data binding.
        /// </summary>
        public PerformanceAnalysisWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.performanceViewModel; // Set ViewModel as DataContext
        }

        /// <summary>
        /// Handles the click event for the Line Chart button.
        /// Displays a line chart with example data.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnLineChartPerformance_Click(object sender, RoutedEventArgs e)
        {
            // Example data for the line chart
            var values = new ChartValues<double> { 3, 5, 7, 4 };
            var lineSeries = new LineSeries
            {
                Title = "Line Chart",
                Values = values
            };
            cartesianChart.Series.Clear();
            cartesianChart.Series.Add(lineSeries);
        }

        /// <summary>
        /// Handles the click event for the Bar Chart button.
        /// Displays a bar chart with example data.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnBarChartPerformance_Click(object sender, RoutedEventArgs e)
        {
            // Example data for the bar chart
            var values = new ChartValues<double> { 4, 6, 3, 8 };
            var barSeries = new ColumnSeries
            {
                Title = "Bar Chart",
                Values = values
            };
            cartesianChart.Series.Clear();
            cartesianChart.Series.Add(barSeries);
        }

        /// <summary>
        /// Handles the click event for the 3D Performance button.
        /// Displays a simple 3D cube in the viewport.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnThreeDPerformance_Click(object sender, RoutedEventArgs e)
        {
            // Clear previous 3D content
            viewport.Children.Clear();

            // Create a 3D mesh (example: a simple cube)
            var meshBuilder = new MeshBuilder();

            // Define the vertices of the cube
            meshBuilder.AddBox(new Point3D(0, 0, 0), 1, 1, 1);

            // Create the mesh geometry
            var mesh = meshBuilder.ToMesh();

            // Create a material for the cube
            var material = new DiffuseMaterial(new SolidColorBrush(Colors.Blue));

            // Create a model visual for the cube
            var model = new GeometryModel3D
            {
                Geometry = mesh,
                Material = material
            };

            // Add the model to the viewport
            viewport.Children.Add(new ModelVisual3D { Content = model });

            // Set the camera position and orientation
            viewport.Camera.Position = new Point3D(3, 3, 3);
            viewport.Camera.LookDirection = new Vector3D(-1, -1, -1);
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing action and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data containing cancellation information.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true; // Prevents the window from closing
            this.Hide(); // Hides the window instead
        }
    }
}