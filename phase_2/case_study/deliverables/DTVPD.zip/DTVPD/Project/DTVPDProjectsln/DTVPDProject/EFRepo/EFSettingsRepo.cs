﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTVPDProject.EFRepo
{
    /// <summary>
    /// Repository class for managing settings in the database.
    /// </summary>
    public class EFSettingsRepo
    {

    }
}
