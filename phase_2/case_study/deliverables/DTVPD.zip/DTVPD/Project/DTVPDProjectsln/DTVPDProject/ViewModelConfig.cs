﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTVPDProject.Entities;
using DTVPDProject.ViewModels;

namespace DTVPDProject
{
    /// <summary>
    /// Provides a centralized configuration for managing the instantiation of various ViewModels in the application.
    /// This class implements the Singleton pattern to ensure that only one instance of each ViewModel is created.
    /// </summary>
    static class ViewModelConfig
    {
        private static UserViewModel _userViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="User ViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static UserViewModel UserViewModel
        {
            get
            {
                if (_userViewModel == null)
                {
                    _userViewModel = new UserViewModel();
                }
                return _userViewModel;
            }
        }

        private static DigitalTwinCreationViewModel _digitalTwinCreationViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="DigitalTwinCreationViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static DigitalTwinCreationViewModel digitalTwinCreationViewModel
        {
            get
            {
                if (_digitalTwinCreationViewModel == null)
                {
                    _digitalTwinCreationViewModel = new DigitalTwinCreationViewModel();
                }
                return _digitalTwinCreationViewModel;
            }
        }

        private static CollaborationViewModel _collaborationViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="CollaborationViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static CollaborationViewModel collaborationViewModel
        {
            get
            {
                if (_collaborationViewModel == null)
                {
                    _collaborationViewModel = new CollaborationViewModel();
                }
                return _collaborationViewModel;
            }
        }

        private static FeedbackViewModel _feedbackViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="FeedbackViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static FeedbackViewModel feedbackViewModel
        {
            get
            {
                if (_feedbackViewModel == null)
                {
                    _feedbackViewModel = new FeedbackViewModel();
                }
                return _feedbackViewModel;
            }
        }

        private static HelpAndSupportViewModel _helpViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="HelpAndSupportViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static HelpAndSupportViewModel helpViewModel
        {
            get
            {
                if (_helpViewModel == null)
                {
                    _helpViewModel = new HelpAndSupportViewModel();
                }
                return _helpViewModel;
            }
        }

        private static PerformanceViewModel _performanceViewModel;

        /// <summary>
        /// Gets the instance of the <see cref="PerformanceViewModel"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static PerformanceViewModel performanceViewModel
        {
            get
            {
                if (_performanceViewModel == null)
                {
                    _performanceViewModel = new PerformanceViewModel();
                }
                return _performanceViewModel;
            }
        }

        private static SimulationManagementViewModel _simulationViewModel;

        /// <summary>
        /// Creates and returns a new instance of the <see cref="SimulationManagementViewModel"/> 
        /// using a new instance of the DbContext.
        /// </summary>
        /// <returns>A new instance of <see cref="SimulationManagementViewModel"/>.</returns>
        public static SimulationManagementViewModel GetSimulationManagementViewModel()
        {
            // Create an instance of the DbContext
            var dbContext = new DtvpdDbEntitiesEntities();
            return new SimulationManagementViewModel(new EFSimulationsRepo(dbContext));
        }
    }
}