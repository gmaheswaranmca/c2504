﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DTVPDProject.ViewModels;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for LoginPageWindow.xaml.
    /// This window allows users to log in to the application.
    /// </summary>
    public partial class LoginPageWindow : Window
    {
        /// <summary>
        /// Gets or sets a value indicating whether the user is an admin.
        /// </summary>
        public bool IsAdmin { get; set; } = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="LoginPageWindow"/> class.
        /// Sets up the DataContext with a new instance of <see cref="User ViewModel"/> 
        /// and assigns the close action for the window.
        /// </summary>
        public LoginPageWindow()
        {
            InitializeComponent();
            var ViewModel = new UserViewModel();
            this.DataContext = ViewModel;

            ViewModel.WindowClose = CloseLogin;
        }

        /// <summary>
        /// Closes the login window and opens the home dashboard if the user is an admin.
        /// </summary>
        public void CloseLogin()
        {
            // this.Hide();
            if (IsAdmin)
            {
                this.Hide();
                FormConfig.homeDashboardWindow.Show();
            }
        }

        /// <summary>
        /// Handles the window closed event. Shuts down the application when the window is closed.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}