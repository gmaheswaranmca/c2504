﻿using System.Windows;
using DTVPDProject.ViewModels;
using DTVPDProject.Repo;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for SimulationManagementWindow.xaml.
    /// This window manages the simulation settings and operations within the application.
    /// </summary>
    public partial class SimulationManagementWindow : Window
    {
        /// <summary>
        /// The view model for managing simulation data and operations.
        /// </summary>
        private readonly SimulationManagementViewModel _viewModel;

        /// <summary>
        /// Initializes a new instance of the <see cref="SimulationManagementWindow"/> class.
        /// Sets up the DataContext with the simulation management view model for data binding.
        /// </summary>
        public SimulationManagementWindow()
        {
            InitializeComponent();
            _viewModel = ViewModelConfig.GetSimulationManagementViewModel(); // Retrieve the view model
            DataContext = _viewModel; // Set the DataContext for data binding
        }
    }
}