﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTVPDProject.Entities
{
    /// <summary>
    /// Interface for managing collaborations in the system.
    /// </summary>
    public interface ICollaborationRepo
    {
        /// <summary>
        /// Retrieves all collaborations.
        /// </summary>
        /// <returns>A collection of collaborations.</returns>
        ObservableCollection<Collaboration> GetAllCollaborations();

        /// <summary>
        /// Retrieves a collaboration by its unique identifier.
        /// </summary>
        /// <param name="collaborationId">The unique identifier of the collaboration.</param>
        /// <returns>The collaboration associated with the specified identifier.</returns>
        Collaboration GetCollaborationById(int collaborationId);

        /// <summary>
        /// Adds a new collaboration to the system.
        /// </summary>
        /// <param name="collaboration">The collaboration to be added.</param>
        void AddCollaboration(Collaboration collaboration);

        /// <summary>
        /// Deletes a collaboration from the system by its unique identifier.
        /// </summary>
        /// <param name="collaborationId">The unique identifier of the collaboration to be deleted.</param>
        void DeleteCollaboration(int collaborationId);
    }
}