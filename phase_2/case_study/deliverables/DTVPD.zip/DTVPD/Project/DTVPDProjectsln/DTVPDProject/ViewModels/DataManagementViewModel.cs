﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using DTVPDProject.Commands;
using DTVPDProject.Entities;
using log4net;

namespace DTVPDProject.ViewModels
{
    public class DataManagementViewModel : INotifyPropertyChanged
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(DataManagementViewModel));
        private ObservableCollection<Simulation> _simulations;
        private ObservableCollection<Simulation> _filteredSimulations;
        private string _searchText;
        private string _selectedFilter;

        // Property to hold filter options
        public ObservableCollection<string> FilterOptions { get; set; }

        public ObservableCollection<Simulation> Simulations
        {
            get => _simulations;
            set
            {
                if (SetProperty(ref _simulations, value))
                {
                    FilteredSimulations = new ObservableCollection<Simulation>(value); // Initialize filtered collection
                    FilterSimulations(); // Apply filtering
                }
            }
        }

        public ObservableCollection<Simulation> FilteredSimulations
        {
            get => _filteredSimulations;
            set => SetProperty(ref _filteredSimulations, value);
        }

        public string SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                {
                    FilterSimulations(); // Trigger filtering when SearchText changes
                }
            }
        }

        public string SelectedFilter
        {
            get => _selectedFilter;
            set
            {
                if (SetProperty(ref _selectedFilter, value))
                {
                    FilterSimulations(); // Trigger filtering when SelectedFilter changes
                }
            }
        }

        public ICommand SearchCommand { get; set; }

        public DataManagementViewModel(ObservableCollection<Simulation> simulations)
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net
            Simulations = simulations;
            FilteredSimulations = new ObservableCollection<Simulation>(simulations);
            FilterOptions = new ObservableCollection<string> { "All", "Succeeded", "Failed" }; // Initialize filter options
            SearchCommand = new RelayCommand(Search);
        }

        private void Search()
        {
            Logger.Info("Search command executed.");
            FilterSimulations(); // Call filtering logic when the search command is executed
        }

        private void FilterSimulations()
        {
            Logger.Debug("Filtering simulations based on search text and selected filter.");
            // Perform filtering based on SearchText and SelectedFilter
            var filtered = Simulations.Where(s =>
                (string.IsNullOrWhiteSpace(SearchText) ||
                 s.ImagePath.IndexOf(SearchText, StringComparison.OrdinalIgnoreCase) >= 0) &&
                (string.IsNullOrWhiteSpace(SelectedFilter) ||
                 SelectedFilter == "All" || // Show all results if "All" is selected
                 (SelectedFilter == "Succeeded" && s.Status.Equals("Succeeded", StringComparison.OrdinalIgnoreCase)) || // Match for Succeeded
                 (SelectedFilter == "Failed" && s.Status.Equals("Failed", StringComparison.OrdinalIgnoreCase)))); // Match for Failed

            // Clear previous results
            FilteredSimulations.Clear();

            // Add filtered results to the collection
            foreach (var simulation in filtered)
            {
                FilteredSimulations.Add(simulation);
            }

            // Debugging: Check how many simulations are filtered
            Logger.Debug($"Filtered count: {FilteredSimulations.Count}");
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        protected bool SetProperty<T>(ref T storage, T value, [CallerMemberName] string propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(storage, value)) return false;
            storage = value;
            OnPropertyChanged(propertyName);
            return true;
        }
    }
}