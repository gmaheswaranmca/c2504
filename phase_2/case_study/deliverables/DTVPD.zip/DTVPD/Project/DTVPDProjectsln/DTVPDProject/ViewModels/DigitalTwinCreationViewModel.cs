﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using DTVPDProject.Commands;
using DTVPDProject.Entities;
using DTVPDProject.EFRepo;
using log4net;
using Microsoft.Win32;

namespace DTVPDProject.ViewModels
{
    public class DigitalTwinCreationViewModel : ViewModelBase
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(DigitalTwinCreationViewModel));
        private readonly EFDigitalTwinsRepo _digitalTwinsRepo;
        public DWindowClose NewWindowClose;
        private ObservableCollection<DigitalTwin> _digitalTwin;
        private DigitalTwin _newDigitalTwin;
        private DigitalTwin _selectedDigitalTwin;

        public ObservableCollection<DigitalTwin> DigitalTwin
        {
            get { return _digitalTwin; }
            set { _digitalTwin = value; OnPropertyChanged(nameof(DigitalTwin)); }
        }

        public DigitalTwin NewDigitalTwin
        {
            get { return _newDigitalTwin; }
            set { _newDigitalTwin = value; OnPropertyChanged(nameof(NewDigitalTwin)); }
        }

        public DigitalTwin SelectedDigitalTwin
        {
            get { return _selectedDigitalTwin; }
            set { _selectedDigitalTwin = value; OnPropertyChanged(nameof(SelectedDigitalTwin)); }
        }

        private string _filePath;

        public string FilePath
        {
            get { return _filePath; }
            set
            {
                _filePath = value;
                NewDigitalTwin.ModelPath = value;
                OnPropertyChanged("FilePath");
            }
        }

        public ICommand CreateCommand { get; }
        public ICommand UpdateCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand BrowseCommand { get; set; }

        public DigitalTwinCreationViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net
            _digitalTwinsRepo = new EFDigitalTwinsRepo();

            CreateCommand = new RelayCommand(Create);
            UpdateCommand = new RelayCommand(Update);
            DeleteCommand = new RelayCommand(Delete);
            BrowseCommand = new RelayCommand(BrowseFile);

            NewDigitalTwin = new DigitalTwin
            {
                TwinID = 1,
                UserID = 1,
                Name = " ",
                Description = "",
                ModelPath = "",
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now,
            };
            LoadDigitalTwin();
        }

        public void LoadDigitalTwin()
        {
            Logger.Info("Loading digital twins from the repository.");
            DigitalTwin = _digitalTwinsRepo.ReadAll();
            Logger.Info($"Loaded {DigitalTwin.Count} digital twins.");
        }

        public void Create()
        {
            try
            {
                var result = MessageBox.Show("Are you sure to create?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _digitalTwinsRepo.Create(NewDigitalTwin);
                DigitalTwin.Add(NewDigitalTwin);
                MessageBox.Show("Created Successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDigitalTwin();

                Logger.Info("Digital twin created successfully.");

                NewWindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error creating digital twin.", ex);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        public void Update()
        {
            try
            {
                var result = MessageBox.Show("Are you sure to update?", "Confirm ", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _digitalTwinsRepo.Update(SelectedDigitalTwin);
                MessageBox.Show("Updated Successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDigitalTwin();

                Logger.Info("Digital twin updated successfully.");

                NewWindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error updating digital twin.", ex);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        public void Delete()
        {
            try
            {
                var result = MessageBox.Show("Are you sure to delete?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _digitalTwinsRepo.Delete(SelectedDigitalTwin.TwinID);
                MessageBox.Show("Deleted Successfully", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadDigitalTwin();

                Logger.Info("Digital twin deleted successfully.");

                NewWindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Logger.Error("Error deleting digital twin.", ex);
                MessageBox.Show($"{ex.StackTrace}");
            }
        }

        private void BrowseFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                FilePath = openFileDialog.FileName;
            }
        }
    }
}