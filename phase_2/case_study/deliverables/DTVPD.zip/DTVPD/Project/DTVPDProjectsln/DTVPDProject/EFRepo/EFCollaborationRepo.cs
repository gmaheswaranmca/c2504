﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using DTVPDProject.Entities;
using DTVPDProject.Repo;

namespace DTVPDProject.EFRepo
{
    /// <summary>
    /// Repository class for managing collaborations in the database.
    /// Implements the ICollaborationRepo interface.
    /// </summary>
    public class EFCollaborationRepo : ICollaborationRepo
    {
        private readonly DtvpdDbEntitiesEntities _context;

        /// <summary>
        /// Initializes a new instance of the <see cref="EFCollaborationRepo"/> class.
        /// </summary>
        public EFCollaborationRepo()
        {
            _context = new DtvpdDbEntitiesEntities();
        }

        /// <summary>
        /// Retrieves all collaborations from the database.
        /// </summary>
        /// <returns>An ObservableCollection of <see cref="Collaboration"/> objects.</returns>
        public ObservableCollection<Collaboration> GetAllCollaborations()
        {
            // Convert the list of collaborations to an ObservableCollection
            return new ObservableCollection<Collaboration>(_context.Collaborations.ToList());
        }

        /// <summary>
        /// Retrieves a collaboration by its ID.
        /// </summary>
        /// <param name="collaborationId">The ID of the collaboration to retrieve.</param>
        /// <returns>The <see cref="Collaboration"/> object with the specified ID, or null if not found.</returns>
        public Collaboration GetCollaborationById(int collaborationId)
        {
            return _context.Collaborations.Find(collaborationId);
        }

        /// <summary>
        /// Adds a new collaboration to the database.
        /// </summary>
        /// <param name="collaboration">The <see cref="Collaboration"/> object to add.</param>
        public void AddCollaboration(Collaboration collaboration)
        {
            _context.Collaborations.Add(collaboration);
            _context.SaveChanges();
        }

        /// <summary>
        /// Deletes a collaboration from the database by its ID.
        /// </summary>
        /// <param name="collaborationId">The ID of the collaboration to delete.</param>
        public void DeleteCollaboration(int collaborationId)
        {
            var collaboration = _context.Collaborations.Find(collaborationId);
            if (collaboration != null)
            {
                _context.Collaborations.Remove(collaboration);
                _context.SaveChanges();
            }
        }
    }
}