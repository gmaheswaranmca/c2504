﻿using System.Collections.Generic;
using System.Data.Entity;
using DTVPDProject.Entities;
using DTVPDProject.Repo;

/// <summary>
/// Repository class for managing simulations in the database.
/// Implements the ISimulationsRepo interface.
/// </summary>
public class EFSimulationsRepo : ISimulationsRepo
{
    private readonly DtvpdDbEntitiesEntities _dbContext;

    /// <summary>
    /// Initializes a new instance of the <see cref="EFSimulationsRepo"/> class.
    /// </summary>
    /// <param name="dbContext">The database context to use for data operations.</param>
    public EFSimulationsRepo(DtvpdDbEntitiesEntities dbContext)
    {
        _dbContext = dbContext;
    }

    /// <summary>
    /// Retrieves all simulations from the database.
    /// </summary>
    /// <returns>An <see cref="IEnumerable{Simulation}"/> containing all simulations.</returns>
    public IEnumerable<Simulation> GetSimulations()
    {
        return _dbContext.Simulations;
    }

    /// <summary>
    /// Retrieves a simulation by its ID.
    /// </summary>
    /// <param name="id">The ID of the simulation to retrieve.</param>
    /// <returns>The <see cref="Simulation"/> object with the specified ID, or null if not found.</returns>
    public Simulation GetSimulationById(int id)
    {
        return _dbContext.Simulations.Find(id);
    }

    /// <summary>
    /// Adds a new simulation to the database.
    /// </summary>
    /// <param name="simulation">The <see cref="Simulation"/> object to add.</param>
    public void AddSimulation(Simulation simulation)
    {
        _dbContext.Simulations.Add(simulation);
    }

    /// <summary>
    /// Updates an existing simulation in the database.
    /// </summary>
    /// <param name="simulation">The <see cref="Simulation"/> object with updated values.</param>
    public void UpdateSimulation(Simulation simulation)
    {
        _dbContext.Entry(simulation).State = EntityState.Modified;
    }

    /// <summary>
    /// Deletes a simulation from the database.
    /// </summary>
    /// <param name="simulation">The <see cref="Simulation"/> object to delete.</param>
    public void DeleteSimulation(Simulation simulation)
    {
        _dbContext.Simulations.Remove(simulation);
    }

    /// <summary>
    /// Saves all changes made in the context to the database.
    /// </summary>
    public void SaveChanges()
    {
        _dbContext.SaveChanges();
    }
}