﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for HomeDashboardWindow.xaml.
    /// This window serves as the main dashboard for the application, providing access to various functionalities.
    /// </summary>
    public partial class HomeDashboardWindow : Window
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="HomeDashboardWindow"/> class.
        /// Sets up the components of the dashboard window.
        /// </summary>
        public HomeDashboardWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the click event of the Create Digital Twin button.
        /// Displays the digital twin creation window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void CreateDigitalTwinButton_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.digitalTwinCreationWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Settings button.
        /// Displays the settings window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.settingsWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Help button.
        /// Displays the help and support window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.helpandSupportWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Feedback button.
        /// Displays the feedback window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnFeedback_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.feedbackWindow.Show();
        }

        /// <summary>
        /// Handles the click event of the Performance Indicator button.
        /// Displays the performance analysis window.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void btnPerformanceIndicator_Click(object sender, RoutedEventArgs e)
        {
            FormConfig.performanceAnalysisWindow.Show();
        }

        /// <summary>
        /// Handles the window closed event. Shuts down the application when the window is closed.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}