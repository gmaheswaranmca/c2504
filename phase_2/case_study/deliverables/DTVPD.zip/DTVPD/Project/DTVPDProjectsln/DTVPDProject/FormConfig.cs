﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTVPDProject.Pages;
using DTVPDProject.ViewModels;

namespace DTVPDProject
{
    /// <summary>
    /// Provides a centralized configuration for managing the instantiation of various window forms in the application.
    /// This class implements the Singleton pattern to ensure that only one instance of each window is created.
    /// </summary>
    public static class FormConfig
    {
        private static CollaborationWindow _collaborationWindow;

        /// <summary>
        /// Gets the instance of the <see cref="CollaborationWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static CollaborationWindow collaborationWindow
        {
            get
            {
                if (_collaborationWindow == null)
                {
                    _collaborationWindow = new CollaborationWindow();
                }
                return _collaborationWindow;
            }
        }

        private static DataManagementWindow _dataManagementWindow;

        /// <summary>
        /// Gets the instance of the <see cref="DataManagementWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static DataManagementWindow dataManagementWindow
        {
            get
            {
                if (_dataManagementWindow == null)
                {
                    _dataManagementWindow = new DataManagementWindow();
                }
                return _dataManagementWindow;
            }
        }

        private static DesignIterationWindow _designIterationWindow;

        /// <summary>
        /// Gets the instance of the <see cref="DesignIterationWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static DesignIterationWindow designIterationWindow
        {
            get
            {
                if (_designIterationWindow == null)
                {
                    _designIterationWindow = new DesignIterationWindow();
                }
                return _designIterationWindow;
            }
        }

        private static DigitalTwinCreationWindow _digitalTwinCreationWindow;

        /// <summary>
        /// Gets the instance of the <see cref="DigitalTwinCreationWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static DigitalTwinCreationWindow digitalTwinCreationWindow
        {
            get
            {
                if (_digitalTwinCreationWindow == null)
                {
                    _digitalTwinCreationWindow = new DigitalTwinCreationWindow();
                }
                return _digitalTwinCreationWindow;
            }
        }

        private static FeedbackWindow _feedbackWindow;

        /// <summary>
        /// Gets the instance of the <see cref="FeedbackWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static FeedbackWindow feedbackWindow
        {
            get
            {
                if (_feedbackWindow == null)
                {
                    _feedbackWindow = new FeedbackWindow();
                }
                return _feedbackWindow;
            }
        }

        private static HelpandSupportWindow _helpandSupportWindow;

        /// <summary>
        /// Gets the instance of the <see cref="HelpandSupportWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static HelpandSupportWindow helpandSupportWindow
        {
            get
            {
                if (_helpandSupportWindow == null)
                {
                    _helpandSupportWindow = new HelpandSupportWindow();
                }
                return _helpandSupportWindow;
            }
        }

        private static HomeDashboardWindow _homeDashboardWindow;

        /// <summary>
        /// Gets the instance of the <see cref="HomeDashboardWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static HomeDashboardWindow homeDashboardWindow
        {
            get
            {
                if (_homeDashboardWindow == null)
                {
                    _homeDashboardWindow = new HomeDashboardWindow();
                }
                return _homeDashboardWindow;
            }
        }

        private static PerformanceAnalysisWindow _performanceAnalysisWindow;

        /// <summary>
        /// Gets the instance of the <see cref="PerformanceAnalysisWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static PerformanceAnalysisWindow performanceAnalysisWindow
        {
            get
            {
                if (_performanceAnalysisWindow == null)
                {
                    _performanceAnalysisWindow = new PerformanceAnalysisWindow();
                }
                return _performanceAnalysisWindow;
            }
        }

        private static SettingsWindow _settingsWindow;

        /// <summary>
        /// Gets the instance of the <see cref="SettingsWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static SettingsWindow settingsWindow
        {
            get
            {
                if (_settingsWindow == null)
                {
                    _settingsWindow = new SettingsWindow();
                }
                return _settingsWindow;
            }
        }

        private static SimulationManagementWindow _simulationManagementWindow;

        /// <summary>
        /// Gets the instance of the <see cref="SimulationManagementWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static SimulationManagementWindow simulationManagementWindow
        {
            get
            {
                if (_simulationManagementWindow == null)
                {
                    _simulationManagementWindow = new SimulationManagementWindow();
                }
                return _simulationManagementWindow;
            }
        }

        private static UserManagementWindow _userManagementWindow;

        /// <summary>
        /// Gets the instance of the <see cref="UserManagementWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static UserManagementWindow userManagementWindow
        {
            get
            {
                if (_userManagementWindow == null)
                {
                    _userManagementWindow = new UserManagementWindow();
                }
                return _userManagementWindow;
            }
        }

        private static LoginPageWindow _loginPageWindow;

        /// <summary>
        /// Gets the instance of the <see cref="LoginPageWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static LoginPageWindow loginPageWindow
        {
            get
            {
                if (_loginPageWindow == null)
                {
                    _loginPageWindow = new LoginPageWindow();
                }
                return _loginPageWindow;
            }
        }

        private static NewUserPageWindow _newUserPageWindow;

        /// <summary>
        /// Gets the instance of the <see cref="NewUserPageWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static NewUserPageWindow newUserPageWindow
        {
            get
            {
                if (_newUserPageWindow == null)
                {
                    _newUserPageWindow = new NewUserPageWindow();
                }
                return _newUserPageWindow;
            }
        }

        private static UpdateUserWindow _updateUserWindow;

        /// <summary>
        /// Gets the instance of the <see cref="UpdateUserWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static UpdateUserWindow updateUserWindow
        {
            get
            {
                if (_updateUserWindow == null)
                {
                    _updateUserWindow = new UpdateUserWindow();
                }
                return _updateUserWindow;
            }
        }

        private static CreateListWindow _createListWindow;

        /// <summary>
        /// Gets the instance of the <see cref="CreateListWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static CreateListWindow createListWindow
        {
            get
            {
                if (_createListWindow == null)
                {
                    _createListWindow = new CreateListWindow();
                }
                return _createListWindow;
            }
        }

        private static EditListWindow _editListWindow;

        /// <summary>
        /// Gets the instance of the <see cref="EditListWindow"/>. 
        /// If the instance does not exist, it creates a new one.
        /// </summary>
        public static EditListWindow editListWindow
        {
            get
            {
                if (_editListWindow == null)
                {
                    _editListWindow = new EditListWindow();
                }
                return _editListWindow;
            }
        }
    }
}