﻿using HelixToolkit.Wpf;
using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using log4net;
using LiveCharts.Configurations;

namespace DTVPDProject.ViewModels
{
    public class PerformanceViewModel : INotifyPropertyChanged
    {
        private static readonly ILog Logger = LogManager.GetLogger(typeof(PerformanceViewModel));
        private ObservableCollection<Metric> _metrics;
        private SeriesCollection _seriesCollection;
        private ChartValues<double> _lineChartValues;
        private ChartValues<double> _barChartValues;

        // New properties
        private string _simulationId;
        private DateTime _startTime;
        private DateTime _endTime;
        private string _status;

        public PerformanceViewModel()
        {
            log4net.Config.XmlConfigurator.Configure(); // Configure log4net

            // Initialize the metrics collection with default metrics
            Metrics = new ObservableCollection<Metric>
            {
                new Metric { MetricName = "Example Metric 1", MetricValue = 10, Unit = "Units" },
                new Metric { MetricName = "Example Metric 2", MetricValue = 20, Unit = "Units" }
                // Add more metrics as needed
            };

            SeriesCollection = new SeriesCollection();
            LineChartValues = new ChartValues<double>();
            BarChartValues = new ChartValues<double>();

            // Initialize the chart configurations
            var mapper = Mappers.Xy<double>()
                .X(x => x)
                .Y(x => x);

            Charting.For<double>(mapper);

            // Set default values for other properties
            SimulationId = "Simulation1";
            StartTime = DateTime.Now;
            EndTime = DateTime.Now.AddHours(1);
            Status = "Started"; // Set a default status

            Logger.Info("Performance ViewModel initialized with default metrics.");
        }

        public ObservableCollection<Metric> Metrics
        {
            get { return _metrics; }
            set
            {
                _metrics = value ?? new ObservableCollection<Metric>
                {
                    new Metric { MetricName = "Default Metric", MetricValue = 0, Unit = "Units" }
                };
                OnPropertyChanged();
            }
        }

        public SeriesCollection SeriesCollection
        {
            get { return _seriesCollection; }
            set
            {
                _seriesCollection = value;
                OnPropertyChanged();
            }
        }

        public ChartValues<double> LineChartValues
        {
            get { return _lineChartValues; }
            set
            {
                _lineChartValues = value;
                OnPropertyChanged();
            }
        }

        public ChartValues<double> BarChartValues
        {
            get { return _barChartValues; }
            set
            {
                _barChartValues = value;
                OnPropertyChanged();
            }
        }

        // New Properties
        public string SimulationId
        {
            get { return _simulationId; }
            set
            {
                _simulationId = value;
                OnPropertyChanged();
            }
        }

        public DateTime StartTime
        {
            get { return _startTime; }
            set
            {
                _startTime = value;
                OnPropertyChanged();
            }
        }

        public DateTime EndTime
        {
            get { return _endTime; }
            set
            {
                _endTime = value;
                OnPropertyChanged();
            }
        }

        public string Status
        {
            get { return _status; }
            set
            {
                _status = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public class Metric
        {
            public string MetricName { get; set; }
            public int MetricValue { get; set; }
            public string Unit { get; set; }

            // Add a command or method to handle clicks
            public void OnMetricClicked(PerformanceViewModel viewModel)
            {
                // Update the charts based on the clicked metric
                viewModel.UpdateCharts(this);
            }
        }

        private void UpdateCharts(Metric metric)
        {
            // Clear existing chart values
            LineChartValues.Clear();
            BarChartValues.Clear();

            LineChartValues.Add(metric.MetricValue); // Add to line chart
            BarChartValues.Add(metric.MetricValue);  // Add to bar chart

            Logger.Info($"Updated charts with metric {metric.MetricName}.");
        }
    }
}