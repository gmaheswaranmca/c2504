﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DTVPDProject.Pages
{
    /// <summary>
    /// Interaction logic for EditListWindow.xaml.
    /// This window allows users to edit existing digital twin entries.
    /// </summary>
    public partial class EditListWindow : Window
    {
        private static EditListWindow _instance;

        /// <summary>
        /// Initializes a new instance of the <see cref="EditListWindow"/> class.
        /// Sets the DataContext to the digital twin creation view model.
        /// </summary>
        public EditListWindow()
        {
            InitializeComponent();
            this.DataContext = ViewModelConfig.digitalTwinCreationViewModel;
            // ViewModelConfig.digitalTwinCreationViewModel.NewWindowClose = HideWindow; // Uncomment to assign the close method
        }

        /// <summary>
        /// Gets the singleton instance of the <see cref="EditListWindow"/> class.
        /// Ensures that only one instance of the window is created.
        /// </summary>
        public static EditListWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EditListWindow();
                }

                return _instance;
            }
        }

        /// <summary>
        /// Hides the window without closing it.
        /// </summary>
        public void HideWindow()
        {
            this.Hide();
        }

        /// <summary>
        /// Handles the window closing event. Cancels the closing and hides the window instead.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The event data.</param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}