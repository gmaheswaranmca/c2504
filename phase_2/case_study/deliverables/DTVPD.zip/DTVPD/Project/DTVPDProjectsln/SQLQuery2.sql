﻿CREATE DATABASE DtvpdDb
USE DtvpdDb



CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Role NVARCHAR(20) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);

INSERT INTO Users (Username, PasswordHash, Email, Role, CreatedAt, UpdatedAt)
VALUES
    ('johnDoe', 'hashed_password_1', 'john.doe@example.com', 'Admin', GETDATE(), GETDATE()),
    ('janeSmith', 'hashed_password_2', 'jane.smith@example.com', 'User ', GETDATE(), GETDATE()),
    ('bobJohnson', 'hashed_password_3', 'bob.johnson@example.com', 'Admin', GETDATE(), GETDATE());
   

   SELECT * FROM Users;