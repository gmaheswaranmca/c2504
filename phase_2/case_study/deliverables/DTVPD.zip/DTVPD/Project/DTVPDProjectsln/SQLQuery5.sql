﻿INSERT INTO Users (Username, PasswordHash, Email, Role)
VALUES ('archana', '1234', 'archana@gmail.com', 'User');

select * from Users;