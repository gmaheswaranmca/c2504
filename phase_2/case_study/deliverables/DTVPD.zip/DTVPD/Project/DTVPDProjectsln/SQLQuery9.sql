﻿INSERT INTO Users (Username, PasswordHash, Email, Role, CreatedAt, UpdatedAt)
VALUES
   
    ('ashna', 'hashed_password_4', 'ashna@gmail.com', 'User', GETDATE(), GETDATE());


   

   select * from Users;