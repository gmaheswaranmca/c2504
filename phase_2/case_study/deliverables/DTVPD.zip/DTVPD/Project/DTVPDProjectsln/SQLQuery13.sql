﻿ALTER TABLE Simulations
ADD ImagePath NVARCHAR(255),
Result VARCHAR(255);


select * from Simulations;