﻿CREATE TABLE DigitalTwins (
    TwinID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    Name NVARCHAR(100) NOT NULL,
    Description NVARCHAR(255),
    ModelPath NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE Simulations (
    SimulationID INT PRIMARY KEY IDENTITY(1,1),
    TwinID INT FOREIGN KEY REFERENCES DigitalTwins(TwinID),
    Status NVARCHAR(20) NOT NULL, -- (e.g., 'Running', 'Completed', 'Failed')
    StartTime DATETIME,
    EndTime DATETIME,
    CreatedAt DATETIME DEFAULT GETDATE(),
    UpdatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE SimulationResults (
    ResultID INT PRIMARY KEY IDENTITY(1,1),
    SimulationID INT FOREIGN KEY REFERENCES Simulations(SimulationID),
    MetricName NVARCHAR(100) NOT NULL,
    MetricValue FLOAT NOT NULL,
    Unit NVARCHAR(20),
    Timestamp DATETIME DEFAULT GETDATE()
);

CREATE TABLE DesignIterations (
    IterationID INT PRIMARY KEY IDENTITY(1,1),
    TwinID INT FOREIGN KEY REFERENCES DigitalTwins(TwinID),
    IterationNumber INT NOT NULL,
    ModifiedModelPath NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE Collaboration (
    CollaborationID INT PRIMARY KEY IDENTITY(1,1),
    TwinID INT FOREIGN KEY REFERENCES DigitalTwins(TwinID),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    Comment NVARCHAR(255),
    CreatedAt DATETIME DEFAULT GETDATE()
);

CREATE TABLE Settings (
    SettingID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    ParameterName NVARCHAR(100) NOT NULL,
    ParameterValue NVARCHAR(255),
    UpdatedAt DATETIME DEFAULT GETDATE()
);