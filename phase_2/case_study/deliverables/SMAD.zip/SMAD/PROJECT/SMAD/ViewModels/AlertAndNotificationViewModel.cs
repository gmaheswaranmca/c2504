﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics; // Include this for StackTrace
using System.Linq;
using System.Windows;
using System.Windows.Input;
using Serilog; // Include Serilog for logging
using SMAD.EFRepo;
using SMAD.Entities;
using SMAD.Repo;

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for managing alerts and notifications.
    /// This ViewModel handles creating, updating, and filtering alerts.
    /// </summary>
    public delegate void DWindowClose();

    public class AlertAndNotificationViewModel : ViewModelBase1
    {
        public DWindowClose NewWindowClose;
        public DWindowClose EditWindowClose;
        private Alert _newAlert;

        /// <summary>
        /// Gets or sets the new alert to be created.
        /// </summary>
        public Alert NewAlert
        {
            get { return _newAlert; }
            set
            {
                _newAlert = value;
                OnPropertyChanged(nameof(NewAlert));
            }
        }

        private Alert _selectedAlert = null;

        /// <summary>
        /// Gets or sets the selected alert for updating.
        /// </summary>
        public Alert SelectedAlert
        {
            get => _selectedAlert;
            set
            {
                _selectedAlert = value;
                OnPropertyChanged(nameof(SelectedAlert));
            }
        }

        private ObservableCollection<Alert> _alerts;

        /// <summary>
        /// Gets or sets the collection of alerts.
        /// </summary>
        public ObservableCollection<Alert> Alerts
        {
            get => _alerts;
            set
            {
                _alerts = value;
                OnPropertyChanged(nameof(Alerts));
            }
        }

        private ObservableCollection<Alert> _filteredAlerts;

        /// <summary>
        /// Gets or sets the collection of filtered alerts based on the selected filter option.
        /// </summary>
        public ObservableCollection<Alert> FilteredAlerts
        {
            get => _filteredAlerts;
            set
            {
                _filteredAlerts = value;
                OnPropertyChanged(nameof(FilteredAlerts));
            }
        }

        private string _selectedFilterOption;

        /// <summary>
        /// Gets or sets the selected filter option for alerts.
        /// </summary>
        public string SelectedFilterOption
        {
            get => _selectedFilterOption;
            set
            {
                _selectedFilterOption = value;
                OnPropertyChanged(nameof(SelectedFilterOption));
                ApplyFilter();
            }
        }

        private IAlertsRepo _repo = new EFAlertsRepo();

        /// <summary>
        /// Command to create a new alert.
        /// </summary>
        public ICommand CreateCommand { get; }

        /// <summary>
        /// Command to update an existing alert.
        /// </summary>
        public ICommand UpdateCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="AlertAndNotificationViewModel"/> class.
        /// </summary>
        public AlertAndNotificationViewModel()
        {
            LoadAlerts();
            SelectedFilterOption = "All";
            CreateCommand = new RelayCommand(CreateAlert);
            UpdateCommand = new RelayCommand(UpdateAlert);
            this.NewAlert = new Alert
            {
                LineID = 0,
                AlertDate = DateTime.Now,
                AlertType = " ",
                Severity = " ",
                Message = " ",
                Resolved = false,
            };
        }

        /// <summary>
        /// Loads all alerts from the repository.
        /// </summary>
        public void LoadAlerts()
        {
            Alerts = _repo.ReadAllAlerts();
            ApplyFilter();
        }

        /// <summary>
        /// Applies the selected filter to the alerts collection.
        /// </summary>
        private void ApplyFilter()
        {
            if (SelectedFilterOption == "Resolved")
            {
                FilteredAlerts = new ObservableCollection<Alert>(Alerts.Where(a => (bool)a.Resolved));
            }
            else if (SelectedFilterOption == "Unresolved")
            {
                FilteredAlerts = new ObservableCollection<Alert>(Alerts.Where(a => !(bool)a.Resolved));
            }
            else
            {
                // Show all alerts when "All" is selected
                FilteredAlerts = new ObservableCollection<Alert>(Alerts);
            }
        }

        /// <summary>
        /// Creates a new alert and saves it to the repository.
        /// </summary>
        public void CreateAlert()
        {
            Alert newAlert = new Alert
            {
                LineID = NewAlert.LineID,
                AlertDate = NewAlert.AlertDate,
                AlertType = NewAlert.AlertType,
                Severity = NewAlert.Severity,
                Message = NewAlert.Message,
                Resolved = NewAlert.Resolved,
            };

            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create an Alert?",
                            caption: "Confirm",
                            button: MessageBoxButton.YesNo,
                            icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _repo.CreateAlert(newAlert);
                result = MessageBox.Show(messageBoxText: "Alert Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                LoadAlerts();

                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error creating alert. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show($"An error occurred while creating an alert: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Updates an existing alert and saves it to the repository.
        /// </summary>
        public void UpdateAlert()
        {
            if (this.SelectedAlert == null)
            {
                return;
            }

            try
            {
                var res = MessageBox.Show(messageBoxText: "Are you sure to Update this Alert?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);

                if (res != MessageBoxResult.Yes)
                {
                    return;
                }

                _repo.UpdateAlert(this.SelectedAlert);
                this.SelectedAlert = this.SelectedAlert;

                var result = MessageBox.Show(messageBoxText: $"Alert {SelectedAlert.AlertID} is updated successfully",
                            caption: "Alert",
                            button: MessageBoxButton.OK,
                            icon: MessageBoxImage.Information);
                LoadAlerts();

                if (EditWindowClose != null)
                {
                    EditWindowClose();
                }
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error updating alert. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show($"An error occurred while updating an alert: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
