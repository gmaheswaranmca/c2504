﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using SMAD.Entities;
using SMAD.Repo;
using Serilog; // Include Serilog for logging
using System.Diagnostics;
using SMAD.EFRepo; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for managing help and support contacts.
    /// This ViewModel handles creating and loading contact support messages.
    /// </summary>
    public class HelpAndSupportViewModel : ViewModelBase1
    {
        private ContactSupport _newContact;

        /// <summary>
        /// Gets or sets the new contact support message to be created.
        /// </summary>
        public ContactSupport NewContact
        {
            get { return _newContact; }
            set
            {
                _newContact = value;
                OnPropertyChanged(nameof(NewContact));
            }
        }

        private ObservableCollection<ContactSupport> _contactSupports;

        /// <summary>
        /// Gets or sets the collection of contact support messages.
        /// </summary>
        public ObservableCollection<ContactSupport> ContactSupports
        {
            get => _contactSupports;
            set
            {
                _contactSupports = value;
                OnPropertyChanged(nameof(ContactSupports));
            }
        }

        private IContactSupportRepo _repo = new EFContactSupportRepo();

        /// <summary>
        /// Command to submit a new contact support message.
        /// </summary>
        public ICommand SubmitCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="HelpAndSupportViewModel"/> class.
        /// </summary>
        public HelpAndSupportViewModel()
        {
            LoadContacts();
            SubmitCommand = new RelayCommand(CreateHelp);
            this.NewContact = new ContactSupport
            {
                Name = " ",
                Email = " ",
                Message = " ",
            };
        }

        /// <summary>
        /// Loads all contact support messages from the repository.
        /// </summary>
        public void LoadContacts()
        {
            ContactSupports = _repo.ReadAllContacts();
        }

        /// <summary>
        /// Creates a new contact support message and saves it to the repository.
        /// </summary>
        public void CreateHelp()
        {
            ContactSupport newContact = new ContactSupport
            {
                Name = NewContact.Name,
                Email = NewContact.Email,
                Message = NewContact.Message,
            };

            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to send the message?",
                            caption: "Confirm",
                            button: MessageBoxButton.YesNo,
                            icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _repo.CreateHelp(newContact);
                result = MessageBox.Show(messageBoxText: "Message Sent Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                LoadContacts();
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error sending help message. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show($"An error occurred while sending the message: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}