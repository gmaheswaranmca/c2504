﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using SMAD.Entities;
using SMAD.EFRepo;
using SMAD.Repo;

namespace SMAD.ViewModels
{
    public class HomePageViewModel : ViewModelBase1
    {
        //private ObservableCollection<ProductionMetric> _productionMetrics;
        //private ObservableCollection<ProductionLine> _productionLines;
        //private readonly IProductionRepo _repo;

        //public ObservableCollection<ProductionMetric> ProductionMetrics
        //{
        //    get => _productionMetrics;
        //    set
        //    {
        //        _productionMetrics = value;
        //        OnPropertyChanged(nameof(ProductionMetrics));
        //        UpdatePlotModel(); // Update the plot model whenever metrics change
        //    }
        //}

        //public ObservableCollection<ProductionLine> ProductionLines
        //{
        //    get => _productionLines;
        //    set
        //    {
        //        _productionLines = value;
        //        OnPropertyChanged(nameof(ProductionLines));
        //    }
        //}

        //private PlotModel _plotModel;
        //public PlotModel PlotModel
        //{
        //    get => _plotModel;
        //    set
        //    {
        //        _plotModel = value;
        //        OnPropertyChanged(nameof(PlotModel));
        //    }
        //}

        public HomePageViewModel()
        {
            //_repo = new EFProductionMonitoringRepo(); // Initialize the EFRepo
            //ProductionMetrics = new ObservableCollection<ProductionMetric>();
            //ProductionLines = new ObservableCollection<ProductionLine>();

            //LoadProductionLines();
            //LoadProductionMetrics();
        }

    //    private void LoadProductionLines()
    //    {
    //        using (var context = new SmadDbEntities())
    //        {
    //            var lines = context.ProductionLines.ToList();
    //            ProductionLines = new ObservableCollection<ProductionLine>(lines);
    //        }
    //    }

    //    private void LoadProductionMetrics()
    //    {
    //        using (var context = new SmadDbEntities())
    //        {
    //            var metrics = context.ProductionMetrics.ToList();
    //            ProductionMetrics = new ObservableCollection<ProductionMetric>(metrics);
    //        }
    //    }

    //    private void UpdatePlotModel()
    //    {
    //        var plotModel = new PlotModel { Title = "Production Metrics" };
    //        var dateAxis = new DateTimeAxis
    //        {
    //            Position = AxisPosition.Bottom,
    //            StringFormat = "dd-MM-yyyy",
    //            Title = "Date"
    //        };
    //        plotModel.Axes.Add(dateAxis);

    //        var productionRateSeries = new LineSeries { Title = "Production Rate" };
    //        foreach (var metric in ProductionMetrics)
    //        {
    //            productionRateSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.ProductionRate));
    //        }
    //        plotModel.Series.Add(productionRateSeries);

    //        var efficiencySeries = new LineSeries { Title = "Efficiency (%)" };
    //        foreach (var metric in ProductionMetrics)
    //        {
    //            efficiencySeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.Efficiency));
    //        }
    //        plotModel.Series.Add(efficiencySeries);

    //        PlotModel = plotModel; // Set the updated plot model
    //    }
    }
}