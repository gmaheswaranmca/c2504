﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot;
using System.Windows.Input;
using System.Windows;
using SMAD.Entities;
using Serilog;
using System.Diagnostics; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for analyzing bottlenecks in production lines.
    /// This ViewModel handles the logic for loading production lines,
    /// analyzing bottlenecks based on selected criteria, and updating
    /// the plot model for visualization.
    /// </summary>
    public class BottleneckAnalysisViewModel : ViewModelBase1
    {
        private ObservableCollection<ProductionLine> _productionLines;
        private ProductionLine _selectedProductionLine;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private ObservableCollection<BottleneckData> _bottleneckData;
        private PlotModel _plotModel;

        /// <summary>
        /// Gets or sets the collection of production lines.
        /// </summary>
        public ObservableCollection<ProductionLine> ProductionLines
        {
            get => _productionLines;
            set
            {
                _productionLines = value;
                OnPropertyChanged(nameof(ProductionLines));
            }
        }

        /// <summary>
        /// Gets or sets the selected production line for analysis.
        /// </summary>
        public ProductionLine SelectedProductionLine
        {
            get => _selectedProductionLine;
            set
            {
                _selectedProductionLine = value;
                OnPropertyChanged(nameof(SelectedProductionLine));
            }
        }

        /// <summary>
        /// Gets or sets the start date for the analysis.
        /// </summary>
        public DateTime? StartDate
        {
            get => _startDate;
            set
            {
                _startDate = value;
                OnPropertyChanged(nameof(StartDate));
            }
        }

        /// <summary>
        /// Gets or sets the end date for the analysis.
        /// </summary>
        public DateTime? EndDate
        {
            get => _endDate;
            set
            {
                _endDate = value;
                OnPropertyChanged(nameof(EndDate));
            }
        }

        /// <summary>
        /// Gets or sets the collection of bottleneck data generated from the analysis.
        /// </summary>
        public ObservableCollection<BottleneckData> BottleneckData
        {
            get => _bottleneckData;
            set
            {
                _bottleneckData = value;
                OnPropertyChanged(nameof(BottleneckData));
            }
        }

        /// <summary>
        /// Gets or sets the plot model used for visualizing downtime analysis.
        /// </summary>
        public PlotModel PlotModel
        {
            get => _plotModel;
            set
            {
                _plotModel = value;
                OnPropertyChanged(nameof(PlotModel));
            }
        }

        /// <summary>
        /// Command to execute the bottleneck analysis.
        /// </summary>
        public ICommand AnalyzeCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="BottleneckAnalysisViewModel"/> class.
        /// This constructor sets up the initial state and loads production lines.
        /// </summary>
        public BottleneckAnalysisViewModel()
        {
            // Initialize collections
            ProductionLines = new ObservableCollection<ProductionLine>();
            BottleneckData = new ObservableCollection<BottleneckData>();

            // Load production lines
            LoadProductionLines();

            // Setup command
            AnalyzeCommand = new RelayCommand1(param => AnalyzeBottlenecks());
        }

        /// <summary>
        /// Loads production lines from the database and populates the ProductionLines collection.
        /// </summary>
        private void LoadProductionLines()
        {
            using (var context = new SmadDbEntities())
            {
                var lines = context.ProductionLines.ToList();
                ProductionLines = new ObservableCollection<ProductionLine>(lines);
                Log.Information("Loaded {Count} production lines.", lines.Count);
            }
        }

        /// <summary>
        /// Analyzes bottlenecks based on the selected production line and date range.
        /// Logs relevant information and updates the BottleneckData collection and PlotModel.
        /// </summary>
        private void AnalyzeBottlenecks()
        {
            // Check if a line is selected
            if (SelectedProductionLine == null)
            {
                Log.Warning("User  attempted to analyze without selecting a production line.");
                MessageBox.Show("Please select a production line.", "Error ", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Check if start and end dates are selected
            if (StartDate == null || EndDate == null)
            {
                Log.Warning("User  attempted to analyze without selecting date range.");
                MessageBox.Show("Please select both start and end dates.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            using (var context = new SmadDbEntities())
            {
                try
                {
                    var data = context.ProductionMetrics
                        .Where(pm => pm.LineID == SelectedProductionLine.LineID
                                     && pm.MetricDate >= StartDate
                                     && pm.MetricDate <= EndDate)
                        .ToList();
                    Log.Information("Analyzed bottlenecks for production line {LineName} from {StartDate} to {EndDate}. Data count: {DataCount}",
                       SelectedProductionLine.LineName, StartDate, EndDate, data.Count);

                    if (data.Count == 0)
                    {
                        Log.Warning("No data found for the selected line and date range.");
                        MessageBox.Show("No data found for the selected line and date range.");
                        return;
                    }

                    // Calculate total downtime in ticks
                    var totalDowntimeTicks = data.Sum(pm => (long)((pm.Downtime ?? 0) * TimeSpan.TicksPerHour));
                    var totalDowntime = new TimeSpan(totalDowntimeTicks);

                    // Generate recommendations based on analysis
                    string recommendations = GenerateRecommendations(totalDowntime);

                    // Create and populate BottleneckData collection
                    BottleneckData.Clear();
                    BottleneckData.Add(new BottleneckData
                    {
                        LineName = SelectedProductionLine.LineName,
                        BottleneckTime = totalDowntime,
                        TotalDowntime = totalDowntime,
                        Recommendations = recommendations
                    });

                    // Update the PlotModel
                    UpdatePlotModel(data);
                }
                catch (Exception ex)
                {
                    // Capture the stack trace
                    var stackTrace = new StackTrace(ex, true);
                    Log.Error(ex, "Error during analysis. Stack Trace: {StackTrace}", stackTrace.ToString());

                    MessageBox.Show($"Error during analysis: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Generates recommendations based on the total downtime.
        /// This method is a placeholder for your custom recommendation logic.
        /// </summary>
        /// <param name="totalDowntime">The total downtime calculated from the analysis.</param>
        /// <returns>A string containing the generated recommendations.</returns>
        private string GenerateRecommendations(TimeSpan totalDowntime)
        {
            // Implement your recommendation logic here
            return $"Recommendations based on total downtime of {totalDowntime.TotalHours} hours."; // Placeholder
        }

        /// <summary>
        /// Updates the PlotModel with the analyzed data.
        /// </summary>
        /// <param name="data">The list of ProductionMetric data used for the analysis.</param>
        private void UpdatePlotModel(List<ProductionMetric> data)
        {
            var plotModel = new PlotModel
            { Title = "Downtime Analysis" };

            plotModel.Series.Clear();

            // Create BarSeries based on data
            var barSeries = new BarSeries
            {
                Title = "Downtime Analysis",
                ItemsSource = data.Select(pm => new BarItem((double)(pm.Downtime ?? 0))).ToList()
            };

            plotModel.Series.Add(barSeries);

            // Add axes
            var categoryAxis = new CategoryAxis { Position = AxisPosition.Left };
            foreach (var pm in data)
            {
                categoryAxis.Labels.Add(pm.MetricDate.ToString("MM/dd/yyyy")); // Adjust the date format as needed
            }

            plotModel.Axes.Clear();
            plotModel.Axes.Add(categoryAxis);
            plotModel.Axes.Add(new LinearAxis { Position = AxisPosition.Bottom, Title = "Downtime (Hours)" });

            PlotModel = plotModel;
        }
    }
}