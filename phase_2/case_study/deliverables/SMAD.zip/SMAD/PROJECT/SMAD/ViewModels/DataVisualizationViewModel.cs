﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot;
using SMAD.Repo;
using System.Windows.Input;
using SMAD.Entities;
using System.Windows;
using Serilog; // Include Serilog for logging
using System.Diagnostics; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for visualizing production metrics data.
    /// This ViewModel handles filtering metrics based on selected production lines and date ranges,
    /// and updates the plot model for visualization.
    /// </summary>
    public class DataVisualizationViewModel : ViewModelBase1
    {
        private readonly IDataVisualizationRepo _repo;

        private ObservableCollection<ProductionLine> _productionLines;
        private ProductionLine _selectedProductionLine;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private PlotModel _plotModel;

        /// <summary>
        /// Gets or sets the collection of production lines.
        /// </summary>
        public ObservableCollection<ProductionLine> ProductionLines
        {
            get => _productionLines;
            set
            {
                _productionLines = value;
                OnPropertyChanged(nameof(ProductionLines));
            }
        }

        /// <summary>
        /// Gets or sets the selected production line for filtering metrics.
        /// </summary>
        public ProductionLine SelectedProductionLine
        {
            get => _selectedProductionLine;
            set
            {
                _selectedProductionLine = value;
                OnPropertyChanged(nameof(SelectedProductionLine));
            }
        }

        /// <summary>
        /// Gets or sets the start date for filtering metrics.
        /// </summary>
        public DateTime? StartDate
        {
            get => _startDate;
            set
            {
                _startDate = value;
                OnPropertyChanged(nameof(StartDate));
            }
        }

        /// <summary>
        /// Gets or sets the end date for filtering metrics.
        /// </summary>
        public DateTime? EndDate
        {
            get => _endDate;
            set
            {
                _endDate = value;
                OnPropertyChanged(nameof(EndDate));
            }
        }

        /// <summary>
        /// Gets or sets the plot model used for visualizing metrics data.
        /// </summary>
        public PlotModel PlotModel
        {
            get => _plotModel;
            set
            {
                _plotModel = value;
                OnPropertyChanged(nameof(PlotModel));
            }
        }

        /// <summary>
        /// Command to execute the filtering of metrics.
        /// </summary>
        public ICommand FilterCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataVisualizationViewModel"/> class.
        /// </summary>
        /// <param name="repo">The repository for data visualization.</param>
        public DataVisualizationViewModel(IDataVisualizationRepo repo)
        {
            _repo = repo;
            ProductionLines = new ObservableCollection<ProductionLine>(_repo.GetProductionLines());
            FilterCommand = new RelayCommand1(param => FilterMetrics());
        }

        /// <summary>
        /// Filters metrics based on the selected production line and date range.
        /// </summary>
        private void FilterMetrics()
        {
            // Check if a line is selected
            if (SelectedProductionLine == null)
            {
                MessageBox.Show("Please select a production line.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Check if start and end dates are selected
            if (StartDate == null || EndDate == null)
            {
                MessageBox.Show("Please select both start and end dates.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var metrics = _repo.FilterMetrics(SelectedProductionLine, StartDate, EndDate);
                UpdatePlotModel(metrics);
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error filtering metrics. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Updates the plot model with the filtered metrics.
        /// </summary>
        /// <param name="metrics">The filtered production metrics.</param>
        private void UpdatePlotModel(IEnumerable<ProductionMetric> metrics)
        {
            var plotModel = new PlotModel { Title = "Data Visualization Metrics" };
            var dateAxis = new DateTimeAxis
            {
                Position = AxisPosition.Bottom,
                StringFormat = "dd-MM-yyyy",
                Title = "Date"
            };
            plotModel.Axes.Add(dateAxis);
            // Assuming you want to visualize ProductionRate and Efficiency
            var productionRateSeries = new LineSeries { Title = "Production Rate" };
            foreach (var metric in metrics)
            {
                productionRateSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.ProductionRate));
            }
            plotModel.Series.Add(productionRateSeries);

            var efficiencySeries = new LineSeries { Title = "Efficiency (%)" };
            foreach (var metric in metrics)
            {
                efficiencySeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.Efficiency));
            }
            plotModel.Series.Add(efficiencySeries);
            plotModel.Axes.Add(new LinearAxis { Title = "Production Rate", Position = AxisPosition.Left });
            plotModel.Axes.Add(new LinearAxis { Title = "Efficiency (%)", Position = AxisPosition.Right });

            PlotModel = plotModel;
        }
    }
}