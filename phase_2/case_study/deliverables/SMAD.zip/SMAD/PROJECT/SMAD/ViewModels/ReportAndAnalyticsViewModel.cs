﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using SMAD.Entities;
using SMAD.Repo;
using Newtonsoft.Json;
using Microsoft.Win32;
using System.IO;
using Serilog; // Include Serilog for logging
using System.Diagnostics; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for generating reports and analytics for production metrics.
    /// This ViewModel handles report generation and exporting data to JSON.
    /// </summary>
    public class ReportAndAnalyticsViewModel : ViewModelBase1
    {
        private readonly IProductionMetricsRepo _repo;
        private ObservableCollection<ProductionMetric> _reportData;
        private DateTime? _startDate;
        private DateTime? _endDate;
        private int? _selectedLineId;

        /// <summary>
        /// Gets or sets the collection of production lines.
        /// </summary>
        public ObservableCollection<ProductionLine> ProductionLines { get; set; }

        /// <summary>
        /// Gets or sets the report data for production metrics.
        /// </summary>
        public ObservableCollection<ProductionMetric> ReportData
        {
            get => _reportData;
            set
            {
                _reportData = value;
                OnPropertyChanged(); // Notify the UI of changes
            }
        }

        /// <summary>
        /// Gets or sets the start date for the report.
        /// </summary>
        public DateTime? StartDate
        {
            get => _startDate;
            set
            {
                _startDate = value;
                OnPropertyChanged(); // Notify UI of changes
            }
        }

        /// <summary>
        /// Gets or sets the end date for the report.
        /// </summary>
        public DateTime? EndDate
        {
            get => _endDate;
            set
            {
                _endDate = value;
                OnPropertyChanged(); // Notify UI of changes
            }
        }

        /// <summary>
        /// Gets or sets the selected production line ID.
        /// </summary>
        public int? SelectedLineId
        {
            get => _selectedLineId;
            set
            {
                _selectedLineId = value;
                OnPropertyChanged(); // Notify UI of changes
            }
        }

        /// <summary>
        /// Gets or sets the selected production line.
        /// </summary>
        public ProductionLine SelectedProductionLine { get; set; }

        /// <summary>
        /// Command to generate a report.
        /// </summary>
        public ICommand GenerateReportCommand { get; }

        /// <summary>
        /// Command to export report data to JSON.
        /// </summary>
        public ICommand ExportToJsonCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReportAndAnalyticsViewModel"/> class.
        /// </summary>
        /// <param name="repo">The repository for production metrics.</param>
        public ReportAndAnalyticsViewModel(IProductionMetricsRepo repo)
        {
            _repo = repo;
            GenerateReportCommand = new RelayCommand1(OnGenerateReport);
            ExportToJsonCommand = new RelayCommand1(OnExportToJson);
            ReportData = new ObservableCollection<ProductionMetric>();
            ProductionLines = new ObservableCollection<ProductionLine>(); // Initialize
        }

        /// <summary>
        /// Generates a report based on the selected criteria.
        /// </summary>
        /// <param name="parameter">Optional parameter for command execution.</param>
        private void OnGenerateReport(object parameter)
        {
            try
            {
                SelectedLineId = SelectedProductionLine?.LineID; // Set selected line ID
                var metrics = _repo.GetProductionMetrics(StartDate, EndDate, SelectedLineId);
                ReportData.Clear();
                foreach (var metric in metrics)
                {
                    ReportData.Add(metric);
                }
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error generating report. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show($"Error generating report: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Exports the report data to a JSON file.
        /// </summary>
        /// <param name="parameter">Optional parameter for command execution.</param>
        private void OnExportToJson(object parameter)
        {
            try
            {
                var jsonSettings = new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                };
                var jsonData = JsonConvert.SerializeObject(ReportData, Formatting.Indented, jsonSettings);
                var SaveFileDialog = new SaveFileDialog
                {
                    Filter = "JSON files (*.json)|*.json",
                    Title = "Save as JSON"
                };
                if (SaveFileDialog.ShowDialog() == true)
                {
                    File.WriteAllText(SaveFileDialog.FileName, jsonData);
                    MessageBox.Show("Data exported successfully to JSON.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                var stackTrace = new StackTrace(ex, true);
                Log.Error(ex, "Error exporting to JSON. Stack Trace: {StackTrace}", stackTrace.ToString());
                MessageBox.Show($"Error exporting to JSON: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}