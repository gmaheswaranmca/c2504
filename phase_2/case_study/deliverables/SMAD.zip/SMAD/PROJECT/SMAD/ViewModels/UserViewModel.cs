﻿using System;
using System.Collections.ObjectModel;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Input;
using SMAD.Entities;
using SMAD.Repo;
using Serilog; // Include Serilog for logging
using System.Diagnostics;
using SMAD.EFRepo; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for managing user accounts.
    /// This ViewModel handles user creation, login, update, and deletion.
    /// </summary>
    public delegate void DWindoClose();

    public class UserViewModel : ViewModelBase1
    {
        public DWindoClose WindowClose;
        public DWindoClose EditWindowClose;

        public  IUserRepo _repo = EFUserRepo.Instance;

        private User _newUser;
        private User _selectedUser;
        private User _currentUser;
        private ObservableCollection<User> _users;

        /// <summary>
        /// Gets or sets the new user to be created.
        /// </summary>
        public User NewUser
        {
            get { return _newUser; }
            set
            {
                _newUser = value;
                OnPropertyChanged(nameof(NewUser));
            }
        }

        /// <summary>
        /// Gets or sets the selected user for updates or deletion.
        /// </summary>
        public User SelectedUser
        {
            get { return _selectedUser; }
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(SelectedUser));
            }
        }

        /// <summary>
        /// Gets or sets the current user for login purposes.
        /// </summary>
        public User CurrentUser
        {
            get { return _currentUser; }
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
            }
        }

        /// <summary>
        /// Gets or sets the collection of users.
        /// </summary>
        public ObservableCollection<User> Users
        {
            get { return _users; }
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        public ICommand CreateCommand { get; set; }
        public ICommand LoginCommand { get; set; }
        public ICommand UpdateCommand { get; set; }
        public ICommand DeleteCommand { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="User ViewModel"/> class.
        /// </summary>
        public UserViewModel()
        {
            NewUser = new User
            {
                Username = "",
                PasswordHash = "",
                Role = "",
                CreatedAt = DateTime.Now,
                LastLogin = DateTime.Now,
            };

            CurrentUser = new User
            {
                Username = "",
                PasswordHash = ""
            };

            LoadUsers();
            CreateCommand = new RelayCommand(Create);
            LoginCommand = new RelayCommand(Login);
            UpdateCommand = new RelayCommand(Update);
            DeleteCommand = new RelayCommand(Delete);
        }

        /// <summary>
        /// Deletes the selected user after confirmation.
        /// </summary>
        public void Delete()
        {
            if (SelectedUser == null)
            {
                MessageBox.Show("Please select the user to delete.", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var res = MessageBox.Show("Are you sure to delete this user?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (res != MessageBoxResult.Yes) return;

            try
            {
                _repo.Delete(SelectedUser);
                MessageBox.Show($"User  {SelectedUser.UserID} deleted successfully.", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error deleting user. Stack Trace: {StackTrace}", new StackTrace(ex, true).ToString());
                MessageBox.Show($"Error deleting user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Updates the selected user after confirmation.
        /// </summary>
        private void Update()
        {
            if (SelectedUser == null) return;

            var res = MessageBox.Show("Are you sure to update this user?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (res != MessageBoxResult.Yes) return;

            try
            {
                _repo.Update(SelectedUser);
                MessageBox.Show($"User  {SelectedUser.UserID} updated successfully.", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
                EditWindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error updating user. Stack Trace: {StackTrace}", new StackTrace(ex, true).ToString());
                MessageBox.Show($"Error updating user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Loads all users from the repository.
        /// </summary>
        public void LoadUsers()
        {
            Users = _repo.ReadAll();
        }

        /// <summary>
        /// Hashes the password for the new user.
        /// </summary>
        public void HashPassword()
        {
            string password = NewUser.PasswordHash;
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(passwordBytes);

                string hashString = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                NewUser.PasswordHash = hashString;
            }
        }

        /// <summary>
        /// Creates a new user after confirmation.
        /// </summary>
        private void Create()
        {
            HashPassword();
            var newUser = new User
            {
                Username = NewUser.Username,
                PasswordHash = NewUser.PasswordHash,
                Role = NewUser.Role,
                CreatedAt = DateTime.Now,
                LastLogin = DateTime.Now,
            };

            try
            {
                var result = MessageBox.Show("Are you sure to create?", "Confirm", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes) return;

                _repo.Create(newUser);
                MessageBox.Show("Created successfully.", "Alert", MessageBoxButton.OK, MessageBoxImage.Information);
                LoadUsers();
                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error creating user. Stack Trace: {StackTrace}", new StackTrace(ex, true).ToString());
                MessageBox.Show($"Error creating user: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Checks if the current user can login.
        /// </summary>
        public bool CanLogin()
        {
            return CurrentUser.Username.Length > 0 && CurrentUser.PasswordHash.Length > 0;
        }

        /// <summary>
        /// Logs in the current user.
        /// </summary>
        private void Login()
        {
            try
            {
                _repo.Login(CurrentUser);
                MessageBox.Show("Login successful.");

                if (CurrentUser.Username == "admin88")
                {
                    SmadConfig.adminDashboardWindow.Show();
                }
                else
                {
                    SmadConfig.homeDashboardWindow.Show();
                }
                WindowClose?.Invoke();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error logging in. Stack Trace: {StackTrace}", new StackTrace(ex, true).ToString());
                MessageBox.Show($"Error logging in: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}