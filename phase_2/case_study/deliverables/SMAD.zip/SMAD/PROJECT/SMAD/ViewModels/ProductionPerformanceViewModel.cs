﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OxyPlot.Axes;
using OxyPlot.Series;
using OxyPlot;
using SMAD.EFRepo;
using SMAD.Repo;
using System.Windows.Input;
using System.Windows;
using SMAD.Entities;
using Serilog; // Include Serilog for logging
using System.Diagnostics; // Include this for StackTrace

namespace SMAD.ViewModels
{
    /// <summary>
    /// ViewModel for monitoring production performance metrics.
    /// This ViewModel handles loading production lines and metrics,
    /// filtering metrics based on selected criteria, and updating
    /// the plot model for visualization.
    /// </summary>
    public class ProductionPerformanceViewModel : ViewModelBase1
    {
        private ObservableCollection<ProductionMetric> _productionMetrics;
        private ObservableCollection<ProductionLine> _productionLines;
        private ProductionLine _selectedProductionLine;
        private DateTime? _startDate;
        private DateTime? _endDate;

        private readonly IProductionRepo _repo;

        /// <summary>
        /// Gets or sets the collection of production metrics.
        /// </summary>
        public ObservableCollection<ProductionMetric> ProductionMetrics
        {
            get => _productionMetrics;
            set
            {
                _productionMetrics = value;
                OnPropertyChanged(nameof(ProductionMetrics));
            }
        }

        /// <summary>
        /// Gets or sets the collection of production lines.
        /// </summary>
        public ObservableCollection<ProductionLine> ProductionLines
        {
            get => _productionLines;
            set
            {
                _productionLines = value;
                OnPropertyChanged(nameof(ProductionLines));
            }
        }

        private PlotModel _plotModel;

        /// <summary>
        /// Gets or sets the plot model used for visualizing production metrics.
        /// </summary>
        public PlotModel PlotModel
        {
            get => _plotModel;
            set
            {
                _plotModel = value;
                OnPropertyChanged(nameof(PlotModel));
            }
        }

        /// <summary>
        /// Gets or sets the selected production line for filtering metrics.
        /// </summary>
        public ProductionLine SelectedProductionLine
        {
            get => _selectedProductionLine;
            set
            {
                _selectedProductionLine = value;
                OnPropertyChanged(nameof(SelectedProductionLine));
            }
        }

        /// <summary>
        /// Gets or sets the start date for filtering metrics.
        /// </summary>
        public DateTime? StartDate
        {
            get => _startDate;
            set
            {
                _startDate = value;
                OnPropertyChanged(nameof(StartDate));
            }
        }

        /// <summary>
        /// Gets or sets the end date for filtering metrics.
        /// </summary>
        public DateTime? EndDate
        {
            get => _endDate;
            set
            {
                _endDate = value;
                OnPropertyChanged(nameof(EndDate));
            }
        }

        /// <summary>
        /// Command to execute the filtering of metrics.
        /// </summary>
        public ICommand FilterCommand { get; }

        /// <summary>
        /// Initializes a new instance of the <see cref="ProductionPerformanceViewModel"/> class.
        /// </summary>
        public ProductionPerformanceViewModel()
        {
            _repo = new EFProductionMonitoringRepo(); // Initialize the EFRepo
            ProductionMetrics = new ObservableCollection<ProductionMetric>();
            ProductionLines = new ObservableCollection<ProductionLine>();

            LoadProductionLines();
            LoadProductionMetrics();

            FilterCommand = new RelayCommand1(param => FilterMetrics());
        }

        /// <summary>
        /// Loads production lines from the database and populates the ProductionLines collection.
        /// </summary>
        private void LoadProductionLines()
        {
            using (var context = new SmadDbEntities())
            {
                var lines = context.ProductionLines.ToList();
                ProductionLines = new ObservableCollection<ProductionLine>(lines);
            }
        }

        /// <summary>
        /// Loads production metrics from the database and populates the ProductionMetrics collection.
        /// </summary>
        private void LoadProductionMetrics()
        {
            using (var context = new SmadDbEntities())
            {
                var metrics = context.ProductionMetrics.ToList();
                ProductionMetrics = new ObservableCollection<ProductionMetric>(metrics);
            }
        }

        /// <summary>
        /// Filters metrics based on the selected production line and date range.
        /// </summary>
        public void FilterMetrics()
        {
            // Check if a line is selected
            if (SelectedProductionLine == null)
            {
                MessageBox.Show("Please select a production line.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Check if start and end dates are selected
            if (StartDate == null || EndDate == null)
            {
                MessageBox.Show("Please select both start and end dates.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var filteredMetrics = _repo.FilterMetrics(SelectedProductionLine, StartDate, EndDate);
                ProductionMetrics = new ObservableCollection<ProductionMetric>(filteredMetrics);
                UpdatePlotModel();
            }
            catch (Exception ex)
            {
                // Capture the stack trace
                
                Log.Error(ex, $"Error filtering metrics. Stack Trace: {ex.StackTrace}");
                MessageBox.Show($"An error occurred while filtering: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Updates the plot model with the filtered metrics.
        /// </summary>
        private void UpdatePlotModel()
        {
            var plotModel = new PlotModel { Title = "Production Metrics" };
            var dateAxis = new DateTimeAxis
            {
                Position = AxisPosition.Bottom,
                StringFormat = "dd-MM-yyyy",
                Title = "Date"
            };
            plotModel.Axes.Add(dateAxis);

            // Add the Production Rate axis (Y-axis)
            var productionRateAxis = new LinearAxis
            {
                Position = AxisPosition.Left,
                Title = "Production Rate"
            };
            plotModel.Axes.Add(productionRateAxis);

            var productionRateSeries = new LineSeries { Title = "Production Rate" };
            foreach (var metric in ProductionMetrics)
            {
                productionRateSeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.ProductionRate));
            }
            plotModel.Series.Add(productionRateSeries);

            var efficiencySeries = new LineSeries { Title = "Efficiency (%)" };
            foreach (var metric in ProductionMetrics)
            {
                efficiencySeries.Points.Add(new DataPoint(DateTimeAxis.ToDouble(metric.MetricDate), (double)metric.Efficiency));
            }
            plotModel.Series.Add(efficiencySeries);

            // Update the PlotModel property
            PlotModel = plotModel;
        }
    }
}