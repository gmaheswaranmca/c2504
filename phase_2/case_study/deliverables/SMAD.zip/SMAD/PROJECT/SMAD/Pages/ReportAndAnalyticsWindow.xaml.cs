﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMAD.EFRepo;
using SMAD.Entities;
using SMAD.ViewModels;

namespace SMAD.Pages
{
    /// <summary>
    /// Interaction logic for ReportAndAnalyticsWindow.xaml
    /// </summary>
    public partial class ReportAndAnalyticsWindow : Window
    {
        private readonly ReportAndAnalyticsViewModel _viewModel;

        public ReportAndAnalyticsWindow()
        {
            InitializeComponent();
            _viewModel = new ReportAndAnalyticsViewModel(new EFProductionMetricsRepo(new SmadDbEntities()));
            DataContext = _viewModel; // Set the DataContext to enable binding
            LoadProductionLines(); // Load production lines when the page is initialized
        }

        private void LoadProductionLines()
        {
            try
            {
                using (var context = new SmadDbEntities())
                {
                    var productionLines = context.ProductionLines.ToList();
                    _viewModel.ProductionLines = new ObservableCollection<ProductionLine>(productionLines);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading production lines: {ex.Message}");
            }
        }

        private void OnGenerateReportClick(object sender, RoutedEventArgs e)
        {
            try
            {
                _viewModel.GenerateReportCommand.Execute(null); // Execute the command to generate the report
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating report: {ex.Message}");
            }
        }

        private void OnExportToPdfClick(object sender, RoutedEventArgs e)
        {
            try
            {
                _viewModel.GenerateReportCommand.Execute(null);
            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error Generating Report: {ex.Message}");
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
