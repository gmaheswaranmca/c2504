﻿using System.Windows;
using SMAD.EFRepo;
using SMAD.ViewModels;

namespace SMAD.Pages
{
    /// <summary>
    /// Interaction logic for DataVisualizationWindow.xaml
    /// </summary>
    public partial class DataVisualizationWindow : Window
    {
        public DataVisualizationWindow()
        {
            InitializeComponent();
            this.DataContext = new DataVisualizationViewModel(new EFDataVisualizationRepo());

        }
    }
}
