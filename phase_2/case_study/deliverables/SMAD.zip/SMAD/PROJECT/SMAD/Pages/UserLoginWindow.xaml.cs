﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SMAD.ViewModels;


namespace SMAD.Pages
{
    /// <summary>
    /// Interaction logic for UserLoginWindow.xaml
    /// </summary>
    public partial class UserLoginWindow : Window
    {
        
        public bool IsAdmin { get; set; } = false;
        public UserLoginWindow()
        {
            InitializeComponent();
            var ViewModel = new UserViewModel();
            this.DataContext = ViewModel;
           // if(ViewModel.CurrentUser.Role.CompareTo)
           //ViewModel.WindowClose = CloseLogin;
        }

        //public void CloseLogin()
        //{

        //    throw new NotImplementedException();
        //    //if (IsAdmin)
        //    //{
        //    //    this.Hide();
        //    //    SmadConfig.adminDashboardWindow.Show();
        //    //}
        //    //else
        //    //{
        //    //    this.Hide();
        //    //    SmadConfig.homeDashboardWindow.Show();
        //    //}


        //}
     

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

       
    }
}
