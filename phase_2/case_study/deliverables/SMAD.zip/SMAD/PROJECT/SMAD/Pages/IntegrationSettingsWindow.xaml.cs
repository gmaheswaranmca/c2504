﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SMAD.Pages
{
    /// <summary>
    /// Interaction logic for IntegrationSettingsWindow.xaml
    /// </summary>
    public partial class IntegrationSettingsWindow : Window
    {
        public IntegrationSettingsWindow()
        {
            InitializeComponent();
        }
        private void ConfigureDevice_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Device configuration functionality is to be implemented soon.", "Coming Soon");
        }

        private void SyncDeviceSettings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Device settings synchronization functionality is to be implemented soon.", "Coming Soon");
        }

        private void CheckConnectivityStatus_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Device connectivity check functionality is to be implemented soon.", "Coming Soon");
        }

        private void SyncDeviceData_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Device data sync functionality is to be implemented soon.", "Coming Soon");
        }

        private void ResetDevice_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Device reset functionality is to be implemented soon.", "Coming Soon");
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel= true;
            this.Hide();    
        }
    }
}
