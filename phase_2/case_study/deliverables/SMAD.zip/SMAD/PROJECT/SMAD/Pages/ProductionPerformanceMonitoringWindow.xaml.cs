﻿using System.Windows;
using SMAD.ViewModels;

namespace SMAD.Pages
{
    /// <summary>
    /// Interaction logic for ProductionPerformanceMonitoringWindow.xaml
    /// </summary>
    public partial class ProductionPerformanceMonitoringWindow : Window
    {
        public ProductionPerformanceMonitoringWindow()
        {
            InitializeComponent();
            this.DataContext = new ProductionPerformanceViewModel();

        }
    }
}
