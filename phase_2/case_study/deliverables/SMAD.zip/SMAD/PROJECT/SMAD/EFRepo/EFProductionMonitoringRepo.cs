﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Entities;
using SMAD.Repo;

namespace SMAD.EFRepo
{
    public class EFProductionMonitoringRepo : IProductionRepo
    {
        public List<ProductionMetric> FilterMetrics(ProductionLine selectedProductionLine, DateTime? startDate, DateTime? endDate)
        {
            using (var context = new SmadDbEntities())
            {
                var query = context.ProductionMetrics.AsQueryable();

                if (selectedProductionLine != null)
                {
                    query = query.Where(m => m.LineID == selectedProductionLine.LineID);
                }

                if (startDate.HasValue)
                {
                    query = query.Where(m => m.MetricDate >= startDate.Value);
                }

                if (endDate.HasValue)
                {
                    query = query.Where(m => m.MetricDate <= endDate.Value);
                }

                return query.ToList();
            }
        }
    }
}