﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Entities;
using SMAD.Repo;

namespace SMAD.EFRepo
{
    public class EFProductionMetricsRepo : IProductionMetricsRepo
    {
        private readonly SmadDbEntities _context;

        public EFProductionMetricsRepo(SmadDbEntities context)
        {
            _context = context;
        }

        public IEnumerable<ProductionMetric> GetProductionMetrics(DateTime? startDate, DateTime? endDate, int? lineId)
        {
            var query = _context.ProductionMetrics.AsQueryable();

            if (lineId.HasValue)
            {
                query = query.Where(pm => pm.LineID == lineId.Value);
            }

            return query.Where(pm => pm.MetricDate >= startDate && pm.MetricDate <= endDate)
                        .ToList();
        }
    }
}
