﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SMAD.Entities;
using SMAD.Repo;

namespace SMAD.EFRepo
{
    public class EFContactSupportRepo : IContactSupportRepo
    {
        private readonly SmadDbEntities _context;
        public EFContactSupportRepo()
        {
            _context = new SmadDbEntities();
        }


        public void CreateHelp(ContactSupport contactModel)
        {
            
            _context.ContactSupports.Add(contactModel);
            _context.SaveChanges();
        }

        public ObservableCollection<ContactSupport> ReadAllContacts()
        {

            return new ObservableCollection<ContactSupport>(_context.ContactSupports.ToList());


        }
    }
}
