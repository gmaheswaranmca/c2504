﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Entities;
using SMAD.Repo;

namespace SMAD.EFRepo
{
    public class EFDataVisualizationRepo : IDataVisualizationRepo
    {
        public IEnumerable<ProductionLine> GetProductionLines()
        {
            using (var context = new SmadDbEntities())
            {
                return context.ProductionLines.ToList();
            }
        }

        public IEnumerable<ProductionMetric> FilterMetrics(ProductionLine selectedLine, DateTime? startDate, DateTime? endDate)
        {
            using (var context = new SmadDbEntities())
            {
                var query = context.ProductionMetrics.AsQueryable();

                if (selectedLine != null)
                {
                    query = query.Where(m => m.LineID == selectedLine.LineID);
                }

                if (startDate.HasValue)
                {
                    query = query.Where(m => m.MetricDate >= startDate.Value);
                }

                if (endDate.HasValue)
                {
                    query = query.Where(m => m.MetricDate <= endDate.Value);
                }

                return query.ToList();
            }
        }
    }
}