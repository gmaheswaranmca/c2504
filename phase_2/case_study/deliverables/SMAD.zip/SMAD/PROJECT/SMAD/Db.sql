﻿Create Database SmadDb;
 
Use SmadDb;
 
CREATE TABLE Users (

    UserID INT PRIMARY KEY IDENTITY(1,1),

    Username NVARCHAR(50) NOT NULL UNIQUE,

    PasswordHash NVARCHAR(255) NOT NULL,

    Role NVARCHAR(50) NOT NULL,

    CreatedAt DATETIME DEFAULT GETDATE(),

    LastLogin DATETIME

);
 


 
CREATE TABLE ProductionLines (

    LineID INT PRIMARY KEY IDENTITY(1,1),

    LineName NVARCHAR(100) NOT NULL,

    Status NVARCHAR(50) NOT NULL,  -- e.g., Active, Inactive

    CreatedAt DATETIME DEFAULT GETDATE()

);
 

 
CREATE TABLE ProductionMetrics (

    MetricID INT PRIMARY KEY IDENTITY(1,1),

    LineID INT NOT NULL,

    MetricDate DATETIME NOT NULL,

    ProductionRate DECIMAL(18, 2),  -- Units produced per hour

    Efficiency DECIMAL(5, 2),       -- Percentage (0-100)

    QualityRate DECIMAL(5, 2),       -- Percentage (0-100)

    Downtime DECIMAL(18, 2),         -- Hours of downtime

    FOREIGN KEY (LineID) REFERENCES ProductionLines(LineID)

);
 

 

 
CREATE TABLE Alerts (

    AlertID INT PRIMARY KEY IDENTITY(1,1),

    LineID INT NOT NULL,

    AlertDate DATETIME DEFAULT GETDATE(),

    AlertType NVARCHAR(100) NOT NULL,  -- e.g., Machine Failure, Quality Issue

    Severity NVARCHAR(50),              -- e.g., Low, Medium, High

    Message NVARCHAR(255) NOT NULL,

    Resolved BIT DEFAULT 0,

    FOREIGN KEY (LineID) REFERENCES ProductionLines(LineID)

);
 

 
CREATE TABLE Settings (

    SettingID INT PRIMARY KEY IDENTITY(1,1),

    SettingKey NVARCHAR(100) NOT NULL UNIQUE,

    SettingValue NVARCHAR(255) NOT NULL,

    CreatedAt DATETIME DEFAULT GETDATE(),

    UpdatedAt DATETIME DEFAULT GETDATE()

);

 
CREATE TABLE ProductionTrends (

    TrendID INT PRIMARY KEY IDENTITY(1,1),

    LineID INT NOT NULL,

    TrendDate DATETIME NOT NULL,

    AverageProductionRate DECIMAL(18, 2),

    AverageEfficiency DECIMAL(5, 2),

    AverageQualityRate DECIMAL(5, 2),

    FOREIGN KEY (LineID) REFERENCES ProductionLines(LineID)

);
 
INSERT INTO ProductionTrends (LineID, TrendDate, AverageProductionRate, AverageEfficiency, AverageQualityRate)

VALUES 

(1, '2022-01-01 00:00:00', 90.00, 92.00, 95.00),

(1, '2022-01-02 00:00:00', 88.00, 90.00, 93.00),

(1, '2022-01-03 00:00:00', 85.00, 88.00, 90.00),

(2, '2022-01-01 00:00:00', 92.00, 94.00, 96.00),

(2, '2022-01-02 00:00:00', 90.00, 92.00, 94.00),

(2, '2022-01-03 00:00:00', 88.00, 90.00, 92.00),

(3, '2022-01-01 00:00:00', 95.00, 97.00, 98.00),

(3, '2022-01-02 00:00:00', 93.00, 95.00, 96.00),

(3, '2022-01-03 00:00:00', 90.00, 92.00, 94.00),

(1, '2022-01-04 00:00:00', 80.00, 85.00, 90.00),

(2, '2022-01-04 00:00:00', 85.00, 88.00, 92.00),

(3, '2022-01-04 00:00:00', 88.00, 90.00, 94.00);
 
Select * From ProductionTrends;
 
 
 