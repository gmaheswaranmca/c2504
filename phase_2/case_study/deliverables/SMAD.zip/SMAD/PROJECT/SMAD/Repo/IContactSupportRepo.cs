﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using SMAD.Entities;

namespace SMAD.Repo
{
    public interface IContactSupportRepo
    {
        void CreateHelp(ContactSupport contactModel);

        ObservableCollection<ContactSupport> ReadAllContacts();
    }
}
