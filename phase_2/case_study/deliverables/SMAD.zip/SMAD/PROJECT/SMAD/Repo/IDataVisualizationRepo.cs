﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Entities;

namespace SMAD.Repo
{
    public interface IDataVisualizationRepo
    {
        IEnumerable<ProductionLine> GetProductionLines();
        IEnumerable<ProductionMetric> FilterMetrics(ProductionLine selectedLine, DateTime? startDate, DateTime? endDate);
        // Add any other necessary method signatures here
    }


}