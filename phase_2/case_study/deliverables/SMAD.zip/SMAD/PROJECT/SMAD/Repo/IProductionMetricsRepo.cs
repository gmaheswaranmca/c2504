﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Entities;

namespace SMAD.Repo
{
    public interface IProductionMetricsRepo
    {
        IEnumerable<ProductionMetric> GetProductionMetrics(DateTime? startDate, DateTime? endDate, int? lineId);
    }
}
