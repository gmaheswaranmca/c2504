﻿using System;
using System.Collections.Generic;
using SMAD.Entities;

namespace SMAD.Repo
{
    public interface IProductionRepo
    {
        List<ProductionMetric> FilterMetrics(ProductionLine selectedProductionLine, DateTime? startDate, DateTime? endDate);
    }
}