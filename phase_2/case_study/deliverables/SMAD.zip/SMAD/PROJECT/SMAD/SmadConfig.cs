﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMAD.Pages;

namespace SMAD
{
    public static class SmadConfig
    {
        public static UserLoginWindow userLoginWindow {  get; set; }    
        public static UserManagementWindow userManagementWindow {  get; set; }
        public static HomeDashboardWindow homeDashboardWindow {  get; set; }    
        public static AdminDashboardWindow adminDashboardWindow {  get; set; }  
        public static DataVisualizationWindow dataVisualizationWindow {  get; set; }    
        public static ProductionPerformanceMonitoringWindow productionPerformanceMonitoringWindow {  get; set; }    
        public static BottleNeckAnalysisWindow bottleNeckAnalysisWindow {  get; set; }
        public static AlertAndNotificationWindow alertAndNotificationWindow {  get; set; }
        public static ReportAndAnalyticsWindow reportAndAnalyticsWindow {  get; set; }
        public static HelpAndSupportWindow helpAndSupportWindow { get; set; }   
        public static AddAlertWindow addAlertWindow {  get; set; }
        public static EditAlertWindow editAlertWindow {  get; set; }
        public static CreateUserWindow createUserWindow {  get; set; }  
        public static UpdateUserWindow updateUserWindow {  get; set; }  

        public static DataSourcesOverview dataSourcesOverview { get; set; }

        public static IntegrationSettingsWindow integrationSettingsWindow { get; set; }

        static SmadConfig()
        {
            userLoginWindow = new UserLoginWindow();
            userManagementWindow = new UserManagementWindow();  
            homeDashboardWindow = new HomeDashboardWindow();
            adminDashboardWindow = new AdminDashboardWindow();
            dataVisualizationWindow = new DataVisualizationWindow();
            productionPerformanceMonitoringWindow = new ProductionPerformanceMonitoringWindow();
            bottleNeckAnalysisWindow = new BottleNeckAnalysisWindow();
            alertAndNotificationWindow = new AlertAndNotificationWindow();
            reportAndAnalyticsWindow = new ReportAndAnalyticsWindow();
            helpAndSupportWindow = new HelpAndSupportWindow();
            addAlertWindow = new AddAlertWindow();
            editAlertWindow = new EditAlertWindow();
            createUserWindow = new CreateUserWindow();
            updateUserWindow = new UpdateUserWindow();  
            integrationSettingsWindow = new IntegrationSettingsWindow();
            dataSourcesOverview = new DataSourcesOverview();

        }

    }
}
