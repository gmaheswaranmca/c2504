﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_
{
    public static class EHRMSConfig
    {
        public static User CurrentUser {get;set;}

        private static EFUserRepo _repo;
        
        static EHRMSConfig()
        {
            _repo = EFUserRepo.Instance;
            CurrentUser = _repo.CurrentUser;
        }

        public static void AddToAuditTrail(AuditTrail auditTrail)
        {
            AuditTrialViewModel.Instance.CreateAuditTrail(new AuditTrail
            {
                UserID = auditTrail.UserID,
                Action = auditTrail.Action,
                ActionDateTime = auditTrail.ActionDateTime,
                Description = auditTrail.Description,
            });
            AuditTrialViewModel.Instance.LoadAuditTrials();
        }
    }
}
