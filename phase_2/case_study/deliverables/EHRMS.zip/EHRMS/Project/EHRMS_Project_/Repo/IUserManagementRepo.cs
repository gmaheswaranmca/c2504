﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IUserManagementRepo
    {
        bool IsUserAuthenticated { get; set; }
        User CurrentUser { get; set; }
        void Login (User user);
        void Create(User newUser);
        ObservableCollection<User> ReadAll();

        void Update(User newUser);
        void Delete(User newUser);  

    }
}
