﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IAppointmentSchedulingRepo
    {
        void Create(Appointment appointment);
        ObservableCollection<Appointment> ReadAppointments(int UserId);

        Appointment GetAppointment(int UserId);
    }
}
