﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IBillingRepo
    {
        void CreateBilling(Billing billing);

        
        ObservableCollection<Billing> ReadAllBillings();

        
        Billing ReadBilling(int billId);

       
        void UpdateBilling(Billing billing);

       
        void DeleteBilling(Billing billing);
    }
}
