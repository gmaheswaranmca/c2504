﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IInsuranceRepo
    {
        void CreateInsurance(Insurance insurance);

        
        ObservableCollection<Insurance> ReadAllInsurances();

     
        Insurance ReadInsurance(int insuranceId);

      
        void UpdateInsurance(Insurance insurance);

      
        void DeleteInsurance(Insurance insurance);

    }
}
