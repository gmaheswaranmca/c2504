﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IPatientManagementRepo
    {
        void Create(Patient newPatient);
        ObservableCollection<Patient> ReadAll();
        void Update(Patient patient);
        void Delete(Patient patient);

        void CreateMedicalHistory(MedicalHistory medicalHistory);
        ObservableCollection<MedicalHistory> ReadAllMedicalHistory(int id);
        Patient ReadByID(int id);
    }
}
