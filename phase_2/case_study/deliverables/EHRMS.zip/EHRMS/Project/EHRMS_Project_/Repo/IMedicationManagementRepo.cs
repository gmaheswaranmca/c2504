﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.Repo
{
    public interface IMedicationManagementRepo
    {
   
        void Create(Medication medication);


        ObservableCollection<Medication> ReadAll();


        Medication ReadById(int medicationId);


        void Update(Medication medication);

    
        void Delete(Medication medication);
    }
}
