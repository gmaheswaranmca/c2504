﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private IUserManagementRepo _repo;
        private User _currentUser;
        public User CurrentUser
        {
            get { return _currentUser; }
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
            }
        }

        public MainViewModel()
        {
            _repo = EFUserRepo.Instance;
            LoadCurrentUserData();
        }

        public void LoadCurrentUserData()
        {
            var user = _repo.CurrentUser;
            if(user != null)
            {
                CurrentUser = new User
                {
                    UserID = user.UserID,
                    Name = user.Name,
                    Email = user.Email,
                    PasswordHash = user.PasswordHash,
                    Role = user.Role,
                    CreatedAt = user.CreatedAt,
                    LastLogin = user.LastLogin,
                };
            }
        }

    }
}
