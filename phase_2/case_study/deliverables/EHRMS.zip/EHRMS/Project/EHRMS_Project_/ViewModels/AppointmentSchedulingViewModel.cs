﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;
using log4net;

namespace EHRMS_Project_.ViewModels
{
    public delegate void DAppointmentWindowClose();
    public class AppointmentSchedulingViewModel : ViewModelBase
    {
     
        private readonly ILog _logger = LogManager.GetLogger(typeof(AppointmentSchedulingViewModel));
        public DAppointmentWindowClose WindowClose;
        private Appointment _newAppointment;
        private IAppointmentSchedulingRepo _repo;

        public Appointment NewAppointment
        {
            get
            {
                return _newAppointment;
            }
            set
            {
                _newAppointment = value;
                OnPropertyChanged(nameof(Appointment));
            }
        }

        private Appointment _selectedAppointment;
        public Appointment SelectedAppointment
        {
            get
            {
                return _selectedAppointment;
            }
            set
            {
                _selectedAppointment = value;
                GetAppointmentPatient();
                OnPropertyChanged(nameof(SelectedAppointment));
            }
        }

        private Patient _appointmentPatient;
        public Patient AppointmentPatient
        {
            get
            {
                return _appointmentPatient;
            }
            set
            {
                _appointmentPatient = value;
                OnPropertyChanged(nameof(AppointmentPatient));
            }
        }



        private ObservableCollection<Appointment> _appointments;
        public ObservableCollection<Appointment> Appointments
        {
            get
            {
                return _appointments;
            }
            set
            {
                _appointments = value;
                OnPropertyChanged(nameof(Appointments));
            }
        }

        public ICommand CreateAppointmentCommand { get; }

        private AppointmentSchedulingViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();
            _repo = EFAppointmentSchedulingRepo.Instance;
            CreateAppointmentCommand = new RelayCommand(CreateAppointment);
            this.NewAppointment = new Appointment
            {
                PatientID = 0,
                UserID = 0,
                AppointmentDate = DateTime.Now,
                Status = "",
                Notes = ""
            };

            LoadAppointments();
        }

        private static AppointmentSchedulingViewModel _instance;
        public static AppointmentSchedulingViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AppointmentSchedulingViewModel();
                }
                return _instance;
            }
        }

        public void CreateAppointment()
        {
            var newAppointment = new Appointment
            {
                PatientID = NewAppointment.PatientID,
                UserID = NewAppointment.UserID,
                AppointmentDate = NewAppointment.AppointmentDate,
                Status = NewAppointment.Status,
                Notes = NewAppointment.Notes
            };


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to Schedule an appointment?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _repo.Create(NewAppointment);
                result = MessageBox.Show(messageBoxText: "Appointment Scheduled successfully...",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Appointment Scheduled successfully...");
                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Appointment Scheduling",
                    ActionDateTime = DateTime.Now,
                    Description = $"User {EHRMSConfig.CurrentUser.UserID} Schedules an appointment for Patient {NewAppointment.PatientID}"
                });

                if (WindowClose != null)
                {
                    WindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }

        public void LoadAppointments()
        {
            try
            {
                Appointments = _repo.ReadAppointments(EHRMSConfig.CurrentUser.UserID);
            }catch(Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }

        public void GetAppointmentPatient()
        {
            try
            {
                AppointmentPatient = EFPatientRepo.Instance.ReadByID((int)SelectedAppointment.PatientID);
            }
            catch(Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }


    }
}
