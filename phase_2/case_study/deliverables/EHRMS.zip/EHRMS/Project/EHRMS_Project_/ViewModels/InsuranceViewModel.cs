﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Commands;
using EHRMS_Project_.Repo;
using System.Windows.Input;
using EHRMS_Project_.Entities;

namespace EHRMS_Project_.ViewModels
{
    public class InsuranceViewModel : ViewModelBase
    {
        private readonly IInsuranceRepo _insuranceRepo;
        private ObservableCollection<Insurance> _insuranceRecords;
        private Insurance _selectedInsurance;

        public ObservableCollection<Insurance> InsuranceRecords
        {
            get { return _insuranceRecords; }
            set
            {
                _insuranceRecords = value;
                OnPropertyChanged(nameof(InsuranceRecords));
                OnPropertyChanged(nameof(IsInsuranceSelected));
            }
        }

        public Insurance SelectedInsurance
        {
            get { return _selectedInsurance; }
            set { _selectedInsurance = value; OnPropertyChanged(nameof(SelectedInsurance)); }
        }

        public ICommand AddInsuranceCommand { get; }
        public ICommand EditInsuranceCommand { get; }
        public ICommand DeleteInsuranceCommand { get; }

        public bool IsInsuranceSelected => SelectedInsurance != null;

        public InsuranceViewModel(IInsuranceRepo insuranceRepo)
        {
            _insuranceRepo = insuranceRepo;
            // Assuming you have an EF context or other data source
            InsuranceRecords = new ObservableCollection<Insurance>(_insuranceRepo.ReadAllInsurances());

            AddInsuranceCommand = new RelayCommand(AddInsurance);
            EditInsuranceCommand = new RelayCommand(EditInsurance, () => IsInsuranceSelected);
            DeleteInsuranceCommand = new RelayCommand(DeleteInsurance, () => IsInsuranceSelected);
        }

        private void AddInsurance()
        {
            var newInsurance = new Insurance
            {
                // Add new insurance details (mocked here)
                PatientID = 1, // Replace with actual data
                InsuranceProvider = "ABC Insurance",
                PolicyNumber = "XYZ123456",
                ExpirationDate = DateTime.Now.AddYears(1)
            };

            // Add to database
            _insuranceRepo.CreateInsurance(newInsurance);
            InsuranceRecords.Add(newInsurance);
            // Save changes to the database here
        }

        private void EditInsurance()
        {
            if (SelectedInsurance != null)
            {
                // Edit insurance logic
                SelectedInsurance.InsuranceProvider = "XYZ Insurance";
                _insuranceRepo.UpdateInsurance(SelectedInsurance);
                // Save changes to the database
            }
        }

        private void DeleteInsurance()
        {
            if (SelectedInsurance != null)
            {
                // Remove from collection
                InsuranceRecords.Remove(SelectedInsurance);
                _insuranceRepo.DeleteInsurance(SelectedInsurance);
                // Delete from the database
            }
        }
    }
}
