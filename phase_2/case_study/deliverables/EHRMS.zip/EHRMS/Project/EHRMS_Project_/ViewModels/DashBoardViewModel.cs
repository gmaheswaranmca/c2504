﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHRMS_Project_.ViewModels
{
    internal class DashBoardViewModel
    {
    }
}
