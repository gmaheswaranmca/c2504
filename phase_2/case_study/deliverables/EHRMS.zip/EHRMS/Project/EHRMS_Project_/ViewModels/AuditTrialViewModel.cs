﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using System.Windows.Input;
using System.Windows;
using EHRMS_Project_.Entities;
using log4net;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.ViewModels
{
    public class AuditTrialViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(AuditTrialViewModel));

        private AuditTrail _newAuditTrail;
        private IAuditTrialRepo _repo;

        public AuditTrail NewAuditTrail
        {
            get
            {
                return _newAuditTrail;
            }
            set
            {
                _newAuditTrail = value;
                OnPropertyChanged(nameof(Appointment));
            }
        }

        private ObservableCollection<AuditTrail> _auditTrail;
        public ObservableCollection<AuditTrail> AuditTrails
        {
            get
            {
                return _auditTrail;
            }
            set
            {
                _auditTrail = value;
                OnPropertyChanged(nameof(AuditTrails));
            }
        }

        private AuditTrialViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            _repo = EFAuditTrialRepo.Instance;
          
            //this.NewAuditTrail = new AuditTrail
            //{
            //    UserID = 0,
            //    Action = "",
            //    ActionDateTime = DateTime.Now,
            //    Description = ""
            //};

            LoadAuditTrials();
        }

        private static AuditTrialViewModel _instance;
        public static AuditTrialViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AuditTrialViewModel();
                }
                return _instance;
            }
        }

        public void CreateAuditTrail(AuditTrail auditTrail)
        {
            //var newAuditTrail = new AuditTrail
            //{
            //    UserID = NewAuditTrail.UserID,
            //    Action = NewAuditTrail.Action,
            //    ActionDateTime = NewAuditTrail.ActionDateTime,
            //    Description = NewAuditTrail.Description
            //};


            try 
            { 
                        
                _repo.Create(auditTrail);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }

        public void LoadAuditTrials()
        {
            try
            {
                AuditTrails = _repo.ReadAll();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }
    }
}
