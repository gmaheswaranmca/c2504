﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Pages;
using EHRMS_Project_.Repo;
using log4net;

namespace EHRMS_Project_.ViewModels
{
    public delegate void DWindowClose();
    public class UserViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(UserViewModel));
        public DWindowClose WindowClose;
        public IUserManagementRepo _repo = EFUserRepo.Instance;
        private User _newUser;

        public User NewUser 
        {
            get
            {
                return _newUser;
            }
            set
            {
                _newUser = value;
                OnPropertyChanged(nameof(NewUser));
            }
        }

        private User _currentUser;

        public User CurrentUser
        {
            get
            {
                return _currentUser;
            }
            set
            {
                _currentUser = value;
                OnPropertyChanged(nameof(CurrentUser));
                

            }
        }

        private ObservableCollection<User> _users;
        public ObservableCollection<User> Users
        {
            get { return _users; }
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));   
            }
        }
        public ICommand CreateCommand { get; set; }
        public ICommand LoginCommand { get; set; }
        public ICommand UpdateCommand { get; set; }

        private UserViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            NewUser = new User
            {
                Name = "Name",
                Email = "",
                PasswordHash = "",
                Role = "Doctor",
                CreatedAt = DateTime.Now,
                LastLogin = DateTime.Now,

            };

            CurrentUser = new User
            {
                Email = "",
                PasswordHash = ""
            };

            LoadUsers();
            CreateCommand = new RelayCommand(Create);
            UpdateCommand = new RelayCommand(Update);
            LoginCommand = new RelayCommand(Login);
        }

        private static UserViewModel _instance;
        public static UserViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserViewModel();
                }
                return _instance;
            }
        }

        private User _selectedUser;
        public User SelectedUser
        {
            get { return _selectedUser; }
            set
            {
                _selectedUser = value;
                OnPropertyChanged(nameof(_selectedUser));

            }

        }

        public void LoadUsers()
        {
            Users = _repo.ReadAll();
        }

        public void HashPassword()
        {
            string password = NewUser.PasswordHash;
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(passwordBytes);

                // Convert the hash bytes to a hexadecimal string
                string hashString = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();

                NewUser.PasswordHash = hashString;
            }
        }

        public void Create()
        {

            HashPassword();

            var newUser = new User
            {
                Name = NewUser.Name,
                Email = NewUser.Email,
                PasswordHash = NewUser.PasswordHash,
                Role = NewUser.Role,
                CreatedAt = DateTime.Now,
                LastLogin = DateTime.Now,
            };


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }

                _repo.Create(newUser);

                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"User created successfully");

                LoadUsers();

                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Created",
                    ActionDateTime = DateTime.Now,
                    Description = $"Admin {EHRMSConfig.CurrentUser.UserID} Created user{newUser.UserID} "
                });

                if (WindowClose != null)
                {
                    WindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }

        public void Login()
        {
            try
            {
                _repo.Login(CurrentUser);
                MessageBox.Show($"Login successfull");
                Logger.log.Info($"Logged in successfully");

                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Logged in",
                    ActionDateTime = DateTime.Now,
                    Description = $"User {EHRMSConfig.CurrentUser.UserID} is logged in"
                });
                if ((_repo.CurrentUser.Role.CompareTo("Admin") == 0))
                {
                    var Window = DashboardWindow.Instance;
                    Window.Show();

                }
                else
                {
                    var window = UserDashboardPageWindow.Instance;
                    window.Show();
                }
                if (WindowClose != null)
                {
                    WindowClose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }


        }

        public void Update()
        {
            if (this.SelectedUser == null)
            {
                return;
            }

            var res = MessageBox.Show(messageBoxText: "Are you sure to Update?",
                    caption: "Confirm",
                    button: MessageBoxButton.YesNo,
                    icon: MessageBoxImage.Question);

            if (res != MessageBoxResult.Yes)
            {
                return;
            }

            try
            {
                _repo.Update(SelectedUser);
                
                var result = MessageBox.Show($"updated successfully",
                        caption: "Alert",
                        button: MessageBoxButton.OK,
                        icon: MessageBoxImage.Information);
                Logger.log.Info($"User updated successfully");

                LoadUsers();
                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Updated",
                    ActionDateTime = DateTime.Now,
                    Description = $"Admin {EHRMSConfig.CurrentUser.UserID} updated {SelectedUser.UserID} "
                });

                if (WindowClose != null)
                {
                    WindowClose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }
        public bool CanLogin()
        {
            return CurrentUser.Email.Length > 0 && CurrentUser.PasswordHash.Length > 0;
        }


    }
}
