﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using System.Windows.Input;
using System.Windows;
using EHRMS_Project_.Entities;
using log4net;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.ViewModels
{
    
    public class MedicationViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(MedicationViewModel));
        private readonly IMedicationManagementRepo _medicationRepo;
        public DWindwoClose NewWindowClose;
        private ObservableCollection<Medication> _medications;
        private Medication _newMedication;
        private Medication _selectedMedication;

        public ObservableCollection<Medication> Medications
        {
            get { return _medications; }
            set { _medications = value; OnPropertyChanged(nameof(Medications)); }
        }

        public Medication NewMedication
        {
            get { return _newMedication; }
            set { _newMedication = value; OnPropertyChanged(nameof(NewMedication)); }
        }

        public Medication SelectedMedication
        {
            get { return _selectedMedication; }
            set { _selectedMedication = value; OnPropertyChanged(nameof(SelectedMedication)); }
        }

       

        public ICommand CreateCommand { get; }
        public ICommand UpdateCommand { get; }
        public ICommand DeleteCommand { get; }

        private MedicationViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            _medicationRepo = new EFMedicationRepo();
           
            CreateCommand = new RelayCommand(Create);
            UpdateCommand = new RelayCommand(Update);
            DeleteCommand = new RelayCommand(Delete);

            NewMedication = new Medication
            {
                PatientID = 10052,
                MedicationName = "Paracetamol",
                Dosage = "500mg",
                Frequency = "Twice a day",
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(7),
                PrescribedBy = EHRMSConfig.CurrentUser.UserID,
                CreatedAt = DateTime.Now
            };
            LoadMedcation();
        }

        private static MedicationViewModel _instance;
        public static MedicationViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MedicationViewModel();
                }
                return _instance;
            }
        }

        public void LoadMedcation()
        {
           Medications = _medicationRepo.ReadAll();
        }

        public void Create()
        {
           
            
            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _medicationRepo.Create(NewMedication);
                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Medication created successfully");

                LoadMedcation();

                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Medication Created",
                    ActionDateTime = DateTime.Now,
                    Description = $"User {EHRMSConfig.CurrentUser.UserID} Created Medication for Patient {NewMedication.PatientID}"
                });

                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
                Logger.log.Error($"{ex.StackTrace}");

            }


        }

        public void Update()
        {
            
            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to update?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _medicationRepo.Update(SelectedMedication);
                result = MessageBox.Show(messageBoxText: "Updated Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Medication updated successfully");

                LoadMedcation();

                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }

        }

        public void Delete()
        {

            
          
            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to delete?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _medicationRepo.Delete(SelectedMedication);
                result = MessageBox.Show(messageBoxText: "Deleted Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Medication deleted successfully");

                LoadMedcation();

                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }


    }
}
