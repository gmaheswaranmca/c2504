﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;
using log4net;

namespace EHRMS_Project_.ViewModels
{
    public class MedicalHistoryViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(MedicalHistoryViewModel));
        public Patient SelectedPatient { get; set; }
        private MedicalHistory _newMedicalHistory;
        public MedicalHistory NewMedicalHistory
        {
            get
            {
                return _newMedicalHistory;
            }
            set
            {
                _newMedicalHistory = value;
                OnPropertyChanged(nameof(NewMedicalHistory));
            }
        }

        private ObservableCollection<MedicalHistory> _medicalHistories;
        public ObservableCollection<MedicalHistory> MedicalHistories
        {
            get
            {
                return _medicalHistories;
            }
            set
            {
                _medicalHistories = value;
                OnPropertyChanged(nameof(MedicalHistories));
            }
        }

        public ICommand CreateMedicalHistoryCommand { get; }
        private IPatientManagementRepo _repo;

        private MedicalHistoryViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            _repo = EFPatientRepo.Instance;
            SelectedPatient = PatientViewModel.Instance.SelectedPatient;
            this.NewMedicalHistory = new MedicalHistory
            {
                MedicalHistoryID = 0,
                PatientID = SelectedPatient.PatientID,
                Condition = "",
                Description = "",
                DateRecorded = DateTime.Now,

            };
            CreateMedicalHistoryCommand = new RelayCommand(CreateMedicalHistory);
            LoadMedicalHistories();
        }

        public void Reset()
        {
            NewMedicalHistory = new MedicalHistory {
                Condition="",
                Description = ""
            };

        }

        private static MedicalHistoryViewModel _instance;
        public static MedicalHistoryViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MedicalHistoryViewModel();
                }
                return _instance;
            }
        }

        public void LoadMedicalHistories()
        {
            //MessageBox.Show($"{SelectedPatient.PatientID}");
            try
            {
                MedicalHistories = _repo.ReadAllMedicalHistory(SelectedPatient.PatientID);

            }catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }

        public void CreateMedicalHistory()
        {
            var MedicalHistory = new MedicalHistory
            {
                PatientID = NewMedicalHistory.PatientID,
                Condition = NewMedicalHistory.Condition,
                Description = NewMedicalHistory.Description,
                DateRecorded = DateTime.Now
            };


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _repo.CreateMedicalHistory(MedicalHistory);
                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Medical history created successfully");

                LoadMedicalHistories();
                Reset();
                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Medical History Created",
                    ActionDateTime = DateTime.Now,
                    Description = $"User {EHRMSConfig.CurrentUser.UserID} Creates a medical history for Patient {NewMedicalHistory.PatientID}"
                });

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.InnerException}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }


    }
}
