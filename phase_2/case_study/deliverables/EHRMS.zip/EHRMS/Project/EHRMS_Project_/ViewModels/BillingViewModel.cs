﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Commands;
using EHRMS_Project_.Repo;
using System.Windows.Input;
using EHRMS_Project_.EFRepo;
using System.Windows;
using EHRMS_Project_.Entities;
using log4net;

namespace EHRMS_Project_.ViewModels
{
    public class BillingViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(BillingViewModel));
        private readonly EFBillingRepo _billingRepo;
        private ObservableCollection<Billing> _billingRecords;
        private Billing _newBill;
        private Billing _selectedBill;
        public DWindowClose NewWindoeClose;

        public ObservableCollection<Billing> BillingRecords
        {
            get { return _billingRecords; }
            set { _billingRecords = value; OnPropertyChanged(nameof(BillingRecords)); }
        }

        public Billing NewBill
        {
            get { return _newBill; }
            set
            {
                _newBill = value; OnPropertyChanged(nameof(NewBill));
                
            }
        }
        public Billing SelectedBill
        {
            get { return _selectedBill; }
            set
            {
                _selectedBill = value; OnPropertyChanged(nameof(SelectedBill));
                
            }
        }

        public ICommand AddBillCommand { get; }
        public ICommand EditBillCommand { get; }
        public ICommand DeleteBillCommand { get; }

        public bool IsBillSelected => SelectedBill != null;

        public BillingViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            _billingRepo = new EFBillingRepo();
            

            AddBillCommand = new RelayCommand(AddBill);
            EditBillCommand = new RelayCommand(EditBill);
            DeleteBillCommand = new RelayCommand(DeleteBill);
            LoadBill();
        }

       public void LoadBill()
        {
            BillingRecords = _billingRepo.ReadAllBillings();
        }

        private void AddBill()
        {
            //var newBill = new Billing
            //{
            //    // Add new bill details (mocked here)
            //    PatientID = 1, // Replace with actual data
            //    TotalAmount = 1000m,
            //    Status = "Pending",
            //    PaymentMethod = "Credit Card",
            //    CreatedAt = DateTime.Now
            //};

            //// Add to database
            //_billingRepo.CreateBilling(newBill);
            //BillingRecords.Add(newBill);
            //// Save changes to the database here

            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                                        caption: "Confirm",
                                        button: MessageBoxButton.YesNo,
                                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _billingRepo.CreateBilling(NewBill);
                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Bill added Successfully");
                LoadBill();

                if (NewWindoeClose != null)
                {
                    NewWindoeClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");
            }
        }

        private void EditBill()
        {
            //if (SelectedBill != null)
            //{
            //    // Edit bill logic
            //    SelectedBill.Status = "Paid";
            //    _billingRepo.UpdateBilling(SelectedBill);
            //    // Save changes to the database
            //}

            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to update?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _billingRepo.UpdateBilling(SelectedBill);
                result = MessageBox.Show(messageBoxText: "Updated Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Bill updated Successfully");

                LoadBill();

                if (NewWindoeClose != null)
                {
                    NewWindoeClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }

        }

        private void DeleteBill()
        {
            //if (SelectedBill != null)
            //{
            //    _billingRepo.DeleteBilling(SelectedBill);
            //    // Remove from collection
            //    BillingRecords.Remove(SelectedBill);
            //    // Delete from the database
            //}


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to delete?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _billingRepo.DeleteBilling(SelectedBill);
                result = MessageBox.Show(messageBoxText: "Deleted Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Bill deleted Successfully");

                LoadBill();

                if (NewWindoeClose != null)
                {
                    NewWindoeClose();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }
        }

    }
}
