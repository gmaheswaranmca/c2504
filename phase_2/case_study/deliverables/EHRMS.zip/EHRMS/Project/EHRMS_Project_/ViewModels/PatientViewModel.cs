﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using EHRMS_Project_.Commands;
using EHRMS_Project_.EFRepo;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;
using log4net;

namespace EHRMS_Project_.ViewModels
{
   

    public delegate void DWindwoClose();
    public class PatientViewModel : ViewModelBase
    {
        private readonly ILog _logger = LogManager.GetLogger(typeof(PatientViewModel));
        private ObservableCollection<Patient> _patients;
        private Patient _newPatient;
        
        public DWindwoClose NewWindowClose;
        public ObservableCollection<Patient> Patients
        {
            get { return _patients; }
            set { _patients = value; OnPropertyChanged(nameof(Patients)); }
        }

        public Patient NewPatient 
        {
            get 
            {
                return _newPatient;
            }

            set
            {
                _newPatient = value;
                OnPropertyChanged(nameof(NewPatient));  
            }
        }

        private Patient _selectedPatient;
        public Patient SelectedPatient
        {
            get{ return _selectedPatient; }
            set
            {
                _selectedPatient = value;
                OnPropertyChanged(nameof(SelectedPatient));
                
            }

        }

        

       


        public ICommand CreateCommand { get; }
       


        private IPatientManagementRepo _repo;

        private PatientViewModel()
        {
            log4net.Config.XmlConfigurator.Configure();

            _repo = EFPatientRepo.Instance;

            CreateCommand = new RelayCommand(Create);
           

            this.NewPatient = new Patient
            {
                FirstName = "ann",
                LastName = "mariya",
                DateOfBirth = DateTime.Now,
                Gender = "Female",
                ContactNumber = "5677887",
                Address = "palathuruthil",
                Email = "ann@gmail.com",
                Allergies = "ooooooo",
                CreatedAt = DateTime.Now
            };

            LoadPatients();
           

            SelectedPatient = new Patient
            {
                FirstName = "ann",
                LastName = "mariya",
                DateOfBirth = DateTime.Now,
                Gender = "Female",
                ContactNumber = "5677887",
                Address = "palathuruthil",
                Email = "ann@gmail.com",
                Allergies = "ooooooo",
                CreatedAt = DateTime.Now
            };


        }

        private static PatientViewModel _instance;
        public static PatientViewModel Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new PatientViewModel();
                }
                return _instance;
            }
        }

        public void LoadPatients()
        {
           
            Patients = _repo.ReadAll();          
           
        }

       

        public void Create()
        {

            var newPatient = new Patient
            {
               
                FirstName = NewPatient.FirstName,
                LastName = NewPatient.LastName,
                DateOfBirth = NewPatient.DateOfBirth,
                Gender = NewPatient.Gender,
                ContactNumber = NewPatient.ContactNumber,
                Address = NewPatient.Address,
                Email = NewPatient.Email,
                Allergies = NewPatient.Allergies,
                CreatedAt = DateTime.Now
            };


            try
            {
                var result = MessageBox.Show(messageBoxText: "Are you sure to create?",
                        caption: "Confirm",
                        button: MessageBoxButton.YesNo,
                        icon: MessageBoxImage.Question);
                if (result != MessageBoxResult.Yes)
                {
                    return;
                }
                _repo.Create(newPatient);  
                result = MessageBox.Show(messageBoxText: "Created Successfully",
                caption: "Alert",
                button: MessageBoxButton.OK,
                icon: MessageBoxImage.Information);
                Logger.log.Info($"Patient created successfully");

                LoadPatients();

                EHRMSConfig.AddToAuditTrail(new AuditTrail
                {
                    UserID = EHRMSConfig.CurrentUser.UserID,
                    Action = "Patient Registration",
                    ActionDateTime = DateTime.Now,
                    Description = $"User {EHRMSConfig.CurrentUser.UserID} registered a new patient"
                });
                if (NewWindowClose != null)
                {
                    NewWindowClose();
                }
               
            }
            catch(Exception ex) 
            {
               MessageBox.Show($"{ex.Message}");
                Logger.log.Error($"{ex.StackTrace}");

            }


        }
    }
}
