﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace EHRMS_Project_
{
    public delegate void DCloseWindow();
    public class CloseConfig
    {
        public DCloseWindow CloseWindow;
        public void CloseCurrentWindow(Window window)
        {

        }

    }
}
