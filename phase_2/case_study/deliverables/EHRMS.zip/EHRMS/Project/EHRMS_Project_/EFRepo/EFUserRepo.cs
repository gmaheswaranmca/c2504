﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFUserRepo : IUserManagementRepo
    {
        private static EFUserRepo _instance;
        public bool IsUserAuthenticated { get; set;  }
        public User CurrentUser {  get; set; } =  null;
        public static EFUserRepo Instance 
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new EFUserRepo();
                }
                return _instance;
            }
        }

        private EHRMSDbEntities _context;



        private EFUserRepo()
        {
            _context = new EHRMSDbEntities();
        }
        public void Create(User newUser)
        {
            try
            {
                _context.Users.Add(newUser);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
            
        }

        public void Delete(User newUser)
        {
            throw new NotImplementedException();
        }

        public ObservableCollection<User> ReadAll()
        {
            return new ObservableCollection<User>(_context.Users.ToList());
        }

        public void Update(User newUser)
        {
            try
            {
                var user = _context.Users.Where(u => u.UserID == newUser.UserID).FirstOrDefault();
                if (user != null)
                {
                    user.Role = newUser.Role;
                    user.Email = newUser.Email;
                    _context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetPassword(string password)
        {
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                byte[] hashBytes = md5.ComputeHash(passwordBytes);

                // Convert the hash bytes to a hexadecimal string
                string inputHash = BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                return inputHash;
            }


        }

        public void Login(User user)
        {
            var HashedPassword = GetPassword(user.PasswordHash);
            var User = _context.Users.FirstOrDefault(u => u.Email == user.Email && u.PasswordHash == HashedPassword);
            if(User == null)
            {
                throw new Exception("Invalid username or password");
            }
            else
            {
                CurrentUser = User;
            }

        }
    }
}
