﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFAuditTrialRepo : IAuditTrialRepo
    {
        private EHRMSDbEntities _context;


        private static EFAuditTrialRepo _instance;


        private EFAuditTrialRepo()
        {
            _context = new EHRMSDbEntities();

        }

        public static EFAuditTrialRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFAuditTrialRepo();
                }
                return _instance;
            }
        }
        public void Create(AuditTrail auditTrial)
        {
            try
            {
                _context.AuditTrails.Add(auditTrial);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
            
        }

        public ObservableCollection<AuditTrail> ReadAll()
        {
            try
            {
                return new ObservableCollection<AuditTrail>(_context.AuditTrails.OrderByDescending(r => r.ActionDateTime).ToList());
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }
    }
}
