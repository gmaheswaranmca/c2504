﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFPatientRepo :IPatientManagementRepo
    {
        private EHRMSDbEntities _context;
        private static EFPatientRepo _instance;
        

        private EFPatientRepo()
        {
            _context = new EHRMSDbEntities();
            
        }

        public static EFPatientRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFPatientRepo();
                }
                return _instance;
            }
        }

        public void Create(Patient newPatient)
        {
            _context.Patients.Add(newPatient);
            _context.SaveChanges();
        }

        public void Delete(Patient patient)
        {
            throw new NotImplementedException();
        }

        public ObservableCollection<Patient> ReadAll()
        {
            
            return new ObservableCollection<Patient>(_context.Patients.ToList());
        }

        public void Update(Patient patient)
        {
            throw new NotImplementedException();
        }

        public void CreateMedicalHistory(MedicalHistory medicalHistory)
        {
            _context.MedicalHistories.Add(medicalHistory);
            _context.SaveChanges();
        }

        public ObservableCollection<MedicalHistory> ReadAllMedicalHistory(int id)
        {
            try
            {
                return new ObservableCollection<MedicalHistory>(_context.MedicalHistories.Where(m => m.PatientID == id).ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public Patient ReadByID(int id)
        {
            try
            {
                return _context.Patients.FirstOrDefault(m => m.PatientID == id);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
