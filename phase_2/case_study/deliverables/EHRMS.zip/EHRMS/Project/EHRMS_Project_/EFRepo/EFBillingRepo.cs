﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFBillingRepo : IBillingRepo
    {
        private readonly EHRMSDbEntities _context;

        public EFBillingRepo()
        {
            _context = new EHRMSDbEntities();
        }

        public void CreateBilling(Billing billing)
        {
            _context.Billings.Add(billing);
            _context.SaveChanges();
        }

        public ObservableCollection<Billing> ReadAllBillings()
        {
            return new ObservableCollection<Billing>(_context.Billings.ToList());
        }
        

        public Billing ReadBilling(int billId)
        {
            return _context.Billings.Find(billId);
        }

        public void UpdateBilling(Billing billing)
        {
            _context.Entry(billing).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void DeleteBilling(Billing billing)
        {
            _context.Billings.Remove(billing);
            _context.SaveChanges();
        }

        
    }
}
