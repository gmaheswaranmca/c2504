﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFMedicationRepo :IMedicationManagementRepo
    {
        private readonly EHRMSDbEntities _context;

        public EFMedicationRepo()
        {
            _context = new EHRMSDbEntities();
        }

        public void Create(Medication medication)
        {
            try
            {
                _context.Medications.Add(medication);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }

        public ObservableCollection<Medication> ReadAll()
        {
            try
            {
                var medications = _context.Medications.ToList();
                return new ObservableCollection<Medication>(medications);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public Medication ReadById(int medicationId)
        {
            try
            {
                return _context.Medications.FirstOrDefault(m => m.MedicationID == medicationId);
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }

        public void Update(Medication medication)
        {
            try
            {
                var existingMedication = _context.Medications.Find(medication.MedicationID);
                if (existingMedication != null)
                {
                    _context.Entry(existingMedication).CurrentValues.SetValues(medication);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }

        public void Delete(Medication medication)
        {
            try
            {
                var medicationToDelete = _context.Medications.Find(medication.MedicationID);
                if (medicationToDelete != null)
                {
                    _context.Medications.Remove(medicationToDelete);
                    _context.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            
        }


    }
}
