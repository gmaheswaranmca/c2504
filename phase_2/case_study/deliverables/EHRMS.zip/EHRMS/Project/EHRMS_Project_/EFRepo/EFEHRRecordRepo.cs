﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EHRMS_Project_.EFRepo
{
    internal class EFEHRRecordRepo
    {
    }
}
