﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFInsuranceRepo : IInsuranceRepo
    {
        private readonly EHRMSDbEntities _context;

        public EFInsuranceRepo(EHRMSDbEntities context)
        {
            _context = context;
        }

        public void CreateInsurance(Insurance insurance)
        {
            _context.Insurances.Add(insurance);
            _context.SaveChanges();
        }

        public ObservableCollection<Insurance> ReadAllInsurances()
        {
            return new ObservableCollection<Insurance>(_context.Insurances.ToList());
        }

        public Insurance ReadInsurance(int insuranceId)
        {
            return _context.Insurances.Find(insuranceId);
        }

        public void UpdateInsurance(Insurance insurance)
        {
            _context.Entry(insurance).State = EntityState.Modified;
            _context.SaveChanges();
        }

        public void DeleteInsurance(Insurance insurance)
        {
            _context.Insurances.Remove(insurance);
            _context.SaveChanges();
        }

        
    }
}
