﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHRMS_Project_.Entities;
using EHRMS_Project_.Repo;

namespace EHRMS_Project_.EFRepo
{
    public class EFAppointmentSchedulingRepo : IAppointmentSchedulingRepo
    {
        private EHRMSDbEntities _context;


        private static EFAppointmentSchedulingRepo _instance;


        private EFAppointmentSchedulingRepo()
        {
            _context = new EHRMSDbEntities();

        }

        public static EFAppointmentSchedulingRepo Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EFAppointmentSchedulingRepo();
                }
                return _instance;
            }
        }
        public void Create(Appointment appointment)
        {
            try
            {
                _context.Appointments.Add(appointment);
                _context.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
           
        }

        public ObservableCollection<Appointment> ReadAppointments(int UserId)
        {
            try
            {
                return new ObservableCollection<Appointment>(_context.Appointments.Where(m => m.UserID == UserId).ToList());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Appointment GetAppointment(int PatientId)
        {
            try
            {
                var appointment = _context.Appointments.FirstOrDefault(a => a.PatientID == PatientId);
                return appointment;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
