﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Pages;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for MedicationListWindow.xaml
    /// </summary>
    public partial class MedicationListWindow : Window
    {
        public MedicationListWindow()
        {
            InitializeComponent();
            this.DataContext = MedicationViewModel.Instance;
        }

        private static MedicationListWindow _instance;
        public static MedicationListWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new MedicationListWindow();
                }

                return _instance;
            }
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            NewMedicationWindow.Instance.Show();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
           EditMedicationWindow.Instance.Show();    
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
