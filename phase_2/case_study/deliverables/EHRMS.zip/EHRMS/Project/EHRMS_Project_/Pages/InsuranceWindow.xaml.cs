﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Repo;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for InsuranceWindow.xaml
    /// </summary>
    public partial class InsuranceWindow : Window
    {
        private readonly IInsuranceRepo _insuranceRepo;
        public InsuranceWindow()
        {
            InitializeComponent();
            //_insuranceRepo = insuranceRepo;
            //this.DataContext = new InsuranceViewModel(_insuranceRepo);
        }

        private static InsuranceWindow _instance;
        public static InsuranceWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new InsuranceWindow();
                }

                return _instance;
            }
        }
    }
}
