﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for NewMedicationWindow.xaml
    /// </summary>
    public partial class NewMedicationWindow : Window
    {
        public NewMedicationWindow()
        {
            InitializeComponent();

            this.DataContext = MedicationViewModel.Instance;
         //   ViewModelConfig.medicationViewModel.NewWindowClose = HideWindow;
        }

        private static NewMedicationWindow _instance;
        public static NewMedicationWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new NewMedicationWindow();
                }

                return _instance;
            }
        }
        public void HideWindow()
        {
            this.Hide();
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
