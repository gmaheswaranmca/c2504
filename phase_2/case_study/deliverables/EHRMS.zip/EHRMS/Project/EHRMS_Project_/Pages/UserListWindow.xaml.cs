﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for UserListWindow.xaml
    /// </summary>
    public partial class UserListWindow : Window
    {
        public UserListWindow()
        {
            InitializeComponent();
            this.DataContext = UserViewModel.Instance;
        }

        private static UserListWindow _instance;
        public static UserListWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new UserListWindow();
                }

                return _instance;
            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            NewUserPageWindow.Instance.Show();
           // FormConfig.newUserPageWindow.Show();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if(grdUsers.SelectedItem == null)
            {
                MessageBox.Show($"Please select a user");
                return;
            }
            UpdateUserWindow.Instance.Show();
        }
    }
}
