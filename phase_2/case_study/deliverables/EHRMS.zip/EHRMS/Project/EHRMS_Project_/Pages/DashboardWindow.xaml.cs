﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Pages;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for DashboardWindow.xaml
    /// </summary>
    public partial class DashboardWindow : Window
    {
        public DashboardWindow()
        {
            InitializeComponent();
        }

        private static DashboardWindow _instance;
        public static DashboardWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DashboardWindow();
                }

                return _instance;
            }

        }

        private void btnUserManager_Click(object sender, RoutedEventArgs e)
        {
            UserListWindow.Instance.Show();
            //FormConfig.userListWindow.Show();
        }
        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnAudit_Click(object sender, RoutedEventArgs e)
        {
            AuditTrialWindow.Instance.Show();
        }
    }
}
