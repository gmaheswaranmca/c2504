﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Pages;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for ReportingPageWindow.xaml
    /// </summary>
    public partial class ReportingPageWindow : Window
    {
        public ReportingPageWindow()
        {
            InitializeComponent();
        }

        private static ReportingPageWindow _instance;
        public static ReportingPageWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new ReportingPageWindow();
                }

                return _instance;
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
