﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Pages;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for EHRRecordWindow.xaml
    /// </summary>
    public partial class EHRRecordWindow : Window
    {
        public EHRRecordWindow()
        {
            InitializeComponent();
        }

        private static EHRRecordWindow _instance;
        public static EHRRecordWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EHRRecordWindow();
                }

                return _instance;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
