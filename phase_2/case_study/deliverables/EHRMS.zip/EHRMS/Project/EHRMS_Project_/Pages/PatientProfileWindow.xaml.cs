﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Pages;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for PatientProfileWindow.xaml
    /// </summary>
    public partial class PatientProfileWindow : Window
    {
        public PatientProfileWindow()
        {
            InitializeComponent();
            this.DataContext = PatientViewModel.Instance;


        }

        private static PatientProfileWindow _instance;
        public static PatientProfileWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new PatientProfileWindow();
                }

                return _instance;
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MedicalHistoryWindow.Instance.Show();
           // FormConfig.medicalHistoryWindow.Show();
        }

        private void btnMed_Click(object sender, RoutedEventArgs e)
        {
            MedicationListWindow.Instance.Show();   
        }
    }
}
