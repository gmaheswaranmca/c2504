﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for AppointmentViewWindow.xaml
    /// </summary>
    public partial class AppointmentViewWindow : Window
    {
        public AppointmentViewWindow()
        {
            InitializeComponent();
            this.DataContext = AppointmentSchedulingViewModel.Instance;
        }

        private static AppointmentViewWindow _instance;
        public static AppointmentViewWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AppointmentViewWindow();
                }

                return _instance;
            }

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        //private void Button_Click(object sender, RoutedEventArgs e)
        //{
            
        //}

        //private void btnEHRMS_Click(object sender, RoutedEventArgs e)
        //{

        //}

        //private void btnMed_Click(object sender, RoutedEventArgs e)
        //{

        //}
    }
}
