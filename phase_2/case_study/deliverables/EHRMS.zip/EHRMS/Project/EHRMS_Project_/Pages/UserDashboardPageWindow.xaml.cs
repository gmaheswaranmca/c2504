﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for UserDashboardPageWindow.xaml
    /// </summary>
    public partial class UserDashboardPageWindow : Window
    {
        public MainViewModel ViewModel { get; set; }
        public UserDashboardPageWindow()
        {
            InitializeComponent();
            ViewModel = new MainViewModel();
            this.DataContext = ViewModel;
           // ValidateDasgBoard();

            if(EHRMSConfig.CurrentUser.Role.CompareTo("Doctor") == 0)
            {
                btnAppointment.Content = "My Appointments";
            }
            else
            {
                btnAppointment.Content = "Schedule Appointment";
            }
            
        }

        private static UserDashboardPageWindow _instance;
        public static UserDashboardPageWindow Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new UserDashboardPageWindow();
                }

                return _instance;
            }

        }


        public void ValidateDasgBoard()
        {
            if(ViewModel.CurrentUser.Role.CompareTo("Doctor") == 0)
            {
                btnPatientManager.IsEnabled = false;
            }
        }
        private void btnPatientManager_Click(object sender, RoutedEventArgs e)
        {
            PatientsListWindow.Instance.Show();
            
        }

        private void btnUserEHR_Click(object sender, RoutedEventArgs e)
        {
           // EHRRecordWindow.Instance.Show();
            
        }

       
        
        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnMedication_Click(object sender, RoutedEventArgs e)
        {
           MedicationListWindow.Instance.Show();
          
        }

        private void btnAppointment_Click(object sender, RoutedEventArgs e)
        {
            if (EHRMSConfig.CurrentUser.Role.CompareTo("Doctor") == 0)
            {
                DoctorAppointmetsList.Instance.Show();
            }
            else
            {
                AppintmentSchedulingWindow.Instance.Show();
            }
        }
    }
}
