﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.Repo;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_
{
    /// <summary>
    /// Interaction logic for BillingAndInsuranceWindow.xaml
    /// </summary>
    public partial class BillingWindow : Window
    {
          private readonly IBillingRepo _billingRepo;

        public BillingWindow()
        {
            InitializeComponent();
          //  this.DataContext = ViewModelConfig.billingViewModel;
        }


        private static BillingWindow _instance;
        public static BillingWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new BillingWindow();
                }

                return _instance;
            }

        }

        //public BillingWindow(IBillingRepo billingRepo)
        //    {
                
        //        //this.DataContext = FormConfig.billingWindow;
        //        _billingRepo = billingRepo;
        //        this.DataContext = new BillingViewModel(_billingRepo);
        //    }
        

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

       

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            //FormConfig.addBillWindow.Show();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            //FormConfig.editBillWindow.Show();
        }
    }
}
