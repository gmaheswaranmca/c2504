﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for EditMedicationWindow.xaml
    /// </summary>
    public partial class EditMedicationWindow : Window
    {
        public EditMedicationWindow()
        {
            InitializeComponent();
            
          //  this.DataContext = ViewModelConfig.medicationViewModel;
           // ViewModelConfig.medicationViewModel.NewWindowClose = HideWindow;
        }

        private static EditMedicationWindow _instance;
        public static EditMedicationWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new EditMedicationWindow();
                }

                return _instance;
            }
        }
        public void HideWindow()
        {
            this.Hide();
        }
    }
}
