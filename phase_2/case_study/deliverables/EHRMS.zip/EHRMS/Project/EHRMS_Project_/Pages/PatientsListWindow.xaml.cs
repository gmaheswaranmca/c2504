﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for PatientsListWindow.xaml
    /// </summary>
    public partial class PatientsListWindow : Window
    {
        private PatientViewModel _patientViewModel;
        public PatientsListWindow()
        {
            InitializeComponent();
            this.DataContext = PatientViewModel.Instance;
        }

        private static PatientsListWindow _instance;
        public static PatientsListWindow Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new PatientsListWindow();
                }

                return _instance;
            }

        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            // FormConfig.patientRegistrationWindow.Show();
            PatientRegistrationWindow.Instance.Show();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            if(grdPatients.SelectedItem == null)
            {
                MessageBox.Show($"Please select a patient");
                return;
            }
            //  PatientProfileWindow.Instance.DataContext = _patientViewModel;
            MedicalHistoryViewModel.Instance.SelectedPatient = PatientViewModel.Instance.SelectedPatient;
            MedicalHistoryViewModel.Instance.LoadMedicalHistories();
            PatientProfileWindow.Instance.Show();
            
        
        }
    }
}
