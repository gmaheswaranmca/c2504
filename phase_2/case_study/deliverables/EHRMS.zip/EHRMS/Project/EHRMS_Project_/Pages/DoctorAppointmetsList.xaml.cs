﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using EHRMS_Project_.ViewModels;

namespace EHRMS_Project_.Pages
{
    /// <summary>
    /// Interaction logic for DoctorAppointmetsList.xaml
    /// </summary>
    public partial class DoctorAppointmetsList : Window
    {
        public DoctorAppointmetsList()
        {
            InitializeComponent();
            this.DataContext = AppointmentSchedulingViewModel.Instance;
        }

        private static DoctorAppointmetsList _instance;
        public static DoctorAppointmetsList Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DoctorAppointmetsList();
                }

                return _instance;
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AppointmentViewWindow.Instance.Show();
        }
    }
}
